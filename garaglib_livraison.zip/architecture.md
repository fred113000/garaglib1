# Architecture du Projet Garaglib

## Vue d'ensemble
Garaglib est une plateforme de réservation de créneaux horaires pour les garages automobiles, inspirée de Doctolib. Elle permet aux clients de rechercher des garages, consulter leurs disponibilités et réserver des créneaux. Les garagistes peuvent gérer leur planning et leurs services, tandis que les administrateurs supervisent l'ensemble de la plateforme.

## Stack Technique
- **Frontend**: Next.js avec App Router et TypeScript
- **Styling**: TailwindCSS pour un design responsive et moderne
- **Backend**: Firebase (Authentication, Firestore, Storage)
- **Déploiement**: Vercel (pour Next.js)

## Structure des Dossiers
```
garaglib/
├── public/             # Ressources statiques (images, favicon, etc.)
├── src/
│   ├── app/            # Structure App Router de Next.js
│   │   ├── (auth)/     # Pages d'authentification (login, register)
│   │   ├── (client)/   # Pages accessibles aux clients
│   │   ├── (garage)/   # Pages accessibles aux garagistes
│   │   ├── (admin)/    # Pages accessibles aux administrateurs
│   │   ├── api/        # Routes API
│   ├── components/     # Composants réutilisables
│   │   ├── ui/         # Composants UI génériques
│   │   ├── client/     # Composants spécifiques aux clients
│   │   ├── garage/     # Composants spécifiques aux garagistes
│   │   ├── admin/      # Composants spécifiques aux administrateurs
│   │   ├── shared/     # Composants partagés entre rôles
│   ├── lib/            # Utilitaires et fonctions
│   │   ├── firebase/   # Configuration et services Firebase
│   │   ├── hooks/      # Custom hooks React
│   │   ├── utils/      # Fonctions utilitaires
│   ├── types/          # Types TypeScript
│   ├── styles/         # Styles globaux
```

## Modèles de Données (Firestore)

### Collection `users`
```typescript
interface User {
  id: string;              // UID Firebase Auth
  email: string;           // Email de l'utilisateur
  displayName: string;     // Nom complet
  phoneNumber: string;     // Numéro de téléphone
  role: 'client' | 'garage' | 'admin';  // Rôle de l'utilisateur
  createdAt: Timestamp;    // Date de création
  updatedAt: Timestamp;    // Date de mise à jour
  photoURL?: string;       // URL de la photo de profil
}
```

### Collection `garages`
```typescript
interface Garage {
  id: string;              // ID unique
  ownerId: string;         // UID du propriétaire (user.id)
  name: string;            // Nom du garage
  description: string;     // Description du garage
  address: {
    street: string;        // Rue
    city: string;          // Ville
    zipCode: string;       // Code postal
    country: string;       // Pays
    coordinates: {         // Coordonnées pour Google Maps
      lat: number;
      lng: number;
    }
  };
  phoneNumber: string;     // Numéro de téléphone
  email: string;           // Email de contact
  website?: string;        // Site web
  openingHours: {          // Horaires d'ouverture
    [day: string]: {       // 'monday', 'tuesday', etc.
      isOpen: boolean;
      slots: {
        start: string;     // Format '09:00'
        end: string;       // Format '18:00'
      }[];
    }
  };
  services: string[];      // Liste des services proposés
  photos: string[];        // URLs des photos
  rating: number;          // Note moyenne
  reviewCount: number;     // Nombre d'avis
  createdAt: Timestamp;    // Date de création
  updatedAt: Timestamp;    // Date de mise à jour
  isVerified: boolean;     // Garage vérifié par l'admin
  isActive: boolean;       // Garage actif ou non
}
```

### Collection `services`
```typescript
interface Service {
  id: string;              // ID unique
  garageId: string;        // ID du garage
  name: string;            // Nom du service
  description: string;     // Description du service
  duration: number;        // Durée en minutes
  price: number;           // Prix en euros
  category: string;        // Catégorie (ex: 'entretien', 'réparation')
  isActive: boolean;       // Service actif ou non
  createdAt: Timestamp;    // Date de création
  updatedAt: Timestamp;    // Date de mise à jour
}
```

### Collection `appointments`
```typescript
interface Appointment {
  id: string;              // ID unique
  garageId: string;        // ID du garage
  clientId: string;        // ID du client
  serviceId: string;       // ID du service
  date: Timestamp;         // Date et heure du rendez-vous
  duration: number;        // Durée en minutes
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;          // Notes additionnelles
  vehicleInfo: {           // Informations sur le véhicule
    make: string;          // Marque
    model: string;         // Modèle
    year: number;          // Année
    licensePlate: string;  // Plaque d'immatriculation
  };
  createdAt: Timestamp;    // Date de création
  updatedAt: Timestamp;    // Date de mise à jour
}
```

### Collection `reviews`
```typescript
interface Review {
  id: string;              // ID unique
  garageId: string;        // ID du garage
  clientId: string;        // ID du client
  appointmentId: string;   // ID du rendez-vous
  rating: number;          // Note (1-5)
  comment: string;         // Commentaire
  createdAt: Timestamp;    // Date de création
  updatedAt: Timestamp;    // Date de mise à jour
  isPublished: boolean;    // Avis publié ou non
}
```

### Collection `notifications`
```typescript
interface Notification {
  id: string;              // ID unique
  userId: string;          // ID de l'utilisateur destinataire
  title: string;           // Titre de la notification
  message: string;         // Message de la notification
  type: 'info' | 'warning' | 'success' | 'error';
  isRead: boolean;         // Notification lue ou non
  createdAt: Timestamp;    // Date de création
  link?: string;           // Lien optionnel
}
```

## Flux de Réservation

1. **Recherche de garage**
   - Le client recherche un garage par localisation ou service
   - Le système affiche les garages correspondants avec leurs notes et disponibilités

2. **Sélection du service**
   - Le client sélectionne un garage
   - Le client choisit un service proposé par le garage

3. **Sélection du créneau**
   - Le système affiche les créneaux disponibles en fonction du service et des horaires du garage
   - Le client sélectionne un créneau disponible

4. **Saisie des informations**
   - Le client saisit les informations sur son véhicule
   - Le client peut ajouter des notes pour le garagiste

5. **Confirmation**
   - Le système récapitule la réservation
   - Le client confirme la réservation

6. **Notification**
   - Le système envoie une notification au client et au garage
   - Le rendez-vous est ajouté au planning du garage

7. **Gestion du rendez-vous**
   - Le garage peut confirmer, annuler ou marquer le rendez-vous comme terminé
   - Le client peut annuler le rendez-vous jusqu'à 24h avant

8. **Évaluation**
   - Après le rendez-vous, le client peut laisser un avis sur le garage

## Interfaces Utilisateur par Rôle

### Interface Client
- **Accueil**: Recherche de garages, services populaires, garages recommandés
- **Recherche**: Filtres avancés, carte Google Maps, liste des garages
- **Profil Garage**: Informations, services, avis, disponibilités
- **Réservation**: Sélection de service, créneau, informations véhicule
- **Dashboard**: Rendez-vous à venir, historique, garages favoris
- **Profil**: Informations personnelles, véhicules enregistrés

### Interface Garage
- **Dashboard**: Rendez-vous du jour, statistiques, notifications
- **Planning**: Vue calendrier, gestion des créneaux
- **Services**: Ajout, modification, suppression de services
- **Clients**: Liste des clients, historique des rendez-vous
- **Profil**: Informations du garage, horaires, photos
- **Statistiques**: Analyses des rendez-vous, services populaires

### Interface Admin
- **Dashboard**: Statistiques globales, nouveaux utilisateurs, activité
- **Garages**: Liste des garages, validation, suspension
- **Utilisateurs**: Gestion des utilisateurs, rôles
- **Services**: Catégories de services, validation
- **Rapports**: Analyses détaillées, exportation de données
- **Paramètres**: Configuration de la plateforme

## Palette de Couleurs
- **Bleu foncé**: #1E3A8A (couleur principale)
- **Bleu clair**: #3B82F6 (couleur secondaire)
- **Blanc**: #FFFFFF (arrière-plan)
- **Gris clair**: #F3F4F6 (arrière-plan secondaire)
- **Gris foncé**: #4B5563 (texte secondaire)
- **Noir**: #111827 (texte principal)
- **Vert**: #10B981 (succès)
- **Rouge**: #EF4444 (erreur)
- **Orange**: #F59E0B (avertissement)
