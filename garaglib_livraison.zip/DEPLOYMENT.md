# Documentation de déploiement et d'accès à Garaglib

## Informations générales

**Nom du projet :** Garaglib  
**Description :** Plateforme de réservation de rendez-vous pour garages automobiles  
**Date de livraison :** 21 mai 2025

## Fonctionnalités principales

### Pour les clients
- Recherche de garages par localisation et services
- Consultation des disponibilités en temps réel
- Réservation de créneaux horaires
- Gestion des rendez-vous depuis un espace personnel
- Système d'avis et d'évaluation des garages
- Ajout de garages en favoris

### Pour les garages
- Gestion de planning avec minimum 5 créneaux disponibles
- Tableau de bord avec statistiques et suivi des rendez-vous
- Gestion des services et tarifs
- Acceptation/refus des rendez-vous
- Upload de photos du garage
- Module de devis et portefeuille client
- Réception de notifications pour les nouvelles réservations
- Export des données clients et rendez-vous

### Pour l'administrateur
- Création de garages à distance
- Supervision de tous les garages et utilisateurs
- Accès aux statistiques globales
- Gestion des messages de contact
- Configuration des paramètres système
- Suite de tests fonctionnels et rapports

## Accès administrateur

**Email :** contact@garaglib.com  
**Mot de passe :** Yanisfred11  
**URL d'accès :** https://garaglib.vercel.app/admin/dashboard

## Structure technique

Le projet est construit avec les technologies suivantes :
- **Frontend :** Next.js 14 avec TypeScript et App Router
- **Styles :** TailwindCSS
- **Backend :** Firebase (Authentication, Firestore, Storage)
- **Déploiement :** Vercel

## Instructions de déploiement

### Prérequis
- Compte Vercel
- Compte Firebase
- Node.js 18+ et npm

### Étapes de déploiement

1. Cloner le dépôt :
```bash
git clone https://github.com/votre-organisation/garaglib.git
cd garaglib
```

2. Installer les dépendances :
```bash
npm install
```

3. Configurer les variables d'environnement :
Créer un fichier `.env.local` à la racine du projet avec les informations Firebase :
```
NEXT_PUBLIC_FIREBASE_API_KEY=votre_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=votre_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=votre_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=votre_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=votre_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=votre_app_id
```

4. Tester en local :
```bash
npm run dev
```

5. Déployer sur Vercel :
```bash
npm run build
vercel --prod
```

## Maintenance et mises à jour

### Mise à jour des dépendances
```bash
npm update
```

### Ajout de nouveaux garages
1. Se connecter avec le compte administrateur
2. Accéder à l'URL : `/admin/garages/create`
3. Remplir le formulaire de création de garage
4. Les identifiants seront automatiquement envoyés au garage par email

### Gestion des paiements Stripe
Le lien de paiement Stripe pour les garages est : https://buy.stripe.com/9AQ7uOdyS7Cg05W5kn
Prix du service : 29,99€/mois

## Optimisations et performances

Le site est optimisé pour :
- Chargement rapide des pages
- Expérience responsive sur mobile et desktop
- Synchronisation en temps réel des données
- Mode hors ligne avec resynchronisation
- Accessibilité conforme aux standards WCAG

## Sécurité

- Authentification à 3 rôles (client, garage, admin)
- Contrôle d'accès basé sur les rôles
- Données chiffrées en transit et au repos
- Protection contre les attaques CSRF et XSS
- Validation des entrées utilisateur

## Support et contact

Pour toute question ou assistance, veuillez contacter :
- Email : support@garaglib.com
- Formulaire de contact : https://garaglib.vercel.app/contact
