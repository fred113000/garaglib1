# Guide d'utilisation Garaglib

## Introduction

Bienvenue sur Garaglib, votre plateforme de réservation de rendez-vous pour garages automobiles. Ce guide vous aidera à comprendre et utiliser toutes les fonctionnalités disponibles selon votre rôle (client, garage ou administrateur).

## Pour les clients

### Recherche de garage
1. Accédez à la page d'accueil
2. Utilisez la barre de recherche pour trouver un garage par localisation ou service
3. Filtrez les résultats selon vos besoins (distance, services, évaluations)
4. Consultez les photos et informations des garages

### Réservation de rendez-vous
1. Sélectionnez un garage dans les résultats de recherche
2. Consultez les créneaux disponibles dans le calendrier
3. Choisissez un service et un créneau horaire
4. Renseignez les informations de votre véhicule
5. Confirmez votre réservation
6. Recevez une notification de confirmation ou d'acceptation

### Gestion de votre compte
1. Créez un compte ou connectez-vous
2. Accédez à votre tableau de bord personnel
3. Consultez l'historique de vos rendez-vous
4. Gérez vos véhicules enregistrés
5. Consultez vos garages favoris
6. Vérifiez vos notifications

## Pour les garages

### Configuration initiale
1. Inscrivez-vous via la page "Devenir partenaire"
2. Complétez votre profil avec toutes les informations nécessaires
3. Ajoutez des photos de votre garage
4. Configurez vos services et tarifs

### Gestion des créneaux
1. Accédez à votre tableau de bord garage
2. Allez dans la section "Créneaux disponibles"
3. Ajoutez au moins 5 créneaux disponibles par jour
4. Définissez l'heure de début, la durée et le service associé

### Gestion des rendez-vous
1. Consultez votre agenda dans le tableau de bord
2. Acceptez ou refusez les demandes de rendez-vous
3. Recevez des notifications pour chaque nouvelle demande
4. Marquez les rendez-vous comme terminés une fois effectués

### Gestion des clients
1. Accédez au portefeuille client
2. Consultez l'historique des rendez-vous par client
3. Créez des devis personnalisés
4. Suivez les statistiques par client

## Pour les administrateurs

### Gestion des garages
1. Connectez-vous avec les identifiants administrateur
2. Accédez au tableau de bord administrateur
3. Créez de nouveaux comptes garage
4. Supervisez tous les garages enregistrés

### Supervision du système
1. Consultez les statistiques globales
2. Gérez les messages de contact
3. Exécutez les tests fonctionnels
4. Consultez les rapports de performance

## Fonctionnalités mobiles

Toutes les fonctionnalités sont disponibles sur mobile avec une interface adaptée :
- Navigation simplifiée
- Affichage optimisé pour les petits écrans
- Interactions tactiles améliorées
- Notifications push (si autorisées)

## Support

En cas de problème ou de question, utilisez le formulaire de contact accessible depuis le menu principal ou contactez-nous directement à support@garaglib.com.

---

Merci d'utiliser Garaglib pour la gestion de vos rendez-vous automobiles !
