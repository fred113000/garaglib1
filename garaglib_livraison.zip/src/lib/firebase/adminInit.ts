// src/lib/firebase/adminInit.ts
import { db, auth } from './config';
import { collection, query, where, getDocs, addDoc, doc, setDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';

// Interface pour les données administrateur
export interface AdminData {
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin';
  createdAt: Date;
}

// Fonction pour vérifier si le compte admin par défaut existe
export const checkDefaultAdminExists = async () => {
  try {
    const adminEmail = 'contact@garaglib.com';
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('email', '==', adminEmail), where('role', '==', 'admin'));
    const querySnapshot = await getDocs(q);
    
    return !querySnapshot.empty;
  } catch (error) {
    console.error('Erreur lors de la vérification du compte admin par défaut:', error);
    throw error;
  }
};

// Fonction pour créer le compte admin par défaut
export const createDefaultAdmin = async () => {
  try {
    const adminEmail = 'contact@garaglib.com';
    const adminPassword = 'Yanisfred11';
    
    // Vérifier si le compte admin existe déjà
    const adminExists = await checkDefaultAdminExists();
    
    if (adminExists) {
      console.log('Le compte admin par défaut existe déjà.');
      return true;
    }
    
    // Créer le compte dans Firebase Auth
    const userCredential = await createUserWithEmailAndPassword(auth, adminEmail, adminPassword);
    const user = userCredential.user;
    
    // Ajouter les informations admin dans Firestore
    const adminData: AdminData = {
      email: adminEmail,
      firstName: 'Admin',
      lastName: 'Garaglib',
      role: 'admin',
      createdAt: new Date()
    };
    
    await setDoc(doc(db, 'users', user.uid), adminData);
    
    console.log('Compte admin par défaut créé avec succès.');
    return true;
  } catch (error) {
    console.error('Erreur lors de la création du compte admin par défaut:', error);
    throw error;
  }
};

// Fonction pour se connecter en tant qu'admin
export const loginAsAdmin = async (email: string, password: string) => {
  try {
    // Vérifier si l'utilisateur est un admin
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('email', '==', email), where('role', '==', 'admin'));
    const querySnapshot = await getDocs(q);
    
    if (querySnapshot.empty) {
      throw new Error('Accès non autorisé. Vous n\'avez pas les droits administrateur.');
    }
    
    // Se connecter avec Firebase Auth
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error('Erreur lors de la connexion admin:', error);
    throw error;
  }
};
