// src/lib/firebase/stripe.ts
import { db } from './config';
import { collection, addDoc, updateDoc, doc, getDoc, query, where, getDocs } from 'firebase/firestore';

// Interface pour les données de paiement
export interface PaymentData {
  garageId: string;
  stripePaymentId: string;
  amount: number;
  currency: string;
  status: 'succeeded' | 'failed' | 'pending';
  createdAt: Date;
}

// Interface pour les données d'abonnement
export interface SubscriptionData {
  garageId: string;
  stripeCustomerId: string;
  subscriptionId: string;
  status: 'active' | 'canceled' | 'past_due';
  priceId: string;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  createdAt: Date;
  updatedAt: Date;
}

// Fonction pour enregistrer un nouveau paiement
export const createPayment = async (paymentData: PaymentData) => {
  try {
    const paymentsRef = collection(db, 'payments');
    const docRef = await addDoc(paymentsRef, {
      ...paymentData,
      createdAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement du paiement:', error);
    throw error;
  }
};

// Fonction pour enregistrer un nouvel abonnement
export const createSubscription = async (subscriptionData: SubscriptionData) => {
  try {
    const subscriptionsRef = collection(db, 'subscriptions');
    const docRef = await addDoc(subscriptionsRef, {
      ...subscriptionData,
      createdAt: new Date(),
      updatedAt: new Date()
    });
    return docRef.id;
  } catch (error) {
    console.error('Erreur lors de l\'enregistrement de l\'abonnement:', error);
    throw error;
  }
};

// Fonction pour mettre à jour le statut d'un abonnement
export const updateSubscriptionStatus = async (subscriptionId: string, status: SubscriptionData['status']) => {
  try {
    const subscriptionsRef = collection(db, 'subscriptions');
    const q = query(subscriptionsRef, where('subscriptionId', '==', subscriptionId));
    const querySnapshot = await getDocs(q);
    
    if (!querySnapshot.empty) {
      const docRef = doc(db, 'subscriptions', querySnapshot.docs[0].id);
      await updateDoc(docRef, {
        status,
        updatedAt: new Date()
      });
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Erreur lors de la mise à jour du statut de l\'abonnement:', error);
    throw error;
  }
};

// Fonction pour vérifier si un garage a un abonnement actif
export const hasActiveSubscription = async (garageId: string) => {
  try {
    const subscriptionsRef = collection(db, 'subscriptions');
    const q = query(
      subscriptionsRef, 
      where('garageId', '==', garageId),
      where('status', '==', 'active')
    );
    const querySnapshot = await getDocs(q);
    
    return !querySnapshot.empty;
  } catch (error) {
    console.error('Erreur lors de la vérification de l\'abonnement:', error);
    throw error;
  }
};

// Fonction pour gérer le retour de Stripe après paiement
export const handleStripeRedirect = async (session_id: string) => {
  try {
    // Dans une implémentation réelle, nous vérifierions le statut de la session Stripe
    // via l'API Stripe, mais pour cette démo, nous simulons un paiement réussi
    
    // Simuler un délai pour l'appel API
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Retourner un résultat simulé
    return {
      success: true,
      message: 'Paiement traité avec succès',
      data: {
        session_id,
        payment_status: 'succeeded',
        customer_id: 'cus_' + Math.random().toString(36).substring(2, 15),
        subscription_id: 'sub_' + Math.random().toString(36).substring(2, 15)
      }
    };
  } catch (error) {
    console.error('Erreur lors du traitement du retour Stripe:', error);
    throw error;
  }
};
