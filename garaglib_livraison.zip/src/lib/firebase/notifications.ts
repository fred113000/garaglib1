// src/lib/firebase/notifications.ts
import { 
  collection, 
  addDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  getDocs, 
  doc, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './config';

export type NotificationType = 'info' | 'warning' | 'success' | 'error';

export interface Notification {
  id?: string;
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  isRead: boolean;
  link?: string;
  createdAt?: Date;
}

// Créer une nouvelle notification
export const createNotification = async (notificationData: Omit<Notification, 'id' | 'isRead' | 'createdAt'>): Promise<string> => {
  try {
    const docRef = await addDoc(collection(db, 'notifications'), {
      ...notificationData,
      isRead: false,
      createdAt: serverTimestamp()
    });
    
    return docRef.id;
  } catch (error) {
    console.error('Erreur lors de la création de la notification:', error);
    throw error;
  }
};

// Marquer une notification comme lue
export const markNotificationAsRead = async (notificationId: string): Promise<void> => {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), {
      isRead: true
    });
  } catch (error) {
    console.error('Erreur lors du marquage de la notification comme lue:', error);
    throw error;
  }
};

// Récupérer les notifications d'un utilisateur
export const getUserNotifications = async (userId: string, limit: number = 20): Promise<Notification[]> => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc')
    );
    
    const querySnapshot = await getDocs(q);
    
    const notifications: Notification[] = [];
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      notifications.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt?.toDate()
      } as Notification);
      
      if (notifications.length >= limit) {
        return;
      }
    });
    
    return notifications;
  } catch (error) {
    console.error('Erreur lors de la récupération des notifications:', error);
    throw error;
  }
};

// Créer une notification de réservation
export const createAppointmentNotification = async (
  userId: string, 
  garageId: string, 
  appointmentId: string, 
  serviceName: string, 
  appointmentDate: Date
): Promise<string> => {
  const formattedDate = appointmentDate.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return createNotification({
    userId,
    title: 'Réservation confirmée',
    message: `Votre réservation pour ${serviceName} le ${formattedDate} a été confirmée.`,
    type: 'success',
    link: `/client/appointments/${appointmentId}`
  });
};

// Créer une notification de rappel de rendez-vous
export const createAppointmentReminderNotification = async (
  userId: string, 
  appointmentId: string, 
  serviceName: string, 
  appointmentDate: Date
): Promise<string> => {
  const formattedDate = appointmentDate.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return createNotification({
    userId,
    title: 'Rappel de rendez-vous',
    message: `Rappel : Vous avez rendez-vous pour ${serviceName} demain à ${formattedDate}.`,
    type: 'info',
    link: `/client/appointments/${appointmentId}`
  });
};

// Créer une notification d'annulation de rendez-vous
export const createAppointmentCancellationNotification = async (
  userId: string, 
  garageName: string, 
  serviceName: string, 
  appointmentDate: Date
): Promise<string> => {
  const formattedDate = appointmentDate.toLocaleDateString('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  return createNotification({
    userId,
    title: 'Rendez-vous annulé',
    message: `Votre rendez-vous pour ${serviceName} chez ${garageName} le ${formattedDate} a été annulé.`,
    type: 'warning',
    link: '/client/dashboard'
  });
};
