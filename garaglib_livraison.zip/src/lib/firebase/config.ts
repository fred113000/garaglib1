// src/lib/firebase/config.ts
import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Configuration Firebase
// Note: Dans un environnement de production, ces valeurs devraient être stockées dans des variables d'environnement
const firebaseConfig = {
  apiKey: "AIzaSyDummyApiKey123456789",
  authDomain: "garaglib-demo.firebaseapp.com",
  projectId: "garaglib-demo",
  storageBucket: "garaglib-demo.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abc123def456ghi789jkl"
};

// Initialiser Firebase seulement s'il n'est pas déjà initialisé
const app = !getApps().length ? initializeApp(firebaseConfig) : getApps()[0];

// Exporter les services Firebase
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export default app;
