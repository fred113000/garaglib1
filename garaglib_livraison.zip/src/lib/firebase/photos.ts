// src/lib/firebase/photos.ts
import { db, storage } from './config';
import { collection, addDoc, getDocs, query, where, deleteDoc, doc, updateDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject, listAll } from 'firebase/storage';

// Interface pour les photos de garage
export interface GaragePhoto {
  id?: string;
  garageId: string;
  url: string;
  fileName: string;
  displayOrder: number;
  isMain: boolean;
  createdAt: Date;
}

// Fonction pour uploader une photo de garage
export const uploadGaragePhoto = async (garageId: string, file: File, isMain: boolean = false): Promise<GaragePhoto> => {
  try {
    // Créer une référence unique pour le fichier
    const fileName = `${Date.now()}_${file.name}`;
    const storageRef = ref(storage, `garages/${garageId}/photos/${fileName}`);
    
    // Uploader le fichier
    await uploadBytes(storageRef, file);
    
    // Récupérer l'URL de téléchargement
    const downloadURL = await getDownloadURL(storageRef);
    
    // Déterminer l'ordre d'affichage (les photos principales sont affichées en premier)
    let displayOrder = 0;
    
    if (!isMain) {
      // Récupérer le nombre actuel de photos pour définir l'ordre
      const photosRef = collection(db, 'garagePhotos');
      const q = query(photosRef, where('garageId', '==', garageId));
      const querySnapshot = await getDocs(q);
      displayOrder = querySnapshot.size;
    }
    
    // Si c'est une photo principale, mettre à jour les autres photos pour qu'elles ne soient plus principales
    if (isMain) {
      const photosRef = collection(db, 'garagePhotos');
      const q = query(
        photosRef, 
        where('garageId', '==', garageId),
        where('isMain', '==', true)
      );
      const querySnapshot = await getDocs(q);
      
      querySnapshot.forEach(async (document) => {
        await updateDoc(doc(db, 'garagePhotos', document.id), {
          isMain: false
        });
      });
    }
    
    // Enregistrer les métadonnées dans Firestore
    const photoData: GaragePhoto = {
      garageId,
      url: downloadURL,
      fileName,
      displayOrder,
      isMain,
      createdAt: new Date()
    };
    
    const docRef = await addDoc(collection(db, 'garagePhotos'), photoData);
    
    return {
      ...photoData,
      id: docRef.id
    };
  } catch (error) {
    console.error('Erreur lors de l\'upload de la photo:', error);
    throw error;
  }
};

// Fonction pour récupérer toutes les photos d'un garage
export const getGaragePhotos = async (garageId: string): Promise<GaragePhoto[]> => {
  try {
    const photosRef = collection(db, 'garagePhotos');
    const q = query(
      photosRef,
      where('garageId', '==', garageId)
    );
    
    const querySnapshot = await getDocs(q);
    const photos: GaragePhoto[] = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      photos.push({
        id: doc.id,
        garageId: data.garageId,
        url: data.url,
        fileName: data.fileName,
        displayOrder: data.displayOrder,
        isMain: data.isMain,
        createdAt: data.createdAt.toDate()
      });
    });
    
    // Trier les photos par ordre d'affichage
    return photos.sort((a, b) => {
      // Les photos principales sont toujours en premier
      if (a.isMain) return -1;
      if (b.isMain) return 1;
      
      // Ensuite, trier par ordre d'affichage
      return a.displayOrder - b.displayOrder;
    });
  } catch (error) {
    console.error('Erreur lors de la récupération des photos:', error);
    throw error;
  }
};

// Fonction pour supprimer une photo
export const deleteGaragePhoto = async (photoId: string): Promise<boolean> => {
  try {
    // Récupérer les données de la photo
    const photoDoc = await getDoc(doc(db, 'garagePhotos', photoId));
    
    if (!photoDoc.exists()) {
      throw new Error('Photo non trouvée');
    }
    
    const photoData = photoDoc.data();
    const { garageId, fileName } = photoData;
    
    // Supprimer le fichier du storage
    const storageRef = ref(storage, `garages/${garageId}/photos/${fileName}`);
    await deleteObject(storageRef);
    
    // Supprimer les métadonnées de Firestore
    await deleteDoc(doc(db, 'garagePhotos', photoId));
    
    return true;
  } catch (error) {
    console.error('Erreur lors de la suppression de la photo:', error);
    throw error;
  }
};

// Fonction pour mettre à jour l'ordre d'affichage des photos
export const updatePhotoOrder = async (photos: GaragePhoto[]): Promise<boolean> => {
  try {
    // Mettre à jour l'ordre d'affichage de chaque photo
    const updatePromises = photos.map((photo, index) => {
      if (!photo.id) return Promise.resolve();
      
      return updateDoc(doc(db, 'garagePhotos', photo.id), {
        displayOrder: index,
        isMain: index === 0 // La première photo est toujours la principale
      });
    });
    
    await Promise.all(updatePromises);
    
    return true;
  } catch (error) {
    console.error('Erreur lors de la mise à jour de l\'ordre des photos:', error);
    throw error;
  }
};

// Fonction pour définir une photo comme principale
export const setMainPhoto = async (photoId: string): Promise<boolean> => {
  try {
    // Récupérer les données de la photo
    const photoDoc = await getDoc(doc(db, 'garagePhotos', photoId));
    
    if (!photoDoc.exists()) {
      throw new Error('Photo non trouvée');
    }
    
    const photoData = photoDoc.data();
    const { garageId } = photoData;
    
    // Mettre à jour toutes les photos du garage pour qu'elles ne soient plus principales
    const photosRef = collection(db, 'garagePhotos');
    const q = query(
      photosRef, 
      where('garageId', '==', garageId),
      where('isMain', '==', true)
    );
    const querySnapshot = await getDocs(q);
    
    const updatePromises = querySnapshot.docs.map((doc) => {
      return updateDoc(doc.ref, {
        isMain: false
      });
    });
    
    await Promise.all(updatePromises);
    
    // Définir la photo sélectionnée comme principale
    await updateDoc(doc(db, 'garagePhotos', photoId), {
      isMain: true
    });
    
    return true;
  } catch (error) {
    console.error('Erreur lors de la définition de la photo principale:', error);
    throw error;
  }
};
