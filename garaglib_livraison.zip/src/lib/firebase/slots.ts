// src/lib/firebase/slots.ts
import { db } from './config';
import { collection, addDoc, getDocs, query, where, Timestamp, deleteDoc, doc } from 'firebase/firestore';

// Interface pour les créneaux disponibles
export interface Slot {
  id?: string;
  garageId: string;
  date: Date;
  startTime: string;
  endTime: string;
  serviceId: string;
  isBooked: boolean;
}

// Fonction pour ajouter un créneau disponible
export const addAvailableSlot = async (slot: Slot) => {
  try {
    const slotsRef = collection(db, 'slots');
    const docRef = await addDoc(slotsRef, {
      ...slot,
      date: Timestamp.fromDate(slot.date),
      createdAt: Timestamp.fromDate(new Date())
    });
    return { ...slot, id: docRef.id };
  } catch (error) {
    console.error('Erreur lors de l\'ajout du créneau:', error);
    throw error;
  }
};

// Fonction pour récupérer les créneaux disponibles pour un garage à une date donnée
export const getAvailableSlots = async (garageId: string, date: Date) => {
  try {
    // Convertir la date en début et fin de journée pour la requête
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    const slotsRef = collection(db, 'slots');
    const q = query(
      slotsRef,
      where('garageId', '==', garageId),
      where('date', '>=', Timestamp.fromDate(startOfDay)),
      where('date', '<=', Timestamp.fromDate(endOfDay)),
      where('isBooked', '==', false)
    );
    
    const querySnapshot = await getDocs(q);
    const slots: Slot[] = [];
    
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      slots.push({
        id: doc.id,
        garageId: data.garageId,
        date: data.date.toDate(),
        startTime: data.startTime,
        endTime: data.endTime,
        serviceId: data.serviceId,
        isBooked: data.isBooked
      });
    });
    
    return slots;
  } catch (error) {
    console.error('Erreur lors de la récupération des créneaux:', error);
    throw error;
  }
};

// Fonction pour supprimer un créneau
export const deleteSlot = async (slotId: string) => {
  try {
    await deleteDoc(doc(db, 'slots', slotId));
    return true;
  } catch (error) {
    console.error('Erreur lors de la suppression du créneau:', error);
    throw error;
  }
};

// Fonction pour marquer un créneau comme réservé
export const bookSlot = async (slotId: string) => {
  try {
    const slotRef = doc(db, 'slots', slotId);
    await updateDoc(slotRef, {
      isBooked: true,
      updatedAt: Timestamp.fromDate(new Date())
    });
    return true;
  } catch (error) {
    console.error('Erreur lors de la réservation du créneau:', error);
    throw error;
  }
};

// Fonction pour vérifier si un garage a au moins 5 créneaux disponibles pour une date
export const hasMinimumAvailableSlots = async (garageId: string, date: Date, minimumSlots = 5) => {
  try {
    const slots = await getAvailableSlots(garageId, date);
    return slots.length >= minimumSlots;
  } catch (error) {
    console.error('Erreur lors de la vérification des créneaux minimum:', error);
    throw error;
  }
};
