"use client";

// src/lib/hooks/useAuth.ts
import { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebase/config';
import { getUserData, User } from '../firebase/auth';

interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    loading: true,
    error: null
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(
      auth,
      async (firebaseUser) => {
        try {
          if (firebaseUser) {
            // L'utilisateur est connecté, récupérer ses données
            const userData = await getUserData(firebaseUser.uid);
            setAuthState({
              user: userData,
              loading: false,
              error: null
            });
          } else {
            // L'utilisateur n'est pas connecté
            setAuthState({
              user: null,
              loading: false,
              error: null
            });
          }
        } catch (error) {
          console.error('Erreur lors de la récupération des données utilisateur:', error);
          setAuthState({
            user: null,
            loading: false,
            error: error instanceof Error ? error.message : 'Une erreur est survenue'
          });
        }
      },
      (error) => {
        console.error('Erreur d\'authentification:', error);
        setAuthState({
          user: null,
          loading: false,
          error: error.message
        });
      }
    );

    // Nettoyer l'abonnement lors du démontage du composant
    return () => unsubscribe();
  }, []);

  return authState;
};
