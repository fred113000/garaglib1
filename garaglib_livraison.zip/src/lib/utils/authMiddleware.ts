// src/lib/utils/authMiddleware.ts
import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getUserData, UserRole } from '../firebase/auth';

export async function authMiddleware(
  request: NextRequest,
  allowedRoles: UserRole[] = ['client', 'garage', 'admin']
) {
  // Vérifier si l'utilisateur est connecté
  const session = cookies().get('session')?.value;
  
  if (!session) {
    // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    return NextResponse.redirect(new URL('/login', request.url));
  }
  
  try {
    // Récupérer les données utilisateur
    const userId = session; // Dans un environnement réel, il faudrait décoder le token
    const userData = await getUserData(userId);
    
    if (!userData) {
      // Rediriger vers la page de connexion si l'utilisateur n'existe pas
      return NextResponse.redirect(new URL('/login', request.url));
    }
    
    // Vérifier si l'utilisateur a le rôle requis
    if (!allowedRoles.includes(userData.role)) {
      // Rediriger vers la page d'accueil si l'utilisateur n'a pas le rôle requis
      return NextResponse.redirect(new URL('/', request.url));
    }
    
    // Continuer la requête si l'utilisateur est autorisé
    return NextResponse.next();
  } catch (error) {
    console.error('Erreur dans authMiddleware:', error);
    // Rediriger vers la page de connexion en cas d'erreur
    return NextResponse.redirect(new URL('/login', request.url));
  }
}
