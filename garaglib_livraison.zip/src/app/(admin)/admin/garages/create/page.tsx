"use client";

import { useState } from 'react';
import Link from 'next/link';

export default function CreateGaragePage() {
  const [formData, setFormData] = useState({
    garageName: '',
    ownerFirstName: '',
    ownerLastName: '',
    email: '',
    phone: '',
    address: '',
    zipCode: '',
    city: '',
    siret: '',
    description: '',
    services: [{ name: '', price: '' }],
    password: '',
    confirmPassword: '',
    sendCredentials: true
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState('');
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData(prev => ({ ...prev, [name]: checked }));
  };
  
  const handleServiceChange = (index: number, field: string, value: string) => {
    const updatedServices = [...formData.services];
    updatedServices[index] = { ...updatedServices[index], [field]: value };
    setFormData(prev => ({ ...prev, services: updatedServices }));
  };
  
  const addService = () => {
    setFormData(prev => ({
      ...prev,
      services: [...prev.services, { name: '', price: '' }]
    }));
  };
  
  const removeService = (index: number) => {
    const updatedServices = [...formData.services];
    updatedServices.splice(index, 1);
    setFormData(prev => ({ ...prev, services: updatedServices }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitError('');
    
    // Vérifier que les mots de passe correspondent
    if (formData.password !== formData.confirmPassword) {
      setSubmitError('Les mots de passe ne correspondent pas.');
      setIsSubmitting(false);
      return;
    }
    
    try {
      // Simulation d'envoi du formulaire
      // Dans une implémentation réelle, nous enverrions les données à Firebase
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setSubmitSuccess(true);
      // Réinitialiser le formulaire
      setFormData({
        garageName: '',
        ownerFirstName: '',
        ownerLastName: '',
        email: '',
        phone: '',
        address: '',
        zipCode: '',
        city: '',
        siret: '',
        description: '',
        services: [{ name: '', price: '' }],
        password: '',
        confirmPassword: '',
        sendCredentials: true
      });
    } catch (error) {
      setSubmitError('Une erreur est survenue lors de la création du garage. Veuillez réessayer.');
      console.error('Erreur lors de la création du garage:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Créer un nouveau garage</h1>
        <p className="text-gray-600">Remplissez le formulaire ci-dessous pour créer un compte garage à distance</p>
      </div>
      
      {submitSuccess ? (
        <div className="bg-white rounded-lg shadow-md p-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="bg-green-100 text-green-700 p-4 rounded-full inline-block mb-4">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Garage créé avec succès !</h2>
            <p className="text-gray-600 mb-6">Le garage a été ajouté à la plateforme et peut maintenant être trouvé par les clients.</p>
            
            {formData.sendCredentials && (
              <div className="bg-blue-50 p-4 rounded-md text-left mb-6">
                <p className="text-blue-700 font-medium mb-2">Un email contenant les identifiants de connexion a été envoyé au garage.</p>
                <p className="text-blue-600">Le garage pourra se connecter et compléter son profil.</p>
              </div>
            )}
            
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 mt-6">
              <Link href="/admin/garages/create" className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors">
                Créer un autre garage
              </Link>
              <Link href="/admin/garages" className="bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 font-bold py-2 px-6 rounded-lg transition-colors">
                Voir tous les garages
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 max-w-4xl mx-auto">
          {submitError && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-red-800">Erreur</h3>
                  <div className="mt-2 text-sm text-red-700">
                    <p>{submitError}</p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">Informations du garage</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="garageName" className="block text-sm font-medium text-gray-700 mb-1">Nom du garage *</label>
                <input
                  type="text"
                  id="garageName"
                  name="garageName"
                  value={formData.garageName}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="siret" className="block text-sm font-medium text-gray-700 mb-1">Numéro SIRET *</label>
                <input
                  type="text"
                  id="siret"
                  name="siret"
                  value={formData.siret}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
              ></textarea>
              <p className="text-xs text-gray-500 mt-1">Une brève description du garage qui sera affichée sur sa fiche.</p>
            </div>
            
            <div className="mb-6">
              <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">Adresse *</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">Code postal *</label>
                <input
                  type="text"
                  id="zipCode"
                  name="zipCode"
                  value={formData.zipCode}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
              
              <div className="md:col-span-2">
                <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">Ville *</label>
                <input
                  type="text"
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">Services proposés</h2>
            
            <div className="space-y-4 mb-4">
              {formData.services.map((service, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <div className="flex-grow">
                    <label htmlFor={`serviceName${index}`} className="block text-sm font-medium text-gray-700 mb-1">Nom du service</label>
                    <input
                      type="text"
                      id={`serviceName${index}`}
                      value={service.name}
                      onChange={(e) => handleServiceChange(index, 'name', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                      placeholder="ex: Vidange"
                    />
                  </div>
                  
                  <div className="w-32">
                    <label htmlFor={`servicePrice${index}`} className="block text-sm font-medium text-gray-700 mb-1">Prix (€)</label>
                    <input
                      type="text"
                      id={`servicePrice${index}`}
                      value={service.price}
                      onChange={(e) => handleServiceChange(index, 'price', e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                      placeholder="ex: 59.99"
                    />
                  </div>
                  
                  <div className="flex items-end pb-1">
                    <button
                      type="button"
                      onClick={() => removeService(index)}
                      className="text-red-500 hover:text-red-700"
                      disabled={formData.services.length === 1}
                    >
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
            
            <button
              type="button"
              onClick={addService}
              className="flex items-center text-primary hover:text-primary-dark"
            >
              <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              Ajouter un service
            </button>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">Informations du propriétaire</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="ownerFirstName" className="block text-sm font-medium text-gray-700 mb-1">Prénom *</label>
                <input
                  type="text"
                  id="ownerFirstName"
                  name="ownerFirstName"
                  value={formData.ownerFirstName}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="ownerLastName" className="block text-sm font-medium text-gray-700 mb-1">Nom *</label>
                <input
                  type="text"
                  id="ownerLastName"
                  name="ownerLastName"
                  value={formData.ownerLastName}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Téléphone *</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-800 mb-4 pb-2 border-b">Informations de connexion</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Mot de passe *</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">Confirmer le mot de passe *</label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
                  required
                />
              </div>
            </div>
            
            <div className="flex items-start mb-6">
              <div className="flex items-center h-5">
                <input
                  id="sendCredentials"
                  name="sendCredentials"
                  type="checkbox"
                  checked={formData.sendCredentials}
                  onChange={handleCheckboxChange}
                  className="focus:ring-primary h-4 w-4 text-primary border-gray-300 rounded"
                />
              </div>
              <div className="ml-3 text-sm">
                <label htmlFor="sendCredentials" className="font-medium text-gray-700">
                  Envoyer les identifiants de connexion par email
                </label>
                <p className="text-gray-500">Un email contenant les identifiants de connexion sera envoyé au garage.</p>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-4">
            <Link
              href="/admin/garages"
              className="bg-white hover:bg-gray-100 text-gray-800 font-bold py-2 px-6 rounded-lg border border-gray-300 transition-colors"
            >
              Annuler
            </Link>
            
            <button
              type="submit"
              disabled={isSubmitting}
              className={`bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors ${isSubmitting ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {isSubmitting ? 'Création en cours...' : 'Créer le garage'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
