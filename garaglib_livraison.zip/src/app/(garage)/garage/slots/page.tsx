// src/app/(garage)/garage/slots/page.tsx
import Navbar from '@/components/ui/Navbar';

export default function GarageSlots() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Gestion des créneaux disponibles</h1>
        
        <div className="grid md:grid-cols-3 gap-6">
          {/* Calendrier et sélection de date */}
          <div className="card col-span-1">
            <h2 className="text-xl font-semibold mb-4">Calendrier</h2>
            <div className="bg-white rounded-lg overflow-hidden">
              <div className="flex items-center justify-between p-4 border-b">
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <h3 className="font-medium">Mai 2025</h3>
                <button className="p-2 hover:bg-gray-100 rounded-full">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              <div className="grid grid-cols-7 gap-1 p-4">
                <div className="text-center text-gray-500 text-sm py-1">Lu</div>
                <div className="text-center text-gray-500 text-sm py-1">Ma</div>
                <div className="text-center text-gray-500 text-sm py-1">Me</div>
                <div className="text-center text-gray-500 text-sm py-1">Je</div>
                <div className="text-center text-gray-500 text-sm py-1">Ve</div>
                <div className="text-center text-gray-500 text-sm py-1">Sa</div>
                <div className="text-center text-gray-500 text-sm py-1">Di</div>
                
                <div className="text-center text-gray-400 py-2">28</div>
                <div className="text-center text-gray-400 py-2">29</div>
                <div className="text-center text-gray-400 py-2">30</div>
                <div className="text-center py-2">1</div>
                <div className="text-center py-2">2</div>
                <div className="text-center py-2">3</div>
                <div className="text-center py-2">4</div>
                
                <div className="text-center py-2">5</div>
                <div className="text-center py-2">6</div>
                <div className="text-center py-2">7</div>
                <div className="text-center py-2">8</div>
                <div className="text-center py-2">9</div>
                <div className="text-center py-2">10</div>
                <div className="text-center py-2">11</div>
                
                <div className="text-center py-2">12</div>
                <div className="text-center py-2">13</div>
                <div className="text-center py-2">14</div>
                <div className="text-center py-2">15</div>
                <div className="text-center py-2">16</div>
                <div className="text-center py-2">17</div>
                <div className="text-center py-2">18</div>
                
                <div className="text-center py-2">19</div>
                <div className="text-center py-2">20</div>
                <div className="text-center bg-primary text-white rounded-full py-2">21</div>
                <div className="text-center py-2">22</div>
                <div className="text-center py-2">23</div>
                <div className="text-center py-2">24</div>
                <div className="text-center py-2">25</div>
                
                <div className="text-center py-2">26</div>
                <div className="text-center py-2">27</div>
                <div className="text-center py-2">28</div>
                <div className="text-center py-2">29</div>
                <div className="text-center py-2">30</div>
                <div className="text-center py-2">31</div>
                <div className="text-center text-gray-400 py-2">1</div>
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="font-medium mb-2">Légende</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-primary rounded-full mr-2"></div>
                  <span className="text-sm">Jour sélectionné</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-green-100 border border-green-500 rounded-full mr-2"></div>
                  <span className="text-sm">Créneaux disponibles</span>
                </div>
                <div className="flex items-center">
                  <div className="w-4 h-4 bg-red-100 border border-red-500 rounded-full mr-2"></div>
                  <span className="text-sm">Jour complet</span>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <h3 className="font-medium mb-2">Horaires d'ouverture</h3>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Lundi - Vendredi</span>
                  <span className="text-sm font-medium">08:00 - 18:00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Samedi</span>
                  <span className="text-sm font-medium">09:00 - 16:00</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm">Dimanche</span>
                  <span className="text-sm font-medium">Fermé</span>
                </div>
              </div>
              <button className="w-full mt-4 text-sm text-primary hover:text-primary-light transition-colors">
                Modifier les horaires d'ouverture
              </button>
            </div>
          </div>
          
          {/* Gestion des créneaux */}
          <div className="card col-span-2">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Créneaux du 21 mai 2025</h2>
              <div className="flex space-x-2">
                <button className="text-sm px-3 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                  Jour précédent
                </button>
                <button className="text-sm px-3 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                  Jour suivant
                </button>
              </div>
            </div>
            
            <div className="bg-white rounded-lg border p-4 mb-6">
              <h3 className="font-medium mb-3">Créneaux rapides</h3>
              <div className="flex flex-wrap gap-2">
                <button className="px-3 py-1 bg-primary text-white rounded hover:bg-primary-light transition-colors">
                  Ajouter 5 créneaux standards
                </button>
                <button className="px-3 py-1 border border-primary text-primary rounded hover:bg-primary hover:text-white transition-colors">
                  Copier depuis jour précédent
                </button>
                <button className="px-3 py-1 border border-primary text-primary rounded hover:bg-primary hover:text-white transition-colors">
                  Appliquer à toute la semaine
                </button>
              </div>
            </div>
            
            <div className="space-y-4">
              {/* Créneau 1 */}
              <div className="bg-white rounded-lg border p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Créneau #1</h3>
                  <div className="flex items-center">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mr-2">Disponible</span>
                    <button className="text-gray-500 hover:text-error transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Heure de début</label>
                    <select className="input w-full">
                      <option>08:00</option>
                      <option>08:30</option>
                      <option>09:00</option>
                      <option selected>09:30</option>
                      <option>10:00</option>
                      <option>10:30</option>
                      <option>11:00</option>
                      <option>11:30</option>
                      <option>12:00</option>
                      <option>12:30</option>
                      <option>13:00</option>
                      <option>13:30</option>
                      <option>14:00</option>
                      <option>14:30</option>
                      <option>15:00</option>
                      <option>15:30</option>
                      <option>16:00</option>
                      <option>16:30</option>
                      <option>17:00</option>
                      <option>17:30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                    <select className="input w-full">
                      <option>30 minutes</option>
                      <option selected>60 minutes</option>
                      <option>90 minutes</option>
                      <option>120 minutes</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                    <select className="input w-full">
                      <option>Tous les services</option>
                      <option selected>Révision complète</option>
                      <option>Changement de pneus</option>
                      <option>Vidange</option>
                      <option>Diagnostic électronique</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Créneau 2 */}
              <div className="bg-white rounded-lg border p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Créneau #2</h3>
                  <div className="flex items-center">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mr-2">Disponible</span>
                    <button className="text-gray-500 hover:text-error transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Heure de début</label>
                    <select className="input w-full">
                      <option>08:00</option>
                      <option>08:30</option>
                      <option>09:00</option>
                      <option>09:30</option>
                      <option>10:00</option>
                      <option>10:30</option>
                      <option selected>11:00</option>
                      <option>11:30</option>
                      <option>12:00</option>
                      <option>12:30</option>
                      <option>13:00</option>
                      <option>13:30</option>
                      <option>14:00</option>
                      <option>14:30</option>
                      <option>15:00</option>
                      <option>15:30</option>
                      <option>16:00</option>
                      <option>16:30</option>
                      <option>17:00</option>
                      <option>17:30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                    <select className="input w-full">
                      <option>30 minutes</option>
                      <option selected>60 minutes</option>
                      <option>90 minutes</option>
                      <option>120 minutes</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                    <select className="input w-full">
                      <option>Tous les services</option>
                      <option>Révision complète</option>
                      <option selected>Changement de pneus</option>
                      <option>Vidange</option>
                      <option>Diagnostic électronique</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Créneau 3 */}
              <div className="bg-white rounded-lg border p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Créneau #3</h3>
                  <div className="flex items-center">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mr-2">Disponible</span>
                    <button className="text-gray-500 hover:text-error transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Heure de début</label>
                    <select className="input w-full">
                      <option>08:00</option>
                      <option>08:30</option>
                      <option>09:00</option>
                      <option>09:30</option>
                      <option>10:00</option>
                      <option>10:30</option>
                      <option>11:00</option>
                      <option>11:30</option>
                      <option>12:00</option>
                      <option>12:30</option>
                      <option>13:00</option>
                      <option>13:30</option>
                      <option selected>14:00</option>
                      <option>14:30</option>
                      <option>15:00</option>
                      <option>15:30</option>
                      <option>16:00</option>
                      <option>16:30</option>
                      <option>17:00</option>
                      <option>17:30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                    <select className="input w-full">
                      <option>30 minutes</option>
                      <option>60 minutes</option>
                      <option selected>90 minutes</option>
                      <option>120 minutes</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                    <select className="input w-full">
                      <option>Tous les services</option>
                      <option selected>Révision complète</option>
                      <option>Changement de pneus</option>
                      <option>Vidange</option>
                      <option>Diagnostic électronique</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Créneau 4 */}
              <div className="bg-white rounded-lg border p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Créneau #4</h3>
                  <div className="flex items-center">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mr-2">Disponible</span>
                    <button className="text-gray-500 hover:text-error transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Heure de début</label>
                    <select className="input w-full">
                      <option>08:00</option>
                      <option>08:30</option>
                      <option>09:00</option>
                      <option>09:30</option>
                      <option>10:00</option>
                      <option>10:30</option>
                      <option>11:00</option>
                      <option>11:30</option>
                      <option>12:00</option>
                      <option>12:30</option>
                      <option>13:00</option>
                      <option>13:30</option>
                      <option>14:00</option>
                      <option>14:30</option>
                      <option>15:00</option>
                      <option selected>15:30</option>
                      <option>16:00</option>
                      <option>16:30</option>
                      <option>17:00</option>
                      <option>17:30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                    <select className="input w-full">
                      <option selected>30 minutes</option>
                      <option>60 minutes</option>
                      <option>90 minutes</option>
                      <option>120 minutes</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                    <select className="input w-full">
                      <option>Tous les services</option>
                      <option>Révision complète</option>
                      <option>Changement de pneus</option>
                      <option selected>Vidange</option>
                      <option>Diagnostic électronique</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Créneau 5 */}
              <div className="bg-white rounded-lg border p-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">Créneau #5</h3>
                  <div className="flex items-center">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mr-2">Disponible</span>
                    <button className="text-gray-500 hover:text-error transition-colors">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Heure de début</label>
                    <select className="input w-full">
                      <option>08:00</option>
                      <option>08:30</option>
                      <option>09:00</option>
                      <option>09:30</option>
                      <option>10:00</option>
                      <option>10:30</option>
                      <option>11:00</option>
                      <option>11:30</option>
                      <option>12:00</option>
                      <option>12:30</option>
                      <option>13:00</option>
                      <option>13:30</option>
                      <option>14:00</option>
                      <option>14:30</option>
                      <option>15:00</option>
                      <option>15:30</option>
                      <option>16:00</option>
                      <option selected>16:30</option>
                      <option>17:00</option>
                      <option>17:30</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Durée</label>
                    <select className="input w-full">
                      <option>30 minutes</option>
                      <option selected>60 minutes</option>
                      <option>90 minutes</option>
                      <option>120 minutes</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                    <select className="input w-full">
                      <option>Tous les services</option>
                      <option>Révision complète</option>
                      <option>Changement de pneus</option>
                      <option>Vidange</option>
                      <option selected>Diagnostic électronique</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Ajouter un créneau */}
              <button className="w-full py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:text-primary hover:border-primary transition-colors flex items-center justify-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
                Ajouter un créneau
              </button>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                Enregistrer les modifications
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
