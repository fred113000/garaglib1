// src/app/(garage)/garage/dashboard/page.tsx
import Navbar from '@/components/ui/Navbar';

export default function GarageDashboard() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Tableau de bord garage</h1>
        
        <div className="grid md:grid-cols-3 gap-6">
          {/* Statistiques */}
          <div className="card col-span-3 md:col-span-1">
            <h2 className="text-xl font-semibold mb-4">Statistiques</h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Rendez-vous aujourd'hui</p>
                <p className="text-2xl font-bold text-primary">8</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Rendez-vous cette semaine</p>
                <p className="text-2xl font-bold text-success">32</p>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Taux d'occupation</p>
                <p className="text-2xl font-bold text-warning">78%</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Nouveaux clients</p>
                <p className="text-2xl font-bold text-purple-600">12</p>
              </div>
            </div>
          </div>
          
          {/* Rendez-vous du jour */}
          <div className="card col-span-3 md:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Rendez-vous du jour</h2>
            <div className="space-y-4">
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">Martin Dupont</h3>
                      <span className="ml-2 px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full">Confirmé</span>
                    </div>
                    <p className="text-sm text-gray-600">Révision complète - Renault Clio (AB-123-CD)</p>
                    <p className="text-sm font-medium mt-2">09:30 - 11:00</p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-sm px-3 py-1 border border-success text-success rounded hover:bg-success hover:text-white transition-colors">
                      Terminé
                    </button>
                    <button className="text-sm px-3 py-1 border border-error text-error rounded hover:bg-error hover:text-white transition-colors">
                      Annuler
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">Sophie Laurent</h3>
                      <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-800 text-xs rounded-full">En cours</span>
                    </div>
                    <p className="text-sm text-gray-600">Changement de pneus - Peugeot 308 (EF-456-GH)</p>
                    <p className="text-sm font-medium mt-2">11:30 - 12:30</p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-sm px-3 py-1 border border-success text-success rounded hover:bg-success hover:text-white transition-colors">
                      Terminé
                    </button>
                    <button className="text-sm px-3 py-1 border border-error text-error rounded hover:bg-error hover:text-white transition-colors">
                      Annuler
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center">
                      <h3 className="font-medium">Jean Moreau</h3>
                      <span className="ml-2 px-2 py-0.5 bg-yellow-100 text-yellow-800 text-xs rounded-full">En attente</span>
                    </div>
                    <p className="text-sm text-gray-600">Diagnostic électronique - Citroën C3 (IJ-789-KL)</p>
                    <p className="text-sm font-medium mt-2">14:00 - 15:00</p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="text-sm px-3 py-1 border border-primary text-primary rounded hover:bg-primary hover:text-white transition-colors">
                      Confirmer
                    </button>
                    <button className="text-sm px-3 py-1 border border-error text-error rounded hover:bg-error hover:text-white transition-colors">
                      Annuler
                    </button>
                  </div>
                </div>
              </div>
              
              <button className="w-full py-2 text-center text-primary hover:text-primary-light transition-colors">
                Voir tous les rendez-vous
              </button>
            </div>
          </div>
        </div>
        
        {/* Planning hebdomadaire */}
        <div className="card mt-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Planning hebdomadaire</h2>
            <div className="flex space-x-2">
              <button className="text-sm px-3 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                &lt; Semaine précédente
              </button>
              <button className="text-sm px-3 py-1 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
                Semaine suivante &gt;
              </button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Heure
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Lundi
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Mardi
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Mercredi
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Jeudi
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vendredi
                  </th>
                  <th scope="col" className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Samedi
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-2 py-4 whitespace-nowrap text-sm text-gray-900">
                    09:00
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-green-100 text-green-800 rounded">Révision</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-blue-100 text-blue-800 rounded">Pneus</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-purple-100 text-purple-800 rounded">Vidange</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-yellow-100 text-yellow-800 rounded">Diagnostic</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-green-100 text-green-800 rounded">Révision</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-red-100 text-red-800 rounded">Freins</div>
                  </td>
                </tr>
                <tr>
                  <td className="px-2 py-4 whitespace-nowrap text-sm text-gray-900">
                    10:00
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-green-100 text-green-800 rounded">Révision</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-blue-100 text-blue-800 rounded">Pneus</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-yellow-100 text-yellow-800 rounded">Diagnostic</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-green-100 text-green-800 rounded">Révision</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-red-100 text-red-800 rounded">Freins</div>
                  </td>
                </tr>
                <tr>
                  <td className="px-2 py-4 whitespace-nowrap text-sm text-gray-900">
                    11:00
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-purple-100 text-purple-800 rounded">Vidange</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                  <td className="px-2 py-4 whitespace-nowrap">
                    <div className="text-xs p-1 bg-gray-100 text-gray-800 rounded">Disponible</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Services */}
        <div className="card mt-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Mes services</h2>
            <button className="text-sm px-3 py-1 bg-primary text-white rounded hover:bg-primary-light transition-colors">
              Ajouter un service
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Service
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Durée
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prix
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Catégorie
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Statut
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Révision complète</div>
                    <div className="text-sm text-gray-500">Contrôle des points essentiels</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">90 min</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">120 €</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">Entretien</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Actif
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-primary hover:text-primary-light mr-3">Modifier</button>
                    <button className="text-error hover:text-red-700">Désactiver</button>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Changement de pneus</div>
                    <div className="text-sm text-gray-500">Remplacement des 4 pneus</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">60 min</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">80 €</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">Pneumatiques</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Actif
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className="text-primary hover:text-primary-light mr-3">Modifier</button>
                    <button className="text-error hover:text-red-700">Désactiver</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  );
}
