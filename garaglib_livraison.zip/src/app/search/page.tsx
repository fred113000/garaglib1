// src/app/search/page.tsx
import Navbar from '@/components/ui/Navbar';
import Link from 'next/link';

export default function SearchPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Rechercher un garage</h1>
        
        <div className="grid md:grid-cols-4 gap-6">
          {/* Filtres de recherche */}
          <div className="card md:col-span-1">
            <h2 className="text-xl font-semibold mb-4">Filtres</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">Localisation</label>
                <input type="text" id="location" placeholder="Ville, code postal..." className="input w-full" />
              </div>
              
              <div>
                <label htmlFor="service" className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                <select id="service" className="input w-full">
                  <option value="">Tous les services</option>
                  <option value="revision">Révision</option>
                  <option value="pneus">Changement de pneus</option>
                  <option value="vidange">Vidange</option>
                  <option value="freins">Freins</option>
                  <option value="diagnostic">Diagnostic</option>
                </select>
              </div>
              
              <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input type="date" id="date" className="input w-full" />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Note minimum</label>
                <div className="flex text-yellow-400">
                  <svg className="w-6 h-6 cursor-pointer" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                  <svg className="w-6 h-6 cursor-pointer" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                  <svg className="w-6 h-6 cursor-pointer" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                  <svg className="w-6 h-6 cursor-pointer text-gray-300" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                  <svg className="w-6 h-6 cursor-pointer text-gray-300" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Distance maximum</label>
                <input type="range" min="1" max="50" className="w-full" />
                <div className="flex justify-between text-xs text-gray-500">
                  <span>1 km</span>
                  <span>25 km</span>
                  <span>50 km</span>
                </div>
              </div>
              
              <button className="w-full py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                Appliquer les filtres
              </button>
            </div>
          </div>
          
          {/* Résultats de recherche */}
          <div className="md:col-span-3">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Résultats (15)</h2>
              <select className="input">
                <option value="relevance">Pertinence</option>
                <option value="rating">Note</option>
                <option value="distance">Distance</option>
                <option value="price">Prix</option>
              </select>
            </div>
            
            <div className="space-y-4">
              {/* Résultat 1 */}
              <div className="card hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/4 mb-4 md:mb-0 md:mr-4">
                    <div className="bg-gray-200 h-40 rounded-md"></div>
                  </div>
                  <div className="md:w-3/4">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-semibold">Garage Martin</h3>
                      <div className="flex items-center">
                        <div className="flex text-yellow-400 mr-1">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                          </svg>
                        </div>
                        <span className="font-medium">4.8</span>
                        <span className="text-gray-500 text-sm ml-1">(32 avis)</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mt-1">Paris, 75016 - 2.3 km</p>
                    
                    <div className="mt-3">
                      <h4 className="font-medium">Services populaires:</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Révision complète</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Changement de pneus</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Vidange</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-600">Prochain créneau disponible:</p>
                        <p className="font-medium">Aujourd'hui à 14:30</p>
                      </div>
                      <Link href="/booking/garage-martin" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                        Réserver
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Résultat 2 */}
              <div className="card hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/4 mb-4 md:mb-0 md:mr-4">
                    <div className="bg-gray-200 h-40 rounded-md"></div>
                  </div>
                  <div className="md:w-3/4">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-semibold">Auto Express</h3>
                      <div className="flex items-center">
                        <div className="flex text-yellow-400 mr-1">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                          </svg>
                        </div>
                        <span className="font-medium">4.2</span>
                        <span className="text-gray-500 text-sm ml-1">(18 avis)</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mt-1">Paris, 75011 - 3.7 km</p>
                    
                    <div className="mt-3">
                      <h4 className="font-medium">Services populaires:</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Diagnostic électronique</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Freins</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Climatisation</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-600">Prochain créneau disponible:</p>
                        <p className="font-medium">Demain à 09:15</p>
                      </div>
                      <Link href="/booking/auto-express" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                        Réserver
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Résultat 3 */}
              <div className="card hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row">
                  <div className="md:w-1/4 mb-4 md:mb-0 md:mr-4">
                    <div className="bg-gray-200 h-40 rounded-md"></div>
                  </div>
                  <div className="md:w-3/4">
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-semibold">Garage Central</h3>
                      <div className="flex items-center">
                        <div className="flex text-yellow-400 mr-1">
                          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                          </svg>
                        </div>
                        <span className="font-medium">4.5</span>
                        <span className="text-gray-500 text-sm ml-1">(24 avis)</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mt-1">Paris, 75008 - 1.8 km</p>
                    
                    <div className="mt-3">
                      <h4 className="font-medium">Services populaires:</h4>
                      <div className="flex flex-wrap gap-2 mt-1">
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Révision complète</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Vidange</span>
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-sm rounded-full">Batterie</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-600">Prochain créneau disponible:</p>
                        <p className="font-medium">Aujourd'hui à 16:45</p>
                      </div>
                      <Link href="/booking/garage-central" className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                        Réserver
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Pagination */}
              <div className="flex justify-center mt-8">
                <nav className="flex items-center space-x-2">
                  <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                    &lt;
                  </button>
                  <button className="px-3 py-1 rounded-md bg-primary text-white">
                    1
                  </button>
                  <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                    2
                  </button>
                  <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                    3
                  </button>
                  <span className="px-3 py-1">...</span>
                  <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                    8
                  </button>
                  <button className="px-3 py-1 rounded-md bg-gray-100 text-gray-700 hover:bg-gray-200 transition-colors">
                    &gt;
                  </button>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
