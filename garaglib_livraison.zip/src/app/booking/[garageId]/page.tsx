// src/app/booking/[garageId]/page.tsx
import Navbar from '@/components/ui/Navbar';
import Link from 'next/link';

export default function BookingPage({ params }: { params: { garageId: string } }) {
  // Dans une implémentation réelle, nous récupérerions les données du garage et des créneaux depuis Firebase
  const garageId = params.garageId;
  
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/search" className="text-primary hover:text-primary-light transition-colors flex items-center">
            <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Retour aux résultats de recherche
          </Link>
        </div>
        
        <h1 className="text-3xl font-bold mb-6">Réservation - Garage {garageId.replace(/-/g, ' ')}</h1>
        
        <div className="grid md:grid-cols-3 gap-6">
          {/* Informations du garage */}
          <div className="card md:col-span-1">
            <div className="bg-gray-200 h-48 rounded-md mb-4"></div>
            
            <h2 className="text-xl font-semibold mb-2">Garage {garageId.replace(/-/g, ' ')}</h2>
            
            <div className="flex items-center mb-4">
              <div className="flex text-yellow-400 mr-1">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
              </div>
              <span className="font-medium">4.8</span>
              <span className="text-gray-500 text-sm ml-1">(32 avis)</span>
            </div>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-start">
                <svg className="w-5 h-5 text-gray-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                <div>
                  <p className="text-gray-800">123 Avenue des Champs-Élysées</p>
                  <p className="text-gray-800">75008 Paris</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <svg className="w-5 h-5 text-gray-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <p className="text-gray-800">01 23 45 67 89</p>
              </div>
              
              <div className="flex items-start">
                <svg className="w-5 h-5 text-gray-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <p className="text-gray-800">contact@garage-{garageId}.fr</p>
              </div>
            </div>
            
            <div className="border-t pt-4">
              <h3 className="font-medium mb-2">Horaires d'ouverture</h3>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-sm">Lundi - Vendredi</span>
                  <span className="text-sm">08:00 - 18:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Samedi</span>
                  <span className="text-sm">09:00 - 16:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Dimanche</span>
                  <span className="text-sm">Fermé</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Processus de réservation */}
          <div className="md:col-span-2">
            <div className="card mb-6">
              <h2 className="text-xl font-semibold mb-4">1. Sélectionnez un service</h2>
              
              <div className="space-y-3">
                <div className="border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors bg-blue-50 border-primary">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-medium">Révision complète</h3>
                      <p className="text-sm text-gray-600 mt-1">Contrôle des points essentiels de votre véhicule</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">120 €</p>
                      <p className="text-sm text-gray-600">Durée: 90 min</p>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-medium">Changement de pneus</h3>
                      <p className="text-sm text-gray-600 mt-1">Remplacement des 4 pneus</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">80 €</p>
                      <p className="text-sm text-gray-600">Durée: 60 min</p>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-medium">Vidange</h3>
                      <p className="text-sm text-gray-600 mt-1">Changement d'huile et du filtre</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">60 €</p>
                      <p className="text-sm text-gray-600">Durée: 30 min</p>
                    </div>
                  </div>
                </div>
                
                <div className="border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-medium">Diagnostic électronique</h3>
                      <p className="text-sm text-gray-600 mt-1">Analyse complète des systèmes électroniques</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">50 €</p>
                      <p className="text-sm text-gray-600">Durée: 60 min</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="card mb-6">
              <h2 className="text-xl font-semibold mb-4">2. Choisissez une date</h2>
              
              <div className="grid grid-cols-7 gap-2 mb-6">
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Lun</p>
                  <p className="text-sm text-gray-500 mb-1">20</p>
                  <button className="w-full py-2 rounded-md border hover:border-primary transition-colors">
                    <span className="text-xs text-gray-500">3 créneaux</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Mar</p>
                  <p className="text-sm text-gray-500 mb-1">21</p>
                  <button className="w-full py-2 rounded-md bg-primary text-white">
                    <span className="text-xs">5 créneaux</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Mer</p>
                  <p className="text-sm text-gray-500 mb-1">22</p>
                  <button className="w-full py-2 rounded-md border hover:border-primary transition-colors">
                    <span className="text-xs text-gray-500">2 créneaux</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Jeu</p>
                  <p className="text-sm text-gray-500 mb-1">23</p>
                  <button className="w-full py-2 rounded-md border hover:border-primary transition-colors">
                    <span className="text-xs text-gray-500">4 créneaux</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Ven</p>
                  <p className="text-sm text-gray-500 mb-1">24</p>
                  <button className="w-full py-2 rounded-md border hover:border-primary transition-colors">
                    <span className="text-xs text-gray-500">1 créneau</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Sam</p>
                  <p className="text-sm text-gray-500 mb-1">25</p>
                  <button className="w-full py-2 rounded-md border hover:border-primary transition-colors">
                    <span className="text-xs text-gray-500">5 créneaux</span>
                  </button>
                </div>
                
                <div className="text-center">
                  <p className="text-sm font-medium mb-1">Dim</p>
                  <p className="text-sm text-gray-500 mb-1">26</p>
                  <button className="w-full py-2 rounded-md border bg-gray-100" disabled>
                    <span className="text-xs text-gray-400">Fermé</span>
                  </button>
                </div>
              </div>
              
              <h3 className="font-medium mb-3">Créneaux disponibles pour le 21 mai 2025</h3>
              
              <div className="grid grid-cols-3 gap-2">
                <button className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center">
                  09:30
                </button>
                <button className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center">
                  11:00
                </button>
                <button className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center">
                  14:00
                </button>
                <button className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center">
                  15:30
                </button>
                <button className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center">
                  16:30
                </button>
              </div>
            </div>
            
            <div className="card mb-6">
              <h2 className="text-xl font-semibold mb-4">3. Informations sur votre véhicule</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label htmlFor="make" className="block text-sm font-medium text-gray-700 mb-1">Marque</label>
                  <input type="text" id="make" className="input w-full" placeholder="Ex: Renault" />
                </div>
                
                <div>
                  <label htmlFor="model" className="block text-sm font-medium text-gray-700 mb-1">Modèle</label>
                  <input type="text" id="model" className="input w-full" placeholder="Ex: Clio" />
                </div>
                
                <div>
                  <label htmlFor="year" className="block text-sm font-medium text-gray-700 mb-1">Année</label>
                  <input type="number" id="year" className="input w-full" placeholder="Ex: 2018" />
                </div>
                
                <div>
                  <label htmlFor="licensePlate" className="block text-sm font-medium text-gray-700 mb-1">Immatriculation</label>
                  <input type="text" id="licensePlate" className="input w-full" placeholder="Ex: AB-123-CD" />
                </div>
              </div>
              
              <div>
                <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">Notes additionnelles (optionnel)</label>
                <textarea id="notes" rows={3} className="input w-full" placeholder="Informations supplémentaires pour le garagiste..."></textarea>
              </div>
            </div>
            
            <div className="card">
              <h2 className="text-xl font-semibold mb-4">4. Récapitulatif</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between pb-4 border-b">
                  <div>
                    <p className="font-medium">Service</p>
                    <p className="text-gray-600">Révision complète</p>
                  </div>
                  <p className="font-medium">120 €</p>
                </div>
                
                <div className="flex justify-between pb-4 border-b">
                  <div>
                    <p className="font-medium">Date et heure</p>
                    <p className="text-gray-600">Mardi 21 mai 2025, 09:30</p>
                  </div>
                  <p className="font-medium">90 min</p>
                </div>
                
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">Véhicule</p>
                    <p className="text-gray-600">À renseigner</p>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between items-center font-medium text-lg pb-4 mb-6 border-b">
                <p>Total</p>
                <p>120 €</p>
              </div>
              
              <div className="flex justify-end">
                <button className="px-6 py-3 bg-primary text-white rounded-md hover:bg-primary-light transition-colors">
                  Confirmer la réservation
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
