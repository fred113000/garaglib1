// src/app/admin/deploy/page.tsx
"use client";

import { useState } from 'react';
import Link from 'next/link';

export default function DeployPage() {
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentComplete, setDeploymentComplete] = useState(false);
  const [deploymentUrl, setDeploymentUrl] = useState('');
  const [deploymentError, setDeploymentError] = useState('');

  const handleDeploy = async () => {
    setIsDeploying(true);
    setDeploymentError('');
    
    try {
      // Simuler un déploiement
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Simuler une URL de déploiement
      setDeploymentUrl('https://garaglib.vercel.app');
      setDeploymentComplete(true);
    } catch (error) {
      console.error('Erreur lors du déploiement:', error);
      setDeploymentError('Une erreur est survenue lors du déploiement. Veuillez réessayer.');
    } finally {
      setIsDeploying(false);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Déploiement de Garaglib</h1>
        <p className="text-gray-600">Déployez votre site Garaglib en production</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        {!deploymentComplete ? (
          <div>
            <div className="text-center mb-8">
              <div className="bg-blue-100 p-4 rounded-full inline-block mb-4">
                <svg className="w-16 h-16 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 11l7-7 7 7M5 19l7-7 7 7" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Prêt pour le déploiement</h2>
              <p className="text-gray-600 mb-6">Toutes les fonctionnalités ont été validées et sont prêtes à être déployées.</p>
            </div>
            
            {deploymentError && (
              <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-6">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <svg className="h-5 w-5 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-red-800">Erreur de déploiement</h3>
                    <div className="mt-2 text-sm text-red-700">
                      <p>{deploymentError}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-semibold mb-4">Récapitulatif des fonctionnalités</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Inscription garage avec page commerciale</span>
                    <p className="text-sm text-gray-600">Page d'inscription avec formulaire et présentation de l'offre</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Paiement Stripe à 29,99€</span>
                    <p className="text-sm text-gray-600">Intégration du lien Stripe pour le paiement de l'abonnement</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">CGV/CGU sur la page d'accueil</span>
                    <p className="text-sm text-gray-600">Conditions générales de vente et d'utilisation accessibles depuis l'accueil</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Rubrique contact avec formulaire</span>
                    <p className="text-sm text-gray-600">Formulaire de contact accessible depuis le menu principal</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Création de garages à distance par l'admin</span>
                    <p className="text-sm text-gray-600">Interface admin pour créer et gérer les garages</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <span className="font-medium">Compte admin par défaut</span>
                    <p className="text-sm text-gray-600">Compte admin configuré avec contact@garaglib.com / Yanisfred11</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="text-center">
              <button
                onClick={handleDeploy}
                disabled={isDeploying}
                className={`bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-lg transition-colors ${isDeploying ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {isDeploying ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Déploiement en cours...
                  </span>
                ) : 'Déployer Garaglib'}
              </button>
            </div>
          </div>
        ) : (
          <div className="text-center">
            <div className="bg-green-100 text-green-700 p-4 rounded-full inline-block mb-4">
              <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Déploiement réussi !</h2>
            <p className="text-gray-600 mb-6">Votre site Garaglib est maintenant en ligne et accessible à l'adresse suivante :</p>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8 max-w-xl mx-auto">
              <p className="text-xl font-semibold text-primary mb-2">{deploymentUrl}</p>
              <p className="text-sm text-gray-600">Vous pouvez partager cette URL avec vos utilisateurs.</p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 mb-8 max-w-xl mx-auto text-left">
              <h3 className="text-lg font-semibold mb-4">Informations d'accès</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-1">Accès administrateur</h4>
                  <p className="text-sm text-gray-600">Email : contact@garaglib.com</p>
                  <p className="text-sm text-gray-600">Mot de passe : Yanisfred11</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Accès au dashboard admin</h4>
                  <p className="text-sm text-gray-600">URL : {deploymentUrl}/admin/dashboard</p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-1">Création de garage à distance</h4>
                  <p className="text-sm text-gray-600">URL : {deploymentUrl}/admin/garages/create</p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-center space-x-4">
              <a 
                href={deploymentUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Visiter le site
              </a>
              
              <Link 
                href="/admin/dashboard" 
                className="bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Retour au dashboard
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
