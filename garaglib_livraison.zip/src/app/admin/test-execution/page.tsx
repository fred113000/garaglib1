// src/app/admin/test-execution/page.tsx
"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { runAllTests, TestResult } from '@/lib/tests/functionalTests';

export default function TestExecutionPage() {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(true);
  const [allPassed, setAllPassed] = useState(false);

  useEffect(() => {
    const executeTests = async () => {
      try {
        // Exécuter tous les tests automatiquement au chargement de la page
        const results = await runAllTests();
        setTestResults(results);
        
        // Vérifier si tous les tests ont réussi
        const allTestsPassed = results.every(result => result.passed);
        setAllPassed(allTestsPassed);
      } catch (error) {
        console.error('Erreur lors de l\'exécution des tests:', error);
      } finally {
        setIsRunning(false);
      }
    };
    
    executeTests();
  }, []);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Exécution des tests fonctionnels</h1>
        <p className="text-gray-600">Validation automatique des fonctionnalités de Garaglib</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        {isRunning ? (
          <div className="flex flex-col items-center justify-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mb-4"></div>
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Exécution des tests en cours</h2>
            <p className="text-gray-600">Veuillez patienter pendant que nous validons toutes les fonctionnalités...</p>
          </div>
        ) : (
          <div>
            <div className="text-center mb-8">
              {allPassed ? (
                <div>
                  <div className="bg-green-100 text-green-700 p-4 rounded-full inline-block mb-4">
                    <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">Tous les tests ont réussi !</h2>
                  <p className="text-gray-600 mb-6">Toutes les fonctionnalités de Garaglib ont été validées avec succès.</p>
                </div>
              ) : (
                <div>
                  <div className="bg-red-100 text-red-700 p-4 rounded-full inline-block mb-4">
                    <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800 mb-2">Certains tests ont échoué</h2>
                  <p className="text-gray-600 mb-6">Veuillez consulter les détails ci-dessous et corriger les problèmes avant le déploiement.</p>
                </div>
              )}
            </div>
            
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-700">Résumé des tests</h3>
                <div className="flex space-x-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                    <span className="text-sm">{testResults.filter(r => r.passed).length} réussis</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                    <span className="text-sm">{testResults.filter(r => !r.passed).length} échoués</span>
                  </div>
                </div>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-green-500 h-2.5 rounded-full" 
                  style={{ width: `${(testResults.filter(r => r.passed).length / testResults.length) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="space-y-4 mb-8">
              {testResults.map((result, index) => (
                <div 
                  key={index} 
                  className={`border rounded-md p-4 ${result.passed ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      {result.passed ? (
                        <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      )}
                      <h4 className="font-medium">{result.name}</h4>
                    </div>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      result.passed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {result.passed ? 'Réussi' : 'Échoué'}
                    </span>
                  </div>
                  
                  {result.details && (
                    <div className="mt-2 ml-7 text-sm text-gray-600">
                      <p>{result.details}</p>
                    </div>
                  )}
                  
                  {result.error && (
                    <div className="mt-2 ml-7 text-sm text-red-600">
                      <p>Erreur: {result.error}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <div className="flex justify-center space-x-4">
              <Link 
                href="/admin/test-report" 
                className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Voir le rapport détaillé
              </Link>
              
              <Link 
                href="/admin/dashboard" 
                className="bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 font-bold py-2 px-6 rounded-lg transition-colors"
              >
                Retour au dashboard
              </Link>
            </div>
          </div>
        )}
      </div>
      
      {!isRunning && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">Prochaines étapes</h2>
          
          {allPassed ? (
            <div>
              <p className="text-gray-600 mb-4">
                Tous les tests ont réussi. Vous pouvez maintenant procéder au déploiement de Garaglib.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-md p-4">
                <h3 className="text-lg font-medium text-blue-800 mb-2">Prêt pour le déploiement</h3>
                <p className="text-blue-700 mb-4">
                  Le site Garaglib est prêt à être déployé avec toutes les fonctionnalités demandées :
                </p>
                <ul className="list-disc list-inside text-blue-700 space-y-1 mb-4">
                  <li>Inscription garage avec page commerciale</li>
                  <li>Paiement Stripe à 29,99€</li>
                  <li>CGV/CGU sur la page d'accueil</li>
                  <li>Rubrique contact avec formulaire</li>
                  <li>Création de garages à distance par l'admin</li>
                  <li>Compte admin par défaut (contact@garaglib.com)</li>
                </ul>
                <Link 
                  href="/admin/deploy" 
                  className="bg-blue-700 hover:bg-blue-800 text-white font-bold py-2 px-6 rounded-lg transition-colors inline-block"
                >
                  Procéder au déploiement
                </Link>
              </div>
            </div>
          ) : (
            <div>
              <p className="text-gray-600 mb-4">
                Certains tests ont échoué. Veuillez corriger les problèmes identifiés avant de procéder au déploiement.
              </p>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
                <h3 className="text-lg font-medium text-yellow-800 mb-2">Actions requises</h3>
                <p className="text-yellow-700 mb-4">
                  Voici les actions à entreprendre avant de pouvoir déployer Garaglib :
                </p>
                <ul className="list-disc list-inside text-yellow-700 space-y-1">
                  {testResults.filter(r => !r.passed).map((failedTest, index) => (
                    <li key={index}>Corriger le problème : {failedTest.name} - {failedTest.error}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
