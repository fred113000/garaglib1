// src/app/admin/test-report/page.tsx
"use client";

import { useState, useEffect } from 'react';
import { runAllTests, generateTestReport, TestResult } from '@/lib/tests/functionalTests';

export default function TestReportPage() {
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [reportGenerated, setReportGenerated] = useState(false);
  const [reportContent, setReportContent] = useState('');

  const runTests = async () => {
    setIsRunning(true);
    setReportGenerated(false);
    
    try {
      const results = await runAllTests();
      setTestResults(results);
      
      const report = generateTestReport(results);
      setReportContent(report);
      setReportGenerated(true);
    } catch (error) {
      console.error('Erreur lors de l\'exécution des tests:', error);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Rapport de tests fonctionnels</h1>
        <p className="text-gray-600">Exécutez les tests pour valider les fonctionnalités de Garaglib</p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Tests fonctionnels</h2>
          <button
            onClick={runTests}
            disabled={isRunning}
            className={`bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors ${isRunning ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isRunning ? 'Exécution en cours...' : 'Exécuter les tests'}
          </button>
        </div>
        
        {isRunning && (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary"></div>
            <span className="ml-4 text-gray-600">Exécution des tests en cours...</span>
          </div>
        )}
        
        {!isRunning && testResults.length > 0 && (
          <div>
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-700">Résumé</h3>
                <div className="flex space-x-4">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                    <span className="text-sm">{testResults.filter(r => r.passed).length} réussis</span>
                  </div>
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                    <span className="text-sm">{testResults.filter(r => !r.passed).length} échoués</span>
                  </div>
                </div>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div 
                  className="bg-green-500 h-2.5 rounded-full" 
                  style={{ width: `${(testResults.filter(r => r.passed).length / testResults.length) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="space-y-4">
              {testResults.map((result, index) => (
                <div 
                  key={index} 
                  className={`border rounded-md p-4 ${result.passed ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      {result.passed ? (
                        <svg className="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      ) : (
                        <svg className="w-5 h-5 text-red-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      )}
                      <h4 className="font-medium">{result.name}</h4>
                    </div>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      result.passed ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {result.passed ? 'Réussi' : 'Échoué'}
                    </span>
                  </div>
                  
                  {result.details && (
                    <div className="mt-2 ml-7 text-sm text-gray-600">
                      <p>{result.details}</p>
                    </div>
                  )}
                  
                  {result.error && (
                    <div className="mt-2 ml-7 text-sm text-red-600">
                      <p>Erreur: {result.error}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {!isRunning && testResults.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <svg className="w-16 h-16 mx-auto mb-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
            <p>Aucun test n'a encore été exécuté. Cliquez sur "Exécuter les tests" pour commencer.</p>
          </div>
        )}
      </div>
      
      {reportGenerated && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Rapport détaillé</h2>
            <button
              onClick={() => {
                // Créer un blob et télécharger le rapport
                const blob = new Blob([reportContent], { type: 'text/markdown' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `garaglib-test-report-${new Date().toISOString().split('T')[0]}.md`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
              }}
              className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg transition-colors flex items-center"
            >
              <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              Télécharger le rapport
            </button>
          </div>
          
          <div className="bg-gray-100 p-4 rounded-md overflow-auto max-h-96">
            <pre className="text-sm whitespace-pre-wrap">{reportContent}</pre>
          </div>
        </div>
      )}
    </div>
  );
}
