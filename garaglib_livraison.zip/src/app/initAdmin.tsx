// src/app/initAdmin.tsx
"use client";

import { useEffect, useState } from 'react';
import { createDefaultAdmin, checkDefaultAdminExists } from '@/lib/firebase/adminInit';

export default function InitAdmin() {
  const [status, setStatus] = useState<'checking' | 'creating' | 'exists' | 'created' | 'error'>('checking');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initializeAdmin = async () => {
      try {
        setStatus('checking');
        const exists = await checkDefaultAdminExists();
        
        if (exists) {
          setStatus('exists');
          console.log('Le compte administrateur par défaut existe déjà.');
          return;
        }
        
        setStatus('creating');
        await createDefaultAdmin();
        setStatus('created');
        console.log('Compte administrateur par défaut créé avec succès.');
      } catch (error) {
        console.error('Erreur lors de l\'initialisation du compte admin:', error);
        setStatus('error');
        setError(error instanceof Error ? error.message : 'Une erreur inconnue est survenue');
      }
    };
    
    initializeAdmin();
  }, []);

  // Ce composant ne rend rien visuellement, il initialise simplement le compte admin
  return null;
}
