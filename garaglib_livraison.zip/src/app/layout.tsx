// src/app/layout.tsx
import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import Navbar from '@/components/ui/Navbar';
import ChatBot from '@/components/shared/ChatBot';
import InitAdmin from './initAdmin';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Garaglib - Réservation de services automobiles en ligne',
  description: 'Plateforme de réservation de rendez-vous pour les garages automobiles',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <InitAdmin />
        {children}
        <ChatBot />
      </body>
    </html>
  );
}
