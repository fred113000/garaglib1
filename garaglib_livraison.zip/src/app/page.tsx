// src/app/page.tsx
import Link from 'next/link';
import Navbar from '@/components/ui/Navbar';

export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-blue-50 to-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                Réservez votre rendez-vous auto en quelques clics
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Garaglib connecte les automobilistes avec les meilleurs garages. Trouvez un créneau disponible et réservez instantanément.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link href="/search" className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-lg transition-colors text-center">
                  Trouver un garage
                </Link>
                <Link href="/join" className="bg-white hover:bg-gray-100 text-primary border border-primary font-bold py-3 px-8 rounded-lg transition-colors text-center">
                  Vous êtes un garage ?
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 md:pl-12">
              <img 
                src="/images/hero-image.jpg" 
                alt="Réservation de rendez-vous automobile" 
                className="rounded-lg shadow-xl w-full"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Comment ça marche */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Comment ça marche</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Recherchez</h3>
              <p className="text-gray-600">Trouvez un garage près de chez vous en fonction de vos besoins et de vos disponibilités.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Réservez</h3>
              <p className="text-gray-600">Sélectionnez un créneau disponible et confirmez votre rendez-vous en quelques clics.</p>
            </div>
            
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">C'est fait !</h3>
              <p className="text-gray-600">Recevez une confirmation par email et présentez-vous au garage à l'heure convenue.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Avantages */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Pourquoi choisir Garaglib</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-primary mb-4">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-2">Gain de temps</h3>
              <p className="text-gray-600">Réservez en ligne 24h/24 et 7j/7, sans attente téléphonique.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-primary mb-4">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-2">Garages vérifiés</h3>
              <p className="text-gray-600">Tous nos garages partenaires sont sélectionnés et vérifiés.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-primary mb-4">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-2">Avis clients</h3>
              <p className="text-gray-600">Consultez les avis des autres utilisateurs avant de choisir votre garage.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="text-primary mb-4">
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-2">Sans frais</h3>
              <p className="text-gray-600">Service 100% gratuit pour les particuliers, sans frais cachés.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Témoignages */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Ce que disent nos utilisateurs</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-4">"J'ai pu réserver un rendez-vous pour ma vidange en quelques minutes, sans avoir à passer des heures au téléphone. Service impeccable !"</p>
              <div className="font-medium">Sophie D.</div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
              </div>
              <p className="text-gray-600 mb-4">"En tant que garagiste, Garaglib m'a permis d'optimiser mon planning et de réduire les rendez-vous manqués. Un vrai plus pour mon activité !"</p>
              <div className="font-medium">Marc L., Garage AutoExpert</div>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {[...Array(4)].map((_, i) => (
                    <svg key={i} className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                  <svg className="w-5 h-5" fill="gray" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                </div>
              </div>
              <p className="text-gray-600 mb-4">"Très pratique pour trouver rapidement un garage disponible. J'aurais aimé plus de filtres pour la recherche, mais dans l'ensemble c'est un excellent service."</p>
              <div className="font-medium">Thomas B.</div>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="py-16 bg-primary">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Prêt à simplifier vos rendez-vous auto ?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">Rejoignez les milliers d'utilisateurs qui font confiance à Garaglib pour leurs besoins automobiles.</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/search" className="bg-white hover:bg-gray-100 text-primary font-bold py-3 px-8 rounded-lg transition-colors">
              Trouver un garage
            </Link>
            <Link href="/join" className="bg-transparent hover:bg-blue-700 text-white border border-white font-bold py-3 px-8 rounded-lg transition-colors">
              Devenir partenaire
            </Link>
          </div>
        </div>
      </section>
      
      {/* CGV et CGU */}
      <section id="cgv" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Conditions Générales de Vente</h2>
          
          <div className="max-w-4xl mx-auto bg-gray-50 p-8 rounded-lg">
            <h3 className="text-xl font-semibold mb-4">Article 1 - Objet</h3>
            <p className="text-gray-700 mb-6">
              Les présentes Conditions Générales de Vente (CGV) régissent les relations contractuelles entre la société Garaglib, ci-après dénommée "le Prestataire", et les garages automobiles, ci-après dénommés "le Client", dans le cadre de la fourniture de services de réservation en ligne.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 2 - Services proposés</h3>
            <p className="text-gray-700 mb-6">
              Le Prestataire propose un service de mise en relation entre les garages automobiles et les particuliers souhaitant réserver un rendez-vous pour l'entretien ou la réparation de leur véhicule. Le service comprend une plateforme de réservation en ligne, un espace de gestion pour les garages, et un système de notification automatique.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 3 - Tarifs et modalités de paiement</h3>
            <p className="text-gray-700 mb-6">
              Le prix du service est fixé à 29,99€ HT par mois. Le paiement s'effectue par prélèvement automatique mensuel via la plateforme Stripe. L'abonnement est sans engagement et peut être résilié à tout moment par le Client depuis son espace personnel.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 4 - Durée et résiliation</h3>
            <p className="text-gray-700 mb-6">
              L'abonnement est conclu pour une durée indéterminée. Le Client peut résilier son abonnement à tout moment depuis son espace personnel. La résiliation prendra effet à la fin de la période mensuelle en cours. Aucun remboursement ne sera effectué pour la période mensuelle entamée.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 5 - Obligations du Client</h3>
            <p className="text-gray-700 mb-6">
              Le Client s'engage à fournir des informations exactes et à jour concernant son garage, ses services et ses disponibilités. Le Client est seul responsable de la gestion de son planning et de l'honoration des rendez-vous pris par les utilisateurs via la plateforme.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 6 - Responsabilité</h3>
            <p className="text-gray-700 mb-6">
              Le Prestataire ne pourra être tenu responsable des dommages directs ou indirects résultant de l'utilisation du service, notamment en cas d'indisponibilité temporaire de la plateforme. La responsabilité du Prestataire est limitée au montant de l'abonnement mensuel payé par le Client.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 7 - Propriété intellectuelle</h3>
            <p className="text-gray-700 mb-6">
              Tous les éléments de la plateforme (textes, images, logos, etc.) sont la propriété exclusive du Prestataire et sont protégés par les lois relatives à la propriété intellectuelle. Toute reproduction, modification ou utilisation sans autorisation préalable est strictement interdite.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 8 - Protection des données personnelles</h3>
            <p className="text-gray-700 mb-6">
              Le Prestataire s'engage à respecter la confidentialité des données personnelles collectées et à les traiter conformément au Règlement Général sur la Protection des Données (RGPD). Pour plus d'informations, veuillez consulter notre Politique de Confidentialité.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 9 - Droit applicable et juridiction compétente</h3>
            <p className="text-gray-700 mb-6">
              Les présentes CGV sont soumises au droit français. En cas de litige, les parties s'efforceront de trouver une solution amiable. À défaut, le litige sera porté devant les tribunaux compétents de Paris.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 10 - Modification des CGV</h3>
            <p className="text-gray-700">
              Le Prestataire se réserve le droit de modifier les présentes CGV à tout moment. Les nouvelles CGV seront applicables dès leur mise en ligne sur la plateforme. Le Client sera informé de toute modification substantielle par email.
            </p>
          </div>
        </div>
      </section>
      
      <section id="cgu" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Conditions Générales d'Utilisation</h2>
          
          <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-sm">
            <h3 className="text-xl font-semibold mb-4">Article 1 - Définitions</h3>
            <p className="text-gray-700 mb-6">
              Dans les présentes Conditions Générales d'Utilisation (CGU), les termes suivants ont la signification qui leur est donnée ci-après :
              <br /><br />
              - "Plateforme" : le site web et l'application mobile Garaglib
              <br />
              - "Utilisateur" : toute personne physique ou morale utilisant la Plateforme
              <br />
              - "Garage" : professionnel de l'automobile proposant ses services sur la Plateforme
              <br />
              - "Client" : utilisateur réservant un rendez-vous auprès d'un Garage
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 2 - Objet</h3>
            <p className="text-gray-700 mb-6">
              Les présentes CGU ont pour objet de définir les conditions d'utilisation de la Plateforme Garaglib, accessible depuis le site web www.garaglib.com ou l'application mobile Garaglib. L'utilisation de la Plateforme implique l'acceptation pleine et entière des présentes CGU.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 3 - Accès à la Plateforme</h3>
            <p className="text-gray-700 mb-6">
              La Plateforme est accessible gratuitement à tout Utilisateur disposant d'un accès à Internet. Tous les coûts afférents à l'accès à la Plateforme (matériel informatique, logiciels, connexion Internet, etc.) sont à la charge de l'Utilisateur. L'Utilisateur est seul responsable du bon fonctionnement de son équipement informatique et de son accès à Internet.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 4 - Inscription et compte utilisateur</h3>
            <p className="text-gray-700 mb-6">
              Pour utiliser certaines fonctionnalités de la Plateforme, l'Utilisateur doit créer un compte. Lors de l'inscription, l'Utilisateur s'engage à fournir des informations exactes, complètes et à jour. L'Utilisateur est responsable de la confidentialité de ses identifiants de connexion et de toutes les activités effectuées depuis son compte.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 5 - Réservation de rendez-vous</h3>
            <p className="text-gray-700 mb-6">
              La Plateforme permet aux Clients de réserver des rendez-vous auprès des Garages partenaires. La réservation est confirmée par email. Le Client s'engage à honorer les rendez-vous réservés ou à les annuler au moins 24 heures à l'avance. En cas d'annulation tardive ou de non-présentation, le Garage se réserve le droit de facturer des frais d'annulation.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 6 - Obligations des Utilisateurs</h3>
            <p className="text-gray-700 mb-6">
              L'Utilisateur s'engage à utiliser la Plateforme conformément aux présentes CGU et à la législation en vigueur. Il s'engage notamment à ne pas :
              <br /><br />
              - Utiliser la Plateforme à des fins illégales ou frauduleuses
              <br />
              - Tenter de perturber le fonctionnement normal de la Plateforme
              <br />
              - Collecter des informations sur les autres Utilisateurs sans leur consentement
              <br />
              - Publier des contenus diffamatoires, injurieux, obscènes ou contraires à l'ordre public
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 7 - Propriété intellectuelle</h3>
            <p className="text-gray-700 mb-6">
              Tous les éléments de la Plateforme (textes, images, logos, etc.) sont la propriété exclusive de Garaglib et sont protégés par les lois relatives à la propriété intellectuelle. Toute reproduction, modification ou utilisation sans autorisation préalable est strictement interdite.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 8 - Protection des données personnelles</h3>
            <p className="text-gray-700 mb-6">
              Garaglib s'engage à respecter la confidentialité des données personnelles collectées et à les traiter conformément au Règlement Général sur la Protection des Données (RGPD). Pour plus d'informations, veuillez consulter notre Politique de Confidentialité.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 9 - Limitation de responsabilité</h3>
            <p className="text-gray-700 mb-6">
              Garaglib agit en tant qu'intermédiaire entre les Clients et les Garages. Garaglib ne pourra être tenu responsable de la qualité des services fournis par les Garages, des annulations de rendez-vous, ou des litiges pouvant survenir entre les Clients et les Garages.
            </p>
            
            <h3 className="text-xl font-semibold mb-4">Article 10 - Modification des CGU</h3>
            <p className="text-gray-700">
              Garaglib se réserve le droit de modifier les présentes CGU à tout moment. Les nouvelles CGU seront applicables dès leur mise en ligne sur la Plateforme. L'Utilisateur est invité à consulter régulièrement les CGU.
            </p>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Garaglib</h3>
              <p className="text-gray-400 mb-4">La solution de réservation en ligne pour l'entretien automobile.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" />
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c5.51 0 10-4.48 10-10S17.51 2 12 2zm6.605 4.61a8.502 8.502 0 011.93 5.314c-.281-.054-3.101-.629-5.943-.271-.065-.141-.12-.293-.184-.445a25.416 25.416 0 00-.564-1.236c3.145-1.28 4.577-3.124 4.761-3.362zM12 3.475c2.17 0 4.154.813 5.662 2.148-.152.216-1.443 1.941-4.48 3.08-1.399-2.57-2.95-4.675-3.189-5A8.687 8.687 0 0112 3.475zm-3.633.803a53.896 53.896 0 013.167 4.935c-3.992 1.063-7.517 1.04-7.896 1.04a8.581 8.581 0 014.729-5.975zM3.453 12.01v-.26c.37.01 4.512.065 8.775-1.215.25.477.477.965.694 1.453-.109.033-.228.065-.336.098-4.404 1.42-6.747 5.303-6.942 5.629a8.522 8.522 0 01-2.19-5.705zM12 20.547a8.482 8.482 0 01-5.239-1.8c.152-.315 1.888-3.656 6.703-5.337.022-.01.033-.01.054-.022a35.318 35.318 0 011.823 6.475 8.4 8.4 0 01-3.341.684zm4.761-1.465c-.086-.52-.542-3.015-1.659-6.084 2.679-.423 5.022.271 5.314.369a8.468 8.468 0 01-3.655 5.715z" />
                  </svg>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Liens rapides</h3>
              <ul className="space-y-2">
                <li><Link href="/" className="text-gray-400 hover:text-white">Accueil</Link></li>
                <li><Link href="/search" className="text-gray-400 hover:text-white">Rechercher un garage</Link></li>
                <li><Link href="/join" className="text-gray-400 hover:text-white">Devenir partenaire</Link></li>
                <li><Link href="/contact" className="text-gray-400 hover:text-white">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Informations légales</h3>
              <ul className="space-y-2">
                <li><a href="#cgv" className="text-gray-400 hover:text-white">Conditions générales de vente</a></li>
                <li><a href="#cgu" className="text-gray-400 hover:text-white">Conditions générales d'utilisation</a></li>
                <li><a href="#privacy" className="text-gray-400 hover:text-white">Politique de confidentialité</a></li>
                <li><a href="#mentions" className="text-gray-400 hover:text-white">Mentions légales</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Newsletter</h3>
              <p className="text-gray-400 mb-4">Inscrivez-vous pour recevoir nos actualités et offres spéciales.</p>
              <form className="flex">
                <input 
                  type="email" 
                  placeholder="Votre email" 
                  className="px-4 py-2 w-full rounded-l-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                />
                <button 
                  type="submit" 
                  className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-r-md transition-colors"
                >
                  OK
                </button>
              </form>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Garaglib. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
