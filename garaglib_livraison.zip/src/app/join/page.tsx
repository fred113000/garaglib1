// src/app/join/page.tsx
"use client";

import { useState } from 'react';
import Link from 'next/link';
import Navbar from '@/components/ui/Navbar';

export default function JoinPage() {
  const [step, setStep] = useState<number>(1);
  
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-1 bg-gradient-to-b from-blue-50 to-white">
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold text-primary mb-4">Rejoignez Garaglib</h1>
              <p className="text-xl text-gray-600">La solution de réservation en ligne pour les professionnels de l'automobile</p>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden">
              {/* En-tête avec étapes */}
              <div className="bg-primary-light text-white p-6">
                <div className="flex justify-between items-center">
                  <div className={`flex items-center ${step >= 1 ? 'text-white' : 'text-blue-200'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step >= 1 ? 'bg-white text-primary' : 'bg-blue-200 text-blue-500'}`}>
                      1
                    </div>
                    <span className="hidden sm:inline">Offre</span>
                  </div>
                  <div className="flex-1 mx-4 h-1 bg-blue-200">
                    <div className={`h-full bg-white transition-all ${step >= 2 ? 'w-full' : 'w-0'}`}></div>
                  </div>
                  <div className={`flex items-center ${step >= 2 ? 'text-white' : 'text-blue-200'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step >= 2 ? 'bg-white text-primary' : 'bg-blue-200 text-blue-500'}`}>
                      2
                    </div>
                    <span className="hidden sm:inline">Inscription</span>
                  </div>
                  <div className="flex-1 mx-4 h-1 bg-blue-200">
                    <div className={`h-full bg-white transition-all ${step >= 3 ? 'w-full' : 'w-0'}`}></div>
                  </div>
                  <div className={`flex items-center ${step >= 3 ? 'text-white' : 'text-blue-200'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-2 ${step >= 3 ? 'bg-white text-primary' : 'bg-blue-200 text-blue-500'}`}>
                      3
                    </div>
                    <span className="hidden sm:inline">Paiement</span>
                  </div>
                </div>
              </div>
              
              {/* Contenu de l'étape */}
              <div className="p-6">
                {step === 1 && (
                  <div className="space-y-8">
                    <div className="text-center">
                      <h2 className="text-3xl font-bold text-gray-800 mb-4">Notre offre professionnelle</h2>
                      <p className="text-gray-600 max-w-2xl mx-auto">Transformez votre garage avec notre solution de réservation en ligne. Augmentez votre visibilité et simplifiez la gestion de vos rendez-vous.</p>
                    </div>
                    
                    <div className="bg-blue-50 rounded-lg p-8 text-center">
                      <div className="inline-block bg-primary text-white text-sm font-bold px-4 py-1 rounded-full mb-4">OFFRE EXCLUSIVE</div>
                      <h3 className="text-4xl font-bold text-primary mb-2">29,99€<span className="text-lg font-normal text-gray-600">/mois</span></h3>
                      <p className="text-gray-500 mb-6">Sans engagement, annulable à tout moment</p>
                      
                      <ul className="space-y-3 text-left max-w-md mx-auto mb-8">
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Gestion illimitée des rendez-vous</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Visibilité sur notre plateforme de recherche</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Tableau de bord professionnel personnalisé</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Notifications automatiques par email</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Gestion de vos services et tarifs</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Support client prioritaire</span>
                        </li>
                        <li className="flex items-start">
                          <svg className="w-5 h-5 text-green-500 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          <span>Statistiques et rapports d'activité</span>
                        </li>
                      </ul>
                      
                      <button 
                        onClick={() => setStep(2)}
                        className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-lg transition-colors"
                      >
                        Continuer
                      </button>
                    </div>
                    
                    <div className="grid md:grid-cols-3 gap-6 mt-12">
                      <div className="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Gain de temps</h3>
                        <p className="text-gray-600">Réduisez le temps passé au téléphone et automatisez la prise de rendez-vous.</p>
                      </div>
                      
                      <div className="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Nouveaux clients</h3>
                        <p className="text-gray-600">Attirez de nouveaux clients grâce à notre plateforme de recherche.</p>
                      </div>
                      
                      <div className="bg-white border border-gray-200 rounded-lg p-6 text-center shadow-sm">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                          </svg>
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Optimisation</h3>
                        <p className="text-gray-600">Optimisez votre planning et réduisez les créneaux non utilisés.</p>
                      </div>
                    </div>
                  </div>
                )}
                
                {step === 2 && (
                  <div>
                    <div className="text-center mb-8">
                      <h2 className="text-3xl font-bold text-gray-800 mb-4">Créez votre compte garage</h2>
                      <p className="text-gray-600 max-w-2xl mx-auto">Remplissez le formulaire ci-dessous pour créer votre compte professionnel.</p>
                    </div>
                    
                    <form className="max-w-2xl mx-auto" onSubmit={(e) => { e.preventDefault(); setStep(3); }}>
                      <div className="mb-8">
                        <h3 className="text-lg font-semibold mb-4 pb-2 border-b">Informations du garage</h3>
                        
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="garageName" className="block text-sm font-medium text-gray-700 mb-1">Nom du garage *</label>
                            <input 
                              type="text" 
                              id="garageName" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                          <div>
                            <label htmlFor="siret" className="block text-sm font-medium text-gray-700 mb-1">Numéro SIRET *</label>
                            <input 
                              type="text" 
                              id="siret" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">Adresse *</label>
                          <input 
                            type="text" 
                            id="address" 
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                            required 
                          />
                        </div>
                        
                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div>
                            <label htmlFor="zipCode" className="block text-sm font-medium text-gray-700 mb-1">Code postal *</label>
                            <input 
                              type="text" 
                              id="zipCode" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                          <div className="md:col-span-2">
                            <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">Ville *</label>
                            <input 
                              type="text" 
                              id="city" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">Téléphone *</label>
                            <input 
                              type="tel" 
                              id="phone" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                          <div>
                            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                            <input 
                              type="email" 
                              id="email" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-8">
                        <h3 className="text-lg font-semibold mb-4 pb-2 border-b">Informations du compte</h3>
                        
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">Prénom *</label>
                            <input 
                              type="text" 
                              id="firstName" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                          <div>
                            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">Nom *</label>
                            <input 
                              type="text" 
                              id="lastName" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">Mot de passe *</label>
                            <input 
                              type="password" 
                              id="password" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                          <div>
                            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">Confirmer le mot de passe *</label>
                            <input 
                              type="password" 
                              id="confirmPassword" 
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light" 
                              required 
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-8">
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input
                              id="terms"
                              type="checkbox"
                              className="focus:ring-primary h-4 w-4 text-primary border-gray-300 rounded"
                              required
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="terms" className="font-medium text-gray-700">
                              J'accepte les <Link href="/#cgv" className="text-primary hover:underline">conditions générales de vente</Link> et les <Link href="/#cgu" className="text-primary hover:underline">conditions d'utilisation</Link> *
                            </label>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between">
                        <button 
                          type="button"
                          onClick={() => setStep(1)}
                          className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-lg transition-colors"
                        >
                          Retour
                        </button>
                        
                        <button 
                          type="submit"
                          className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors"
                        >
                          Continuer vers le paiement
                        </button>
                      </div>
                    </form>
                  </div>
                )}
                
                {step === 3 && (
                  <div className="text-center py-8">
                    <div className="mb-8">
                      <h2 className="text-3xl font-bold text-gray-800 mb-4">Finaliser votre inscription</h2>
                      <p className="text-gray-600 max-w-2xl mx-auto mb-8">Vous êtes à un pas de rejoindre Garaglib. Procédez au paiement pour activer votre compte.</p>
                      
                      <div className="bg-blue-50 rounded-lg p-6 max-w-md mx-auto mb-8">
                        <h3 className="text-xl font-semibold mb-4">Récapitulatif</h3>
                        <div className="flex justify-between mb-2">
                          <span className="text-gray-600">Abonnement mensuel Garaglib</span>
                          <span className="font-medium">29,99€</span>
                        </div>
                        <div className="flex justify-between mb-2 text-sm text-gray-500">
                          <span>TVA (20%)</span>
                          <span>6,00€</span>
                        </div>
                        <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                          <span>Total</span>
                          <span>29,99€</span>
                        </div>
                      </div>
                      
                      <a 
                        href="https://buy.stripe.com/9AQ7uOdyS7Cg05W5kn" 
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bg-primary hover:bg-primary-dark text-white font-bold py-3 px-8 rounded-lg transition-colors inline-flex items-center"
                      >
                        <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
                        </svg>
                        Procéder au paiement sécurisé
                      </a>
                      
                      <p className="text-sm text-gray-500 mt-4">
                        Paiement sécurisé par Stripe. Vous serez redirigé vers notre plateforme de paiement.
                      </p>
                    </div>
                    
                    <div className="flex justify-center mt-8">
                      <button 
                        type="button"
                        onClick={() => setStep(2)}
                        className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-lg transition-colors"
                      >
                        Retour
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-12 bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Questions fréquentes</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Comment fonctionne l'abonnement ?</h3>
                  <p className="text-gray-600">L'abonnement est mensuel, sans engagement. Vous pouvez annuler à tout moment depuis votre espace garage. Le paiement est automatiquement renouvelé chaque mois.</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Puis-je essayer avant de m'engager ?</h3>
                  <p className="text-gray-600">Nous n'offrons pas de période d'essai, mais notre abonnement est sans engagement. Vous pouvez vous désabonner à tout moment si le service ne vous convient pas.</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Comment les clients réservent-ils des créneaux ?</h3>
                  <p className="text-gray-600">Les clients peuvent rechercher votre garage sur notre plateforme, consulter vos services et disponibilités, puis réserver un créneau en quelques clics. Vous recevez une notification pour chaque nouvelle réservation.</p>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Puis-je gérer plusieurs garages avec un seul compte ?</h3>
                  <p className="text-gray-600">Non, chaque garage nécessite un abonnement distinct. Cependant, vous pouvez utiliser la même adresse email pour gérer plusieurs comptes.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
