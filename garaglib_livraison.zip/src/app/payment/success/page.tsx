// src/app/payment/success/page.tsx
"use client";

import { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Navbar from '@/components/ui/Navbar';
import { handleStripeRedirect } from '@/lib/firebase/stripe';

export default function PaymentSuccessPage() {
  const searchParams = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [paymentData, setPaymentData] = useState<any>(null);
  
  useEffect(() => {
    const processPayment = async () => {
      try {
        const session_id = searchParams.get('session_id');
        
        if (!session_id) {
          setError('Identifiant de session manquant. Impossible de vérifier votre paiement.');
          setLoading(false);
          return;
        }
        
        const result = await handleStripeRedirect(session_id);
        
        if (result.success) {
          setPaymentData(result.data);
        } else {
          setError(result.message || 'Une erreur est survenue lors du traitement de votre paiement.');
        }
      } catch (error) {
        console.error('Erreur lors du traitement du paiement:', error);
        setError('Une erreur inattendue est survenue. Veuillez contacter notre support.');
      } finally {
        setLoading(false);
      }
    };
    
    processPayment();
  }, [searchParams]);
  
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="flex-1 bg-gradient-to-b from-blue-50 to-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
            {loading ? (
              <div className="p-8 text-center">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto mb-4"></div>
                <h2 className="text-2xl font-bold text-gray-800 mb-2">Traitement de votre paiement</h2>
                <p className="text-gray-600">Veuillez patienter pendant que nous confirmons votre paiement...</p>
              </div>
            ) : error ? (
              <div className="p-8 text-center">
                <div className="bg-red-100 text-red-700 p-4 rounded-lg mb-6">
                  <svg className="w-8 h-8 text-red-500 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <h2 className="text-xl font-bold mb-2">Erreur de paiement</h2>
                  <p>{error}</p>
                </div>
                
                <div className="mt-6">
                  <Link href="/join" className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors">
                    Réessayer
                  </Link>
                </div>
              </div>
            ) : (
              <div className="p-8">
                <div className="text-center mb-8">
                  <div className="bg-green-100 text-green-700 p-4 rounded-full inline-block mb-4">
                    <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="text-3xl font-bold text-gray-800 mb-2">Paiement réussi !</h2>
                  <p className="text-gray-600 mb-6">Votre abonnement Garaglib a été activé avec succès.</p>
                  
                  <div className="bg-gray-50 rounded-lg p-6 text-left mb-8">
                    <h3 className="text-lg font-semibold mb-4">Détails de votre abonnement</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Abonnement :</span>
                        <span className="font-medium">Garaglib Premium</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Montant :</span>
                        <span className="font-medium">29,99€ / mois</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Statut :</span>
                        <span className="text-green-600 font-medium">Actif</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Prochain prélèvement :</span>
                        <span className="font-medium">{new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <p className="text-gray-700">
                      Vos identifiants de connexion ont été envoyés à l'adresse email que vous avez fournie lors de l'inscription.
                    </p>
                    
                    <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4 mt-6">
                      <Link href="/garage/dashboard" className="bg-primary hover:bg-primary-dark text-white font-bold py-2 px-6 rounded-lg transition-colors">
                        Accéder à mon espace garage
                      </Link>
                      <Link href="/" className="bg-white hover:bg-gray-100 text-gray-800 border border-gray-300 font-bold py-2 px-6 rounded-lg transition-colors">
                        Retour à l'accueil
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="max-w-2xl mx-auto mt-12">
            <h3 className="text-xl font-semibold mb-4">Questions fréquentes</h3>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Quand mon abonnement sera-t-il actif ?</h4>
                <p className="text-gray-600">Votre abonnement est actif immédiatement après la confirmation du paiement.</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Comment puis-je modifier mes informations de paiement ?</h4>
                <p className="text-gray-600">Vous pouvez modifier vos informations de paiement à tout moment depuis votre espace garage, dans la section "Abonnement".</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Comment puis-je annuler mon abonnement ?</h4>
                <p className="text-gray-600">Vous pouvez annuler votre abonnement à tout moment depuis votre espace garage, dans la section "Abonnement". L'annulation prendra effet à la fin de la période mensuelle en cours.</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-medium mb-2">Je n'ai pas reçu mes identifiants de connexion, que faire ?</h4>
                <p className="text-gray-600">Si vous n'avez pas reçu vos identifiants par email, veuillez vérifier votre dossier de spam. Si vous ne les trouvez toujours pas, contactez notre support à support@garaglib.com.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
