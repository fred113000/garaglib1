"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';

// Interface pour les clients
interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  vehicles: {
    id: string;
    make: string;
    model: string;
    year: number;
    licensePlate: string;
  }[];
  appointmentsCount: number;
  totalSpent: number;
  lastVisit: Date | null;
}

export default function ClientPortfolio({ garageId }: { garageId: string }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const { user } = useAuth();

  // Charger les clients au chargement du composant
  useEffect(() => {
    const loadClients = async () => {
      try {
        setIsLoading(true);
        // Simulation de chargement des clients depuis Firebase
        // Dans une implémentation réelle, nous utiliserions une fonction Firebase
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Données de test
        const mockClients: Client[] = [
          {
            id: 'client1',
            name: 'Jean Dupont',
            email: 'jean.dupont@example.com',
            phone: '06 12 34 56 78',
            vehicles: [
              {
                id: 'vehicle1',
                make: 'Renault',
                model: 'Clio',
                year: 2018,
                licensePlate: 'AB-123-CD'
              }
            ],
            appointmentsCount: 5,
            totalSpent: 789.50,
            lastVisit: new Date(2025, 4, 10)
          },
          {
            id: 'client2',
            name: 'Marie Martin',
            email: 'marie.martin@example.com',
            phone: '06 23 45 67 89',
            vehicles: [
              {
                id: 'vehicle2',
                make: 'Peugeot',
                model: '308',
                year: 2020,
                licensePlate: 'EF-456-GH'
              },
              {
                id: 'vehicle3',
                make: 'Citroën',
                model: 'C3',
                year: 2016,
                licensePlate: 'IJ-789-KL'
              }
            ],
            appointmentsCount: 3,
            totalSpent: 1250.75,
            lastVisit: new Date(2025, 3, 25)
          },
          {
            id: 'client3',
            name: 'Pierre Durand',
            email: 'pierre.durand@example.com',
            phone: '06 34 56 78 90',
            vehicles: [
              {
                id: 'vehicle4',
                make: 'Citroën',
                model: 'C3',
                year: 2019,
                licensePlate: 'MN-012-OP'
              }
            ],
            appointmentsCount: 1,
            totalSpent: 259.98,
            lastVisit: new Date(2025, 4, 20)
          }
        ];
        
        setClients(mockClients);
      } catch (error) {
        console.error('Erreur lors du chargement des clients:', error);
        setError('Impossible de charger les clients. Veuillez réessayer.');
      } finally {
        setIsLoading(false);
      }
    };

    loadClients();
  }, [garageId]);

  // Filtrer les clients selon le terme de recherche
  const filteredClients = clients.filter(client => 
    client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.phone.includes(searchTerm) ||
    client.vehicles.some(vehicle => 
      vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  // Vérifier si l'utilisateur est autorisé à accéder au portefeuille client
  const isAuthorized = user && (user.role === 'garage' || user.role === 'admin');

  if (!isAuthorized) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
        Vous n'êtes pas autorisé à accéder au portefeuille client de ce garage.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Portefeuille client</h2>
        <button
          className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-lg transition-colors"
          onClick={() => {/* Ouvrir le formulaire d'ajout de client */}}
        >
          Ajouter un client
        </button>
      </div>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Barre de recherche */}
      <div className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            placeholder="Rechercher un client, un véhicule..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Liste des clients */}
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredClients.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
          <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
          </svg>
          <p className="text-gray-500">
            Aucun client trouvé.
          </p>
          {searchTerm && (
            <p className="text-gray-500 text-sm mt-1">
              Essayez de modifier votre recherche.
            </p>
          )}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Véhicules
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Rendez-vous
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total dépensé
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dernière visite
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredClients.map((client) => (
                <tr 
                  key={client.id}
                  className={`hover:bg-gray-50 cursor-pointer ${selectedClient?.id === client.id ? 'bg-blue-50' : ''}`}
                  onClick={() => setSelectedClient(client)}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div>
                        <div className="text-sm font-medium text-gray-900">{client.name}</div>
                        <div className="text-sm text-gray-500">{client.email}</div>
                        <div className="text-sm text-gray-500">{client.phone}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      {client.vehicles.map((vehicle) => (
                        <div key={vehicle.id} className="text-sm text-gray-500 mb-1">
                          {vehicle.make} {vehicle.model} ({vehicle.year}) - {vehicle.licensePlate}
                        </div>
                      ))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{client.appointmentsCount}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{client.totalSpent.toFixed(2)} €</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">
                      {client.lastVisit ? client.lastVisit.toLocaleDateString() : 'Jamais'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      className="text-primary hover:text-primary-dark mr-3"
                      onClick={(e) => {
                        e.stopPropagation();
                        /* Voir le profil client */
                      }}
                    >
                      Profil
                    </button>
                    <button
                      className="text-blue-600 hover:text-blue-800 mr-3"
                      onClick={(e) => {
                        e.stopPropagation();
                        /* Créer un devis */
                      }}
                    >
                      Devis
                    </button>
                    <button
                      className="text-green-600 hover:text-green-800"
                      onClick={(e) => {
                        e.stopPropagation();
                        /* Créer un rendez-vous */
                      }}
                    >
                      RDV
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Détails du client sélectionné */}
      {selectedClient && (
        <div className="mt-8 border-t border-gray-200 pt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Détails du client</h3>
            <button
              className="text-gray-500 hover:text-gray-700"
              onClick={() => setSelectedClient(null)}
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Informations personnelles</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-900 mb-1"><span className="font-medium">Nom:</span> {selectedClient.name}</p>
                <p className="text-sm text-gray-900 mb-1"><span className="font-medium">Email:</span> {selectedClient.email}</p>
                <p className="text-sm text-gray-900"><span className="font-medium">Téléphone:</span> {selectedClient.phone}</p>
              </div>
              
              <h4 className="text-sm font-medium text-gray-500 mt-4 mb-2">Véhicules</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                {selectedClient.vehicles.map((vehicle) => (
                  <div key={vehicle.id} className="mb-3 last:mb-0">
                    <p className="text-sm font-medium text-gray-900">{vehicle.make} {vehicle.model} ({vehicle.year})</p>
                    <p className="text-sm text-gray-500">Immatriculation: {vehicle.licensePlate}</p>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Statistiques</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between mb-2">
                  <p className="text-sm text-gray-500">Nombre de rendez-vous</p>
                  <p className="text-sm font-medium text-gray-900">{selectedClient.appointmentsCount}</p>
                </div>
                <div className="flex justify-between mb-2">
                  <p className="text-sm text-gray-500">Total dépensé</p>
                  <p className="text-sm font-medium text-gray-900">{selectedClient.totalSpent.toFixed(2)} €</p>
                </div>
                <div className="flex justify-between">
                  <p className="text-sm text-gray-500">Dernière visite</p>
                  <p className="text-sm font-medium text-gray-900">
                    {selectedClient.lastVisit ? selectedClient.lastVisit.toLocaleDateString() : 'Jamais'}
                  </p>
                </div>
              </div>
              
              <h4 className="text-sm font-medium text-gray-500 mt-4 mb-2">Actions rapides</h4>
              <div className="flex flex-wrap gap-2">
                <button
                  className="bg-primary hover:bg-primary-dark text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Créer un rendez-vous */}}
                >
                  Nouveau rendez-vous
                </button>
                <button
                  className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Créer un devis */}}
                >
                  Nouveau devis
                </button>
                <button
                  className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Ajouter un véhicule */}}
                >
                  Ajouter un véhicule
                </button>
                <button
                  className="bg-gray-500 hover:bg-gray-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Modifier le client */}}
                >
                  Modifier
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
