"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';
import { format, addDays, startOfWeek, isSameDay } from 'date-fns';
import { fr } from 'date-fns/locale';

// Interface pour les rendez-vous
interface Appointment {
  id: string;
  clientId: string;
  clientName: string;
  vehicleInfo: string;
  date: Date;
  startTime: string;
  endTime: string;
  service: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes?: string;
}

export default function GarageCalendar({ garageId }: { garageId: string }) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const { user } = useAuth();

  // Charger les rendez-vous au chargement du composant
  useEffect(() => {
    const loadAppointments = async () => {
      try {
        setIsLoading(true);
        // Simulation de chargement des rendez-vous depuis Firebase
        // Dans une implémentation réelle, nous utiliserions une fonction Firebase
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Données de test
        const mockAppointments: Appointment[] = [
          {
            id: 'appt1',
            clientId: 'client1',
            clientName: 'Jean Dupont',
            vehicleInfo: 'Renault Clio - AB-123-CD',
            date: new Date(2025, 4, 21, 9, 0),
            startTime: '09:00',
            endTime: '10:30',
            service: 'Vidange + Changement filtre à huile',
            status: 'pending'
          },
          {
            id: 'appt2',
            clientId: 'client2',
            clientName: 'Marie Martin',
            vehicleInfo: 'Peugeot 308 - EF-456-GH',
            date: new Date(2025, 4, 21, 14, 0),
            startTime: '14:00',
            endTime: '16:00',
            service: 'Révision complète',
            status: 'confirmed'
          },
          {
            id: 'appt3',
            clientId: 'client3',
            clientName: 'Pierre Durand',
            vehicleInfo: 'Citroën C3 - IJ-789-KL',
            date: new Date(2025, 4, 22, 11, 0),
            startTime: '11:00',
            endTime: '12:00',
            service: 'Diagnostic électronique',
            status: 'pending'
          },
          {
            id: 'appt4',
            clientId: 'client4',
            clientName: 'Sophie Lefebvre',
            vehicleInfo: 'Toyota Yaris - MN-012-OP',
            date: new Date(2025, 4, 23, 10, 0),
            startTime: '10:00',
            endTime: '11:30',
            service: 'Changement plaquettes de frein',
            status: 'confirmed'
          }
        ];
        
        setAppointments(mockAppointments);
      } catch (error) {
        console.error('Erreur lors du chargement des rendez-vous:', error);
        setError('Impossible de charger les rendez-vous. Veuillez réessayer.');
      } finally {
        setIsLoading(false);
      }
    };

    loadAppointments();
  }, [garageId]);

  // Générer les jours de la semaine
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));

  // Filtrer les rendez-vous pour la date sélectionnée
  const appointmentsForSelectedDate = appointments.filter(appointment => 
    isSameDay(appointment.date, selectedDate)
  );

  // Gérer l'acceptation d'un rendez-vous
  const handleAcceptAppointment = async (appointmentId: string) => {
    try {
      // Dans une implémentation réelle, nous utiliserions une fonction Firebase
      // pour mettre à jour le statut du rendez-vous
      
      // Simuler une mise à jour
      setAppointments(prev => 
        prev.map(appointment => 
          appointment.id === appointmentId 
            ? { ...appointment, status: 'confirmed' as const } 
            : appointment
        )
      );
      
      // Si le rendez-vous sélectionné est celui qui vient d'être accepté,
      // mettre à jour également l'état selectedAppointment
      if (selectedAppointment?.id === appointmentId) {
        setSelectedAppointment(prev => 
          prev ? { ...prev, status: 'confirmed' as const } : null
        );
      }
      
      // Simuler l'envoi d'une notification au client
      console.log(`Notification envoyée au client pour le rendez-vous ${appointmentId}: Rendez-vous confirmé`);
    } catch (error) {
      console.error('Erreur lors de l\'acceptation du rendez-vous:', error);
      setError('Impossible d\'accepter le rendez-vous. Veuillez réessayer.');
    }
  };

  // Gérer le refus d'un rendez-vous
  const handleDeclineAppointment = async (appointmentId: string) => {
    try {
      // Demander confirmation
      if (!confirm('Êtes-vous sûr de vouloir refuser ce rendez-vous ?')) {
        return;
      }
      
      // Dans une implémentation réelle, nous utiliserions une fonction Firebase
      // pour mettre à jour le statut du rendez-vous
      
      // Simuler une mise à jour
      setAppointments(prev => 
        prev.map(appointment => 
          appointment.id === appointmentId 
            ? { ...appointment, status: 'cancelled' as const } 
            : appointment
        )
      );
      
      // Si le rendez-vous sélectionné est celui qui vient d'être refusé,
      // mettre à jour également l'état selectedAppointment
      if (selectedAppointment?.id === appointmentId) {
        setSelectedAppointment(prev => 
          prev ? { ...prev, status: 'cancelled' as const } : null
        );
      }
      
      // Simuler l'envoi d'une notification au client
      console.log(`Notification envoyée au client pour le rendez-vous ${appointmentId}: Rendez-vous refusé`);
    } catch (error) {
      console.error('Erreur lors du refus du rendez-vous:', error);
      setError('Impossible de refuser le rendez-vous. Veuillez réessayer.');
    }
  };

  // Gérer la complétion d'un rendez-vous
  const handleCompleteAppointment = async (appointmentId: string) => {
    try {
      // Dans une implémentation réelle, nous utiliserions une fonction Firebase
      // pour mettre à jour le statut du rendez-vous
      
      // Simuler une mise à jour
      setAppointments(prev => 
        prev.map(appointment => 
          appointment.id === appointmentId 
            ? { ...appointment, status: 'completed' as const } 
            : appointment
        )
      );
      
      // Si le rendez-vous sélectionné est celui qui vient d'être complété,
      // mettre à jour également l'état selectedAppointment
      if (selectedAppointment?.id === appointmentId) {
        setSelectedAppointment(prev => 
          prev ? { ...prev, status: 'completed' as const } : null
        );
      }
      
      // Simuler l'envoi d'une notification au client
      console.log(`Notification envoyée au client pour le rendez-vous ${appointmentId}: Rendez-vous terminé`);
    } catch (error) {
      console.error('Erreur lors de la complétion du rendez-vous:', error);
      setError('Impossible de marquer le rendez-vous comme terminé. Veuillez réessayer.');
    }
  };

  // Naviguer à la semaine précédente
  const goToPreviousWeek = () => {
    setCurrentWeekStart(prev => addDays(prev, -7));
  };

  // Naviguer à la semaine suivante
  const goToNextWeek = () => {
    setCurrentWeekStart(prev => addDays(prev, 7));
  };

  // Vérifier si l'utilisateur est autorisé à accéder à l'agenda
  const isAuthorized = user && (user.role === 'garage' || user.role === 'admin');

  if (!isAuthorized) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
        Vous n'êtes pas autorisé à accéder à l'agenda de ce garage.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Agenda des rendez-vous</h2>
        <div className="flex space-x-2">
          <button
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded-md transition-colors"
            onClick={goToPreviousWeek}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded-md transition-colors"
            onClick={() => setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}
          >
            Aujourd'hui
          </button>
          <button
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded-md transition-colors"
            onClick={goToNextWeek}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Calendrier hebdomadaire */}
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="mb-6">
          <div className="grid grid-cols-7 gap-2 mb-2">
            {weekDays.map((day, index) => {
              const dayAppointments = appointments.filter(appointment => 
                isSameDay(appointment.date, day)
              );
              const isToday = isSameDay(day, new Date());
              const isSelected = isSameDay(day, selectedDate);
              
              return (
                <div 
                  key={index}
                  className={`p-2 rounded-lg cursor-pointer transition-colors ${
                    isSelected 
                      ? 'bg-primary text-white' 
                      : isToday 
                        ? 'bg-blue-100 text-blue-800' 
                        : 'bg-gray-100 hover:bg-gray-200'
                  }`}
                  onClick={() => setSelectedDate(day)}
                >
                  <div className="text-center">
                    <p className="text-xs font-medium mb-1">
                      {format(day, 'EEE', { locale: fr })}
                    </p>
                    <p className={`text-lg font-bold ${isSelected ? 'text-white' : ''}`}>
                      {format(day, 'd', { locale: fr })}
                    </p>
                  </div>
                  <div className="mt-2">
                    {dayAppointments.length > 0 ? (
                      <div className="text-center">
                        <span className={`inline-flex items-center justify-center px-2 py-1 text-xs font-bold rounded-full ${
                          isSelected 
                            ? 'bg-white text-primary' 
                            : 'bg-primary text-white'
                        }`}>
                          {dayAppointments.length}
                        </span>
                      </div>
                    ) : (
                      <div className="text-center text-xs text-gray-500">
                        -
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Rendez-vous du {format(selectedDate, 'EEEE d MMMM yyyy', { locale: fr })}
            </h3>
            
            {appointmentsForSelectedDate.length === 0 ? (
              <div className="text-center py-8">
                <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="text-gray-500">
                  Aucun rendez-vous prévu pour cette journée.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {appointmentsForSelectedDate
                  .sort((a, b) => a.startTime.localeCompare(b.startTime))
                  .map((appointment) => (
                    <div 
                      key={appointment.id}
                      className={`p-4 rounded-lg border ${
                        appointment.status === 'pending' ? 'border-yellow-300 bg-yellow-50' :
                        appointment.status === 'confirmed' ? 'border-green-300 bg-green-50' :
                        appointment.status === 'cancelled' ? 'border-red-300 bg-red-50' :
                        'border-blue-300 bg-blue-50'
                      } cursor-pointer hover:shadow-md transition-shadow`}
                      onClick={() => setSelectedAppointment(appointment)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-sm font-medium text-gray-900">
                            {appointment.startTime} - {appointment.endTime}
                          </p>
                          <p className="text-lg font-semibold text-gray-900 mt-1">
                            {appointment.clientName}
                          </p>
                          <p className="text-sm text-gray-600">
                            {appointment.vehicleInfo}
                          </p>
                          <p className="text-sm text-gray-600 mt-1">
                            {appointment.service}
                          </p>
                        </div>
                        <div>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            appointment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            appointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                            appointment.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {appointment.status === 'pending' ? 'En attente' :
                             appointment.status === 'confirmed' ? 'Confirmé' :
                             appointment.status === 'cancelled' ? 'Annulé' :
                             'Terminé'}
                          </span>
                        </div>
                      </div>
                      
                      {appointment.status === 'pending' && (
                        <div className="mt-3 flex space-x-2">
                          <button
                            className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAcceptAppointment(appointment.id);
                            }}
                          >
                            Accepter
                          </button>
                          <button
                            className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeclineAppointment(appointment.id);
                            }}
                          >
                            Refuser
                          </button>
                        </div>
                      )}
                      
                      {appointment.status === 'confirmed' && (
                        <div className="mt-3">
                          <button
                            className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCompleteAppointment(appointment.id);
                            }}
                          >
                            Marquer comme terminé
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            )}
          </div>
        </div>
      )}
      
      {/* Détails du rendez-vous sélectionné */}
      {selectedAppointment && (
        <div className="mt-6 border-t border-gray-200 pt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-gray-900">Détails du rendez-vous</h3>
            <button
              className="text-gray-500 hover:text-gray-700"
              onClick={() => setSelectedAppointment(null)}
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Informations du rendez-vous</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Date:</span> {format(selectedAppointment.date, 'EEEE d MMMM yyyy', { locale: fr })}
                </p>
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Horaire:</span> {selectedAppointment.startTime} - {selectedAppointment.endTime}
                </p>
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Service:</span> {selectedAppointment.service}
                </p>
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Statut:</span>{' '}
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    selectedAppointment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    selectedAppointment.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                    selectedAppointment.status === 'cancelled' ? 'bg-red-100 text-red-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {selectedAppointment.status === 'pending' ? 'En attente' :
                     selectedAppointment.status === 'confirmed' ? 'Confirmé' :
                     selectedAppointment.status === 'cancelled' ? 'Annulé' :
                     'Terminé'}
                  </span>
                </p>
                {selectedAppointment.notes && (
                  <div className="mt-2">
                    <p className="text-sm font-medium text-gray-900 mb-1">Notes:</p>
                    <p className="text-sm text-gray-600">{selectedAppointment.notes}</p>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Informations du client</h4>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Nom:</span> {selectedAppointment.clientName}
                </p>
                <p className="text-sm text-gray-900 mb-1">
                  <span className="font-medium">Véhicule:</span> {selectedAppointment.vehicleInfo}
                </p>
              </div>
              
              <h4 className="text-sm font-medium text-gray-500 mt-4 mb-2">Actions</h4>
              <div className="flex flex-wrap gap-2">
                {selectedAppointment.status === 'pending' && (
                  <>
                    <button
                      className="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                      onClick={() => handleAcceptAppointment(selectedAppointment.id)}
                    >
                      Accepter le rendez-vous
                    </button>
                    <button
                      className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                      onClick={() => handleDeclineAppointment(selectedAppointment.id)}
                    >
                      Refuser le rendez-vous
                    </button>
                  </>
                )}
                
                {selectedAppointment.status === 'confirmed' && (
                  <button
                    className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                    onClick={() => handleCompleteAppointment(selectedAppointment.id)}
                  >
                    Marquer comme terminé
                  </button>
                )}
                
                <button
                  className="bg-gray-500 hover:bg-gray-600 text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Ajouter des notes */}}
                >
                  Ajouter des notes
                </button>
                
                <button
                  className="bg-primary hover:bg-primary-dark text-white px-3 py-1 rounded-md text-sm transition-colors"
                  onClick={() => {/* Contacter le client */}}
                >
                  Contacter le client
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
