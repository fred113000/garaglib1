// src/components/garage/SlotValidator.tsx
import { useState, useEffect } from 'react';
import { hasMinimumSlots } from '@/lib/firebase/slots';

interface SlotValidatorProps {
  garageId: string;
  date: Date;
  minimumSlots?: number;
  onValidationChange: (isValid: boolean) => void;
}

export default function SlotValidator({ 
  garageId, 
  date, 
  minimumSlots = 5,
  onValidationChange 
}: SlotValidatorProps) {
  const [isValid, setIsValid] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [slotsCount, setSlotsCount] = useState<number>(0);

  useEffect(() => {
    const checkSlots = async () => {
      setLoading(true);
      try {
        // Vérifier si le garage a au moins le nombre minimum de créneaux
        const hasMinimum = await hasMinimumSlots(garageId, date, minimumSlots);
        setIsValid(hasMinimum);
        
        // Récupérer le nombre de créneaux disponibles
        const slots = await getAvailableSlots(garageId, date);
        setSlotsCount(slots.length);
        
        // Informer le parent du changement de validation
        onValidationChange(hasMinimum);
      } catch (error) {
        console.error('Erreur lors de la validation des créneaux:', error);
        setIsValid(false);
        onValidationChange(false);
      } finally {
        setLoading(false);
      }
    };

    checkSlots();
  }, [garageId, date, minimumSlots, onValidationChange]);

  if (loading) {
    return (
      <div className="p-4 bg-gray-100 rounded-md">
        <p className="text-gray-600">Vérification des créneaux en cours...</p>
      </div>
    );
  }

  if (isValid) {
    return (
      <div className="p-4 bg-green-100 rounded-md">
        <p className="text-green-800">
          <span className="font-medium">✓</span> Vous avez {slotsCount} créneaux disponibles pour cette date.
        </p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-red-100 rounded-md">
      <p className="text-red-800">
        <span className="font-medium">⚠</span> Vous devez définir au moins {minimumSlots} créneaux disponibles pour cette date.
        Actuellement : {slotsCount} créneaux.
      </p>
    </div>
  );
}
