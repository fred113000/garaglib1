"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';

// Interface pour les devis
interface Quote {
  id: string;
  clientId: string;
  clientName: string;
  vehicleInfo: string;
  services: {
    name: string;
    price: number;
  }[];
  totalAmount: number;
  status: 'draft' | 'sent' | 'accepted' | 'declined';
  createdAt: Date;
  validUntil: Date;
}

export default function QuoteManager({ garageId }: { garageId: string }) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'draft' | 'sent' | 'accepted' | 'declined'>('all');
  const { user } = useAuth();

  // Charger les devis au chargement du composant
  useEffect(() => {
    const loadQuotes = async () => {
      try {
        setIsLoading(true);
        // Simulation de chargement des devis depuis Firebase
        // Dans une implémentation réelle, nous utiliserions une fonction Firebase
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Données de test
        const mockQuotes: Quote[] = [
          {
            id: '1',
            clientId: 'client1',
            clientName: 'Jean Dupont',
            vehicleInfo: 'Renault Clio - AB-123-CD',
            services: [
              { name: 'Vidange', price: 89.99 },
              { name: 'Changement filtre à huile', price: 29.99 }
            ],
            totalAmount: 119.98,
            status: 'accepted',
            createdAt: new Date(2025, 4, 15),
            validUntil: new Date(2025, 5, 15)
          },
          {
            id: '2',
            clientId: 'client2',
            clientName: 'Marie Martin',
            vehicleInfo: 'Peugeot 308 - EF-456-GH',
            services: [
              { name: 'Révision complète', price: 249.99 },
              { name: 'Changement plaquettes de frein', price: 149.99 }
            ],
            totalAmount: 399.98,
            status: 'sent',
            createdAt: new Date(2025, 4, 18),
            validUntil: new Date(2025, 5, 18)
          },
          {
            id: '3',
            clientId: 'client3',
            clientName: 'Pierre Durand',
            vehicleInfo: 'Citroën C3 - IJ-789-KL',
            services: [
              { name: 'Diagnostic électronique', price: 59.99 },
              { name: 'Réparation système électrique', price: 199.99 }
            ],
            totalAmount: 259.98,
            status: 'draft',
            createdAt: new Date(2025, 4, 20),
            validUntil: new Date(2025, 5, 20)
          }
        ];
        
        setQuotes(mockQuotes);
      } catch (error) {
        console.error('Erreur lors du chargement des devis:', error);
        setError('Impossible de charger les devis. Veuillez réessayer.');
      } finally {
        setIsLoading(false);
      }
    };

    loadQuotes();
  }, [garageId]);

  // Filtrer les devis selon l'onglet actif
  const filteredQuotes = activeTab === 'all' 
    ? quotes 
    : quotes.filter(quote => quote.status === activeTab);

  // Vérifier si l'utilisateur est autorisé à gérer les devis
  const isAuthorized = user && (user.role === 'garage' || user.role === 'admin');

  if (!isAuthorized) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
        Vous n'êtes pas autorisé à gérer les devis de ce garage.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-gray-800">Gestion des devis</h2>
        <button
          className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-lg transition-colors"
          onClick={() => {/* Ouvrir le formulaire de création de devis */}}
        >
          Nouveau devis
        </button>
      </div>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Onglets de filtrage */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex -mb-px">
          <button
            className={`py-2 px-4 border-b-2 font-medium text-sm ${
              activeTab === 'all'
                ? 'border-primary text-primary'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('all')}
          >
            Tous
          </button>
          <button
            className={`py-2 px-4 border-b-2 font-medium text-sm ${
              activeTab === 'draft'
                ? 'border-primary text-primary'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('draft')}
          >
            Brouillons
          </button>
          <button
            className={`py-2 px-4 border-b-2 font-medium text-sm ${
              activeTab === 'sent'
                ? 'border-primary text-primary'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('sent')}
          >
            Envoyés
          </button>
          <button
            className={`py-2 px-4 border-b-2 font-medium text-sm ${
              activeTab === 'accepted'
                ? 'border-primary text-primary'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('accepted')}
          >
            Acceptés
          </button>
          <button
            className={`py-2 px-4 border-b-2 font-medium text-sm ${
              activeTab === 'declined'
                ? 'border-primary text-primary'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('declined')}
          >
            Refusés
          </button>
        </nav>
      </div>
      
      {/* Liste des devis */}
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : filteredQuotes.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
          <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <p className="text-gray-500">
            Aucun devis {activeTab !== 'all' ? `au statut "${activeTab}"` : ''} trouvé.
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Client
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Véhicule
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Montant
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Statut
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Date
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredQuotes.map((quote) => (
                <tr key={quote.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{quote.clientName}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{quote.vehicleInfo}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{quote.totalAmount.toFixed(2)} €</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      quote.status === 'draft' ? 'bg-gray-100 text-gray-800' :
                      quote.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                      quote.status === 'accepted' ? 'bg-green-100 text-green-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {quote.status === 'draft' ? 'Brouillon' :
                       quote.status === 'sent' ? 'Envoyé' :
                       quote.status === 'accepted' ? 'Accepté' :
                       'Refusé'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {quote.createdAt.toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      className="text-primary hover:text-primary-dark mr-3"
                      onClick={() => {/* Voir le devis */}}
                    >
                      Voir
                    </button>
                    {quote.status === 'draft' && (
                      <>
                        <button
                          className="text-blue-600 hover:text-blue-800 mr-3"
                          onClick={() => {/* Envoyer le devis */}}
                        >
                          Envoyer
                        </button>
                        <button
                          className="text-gray-600 hover:text-gray-800"
                          onClick={() => {/* Modifier le devis */}}
                        >
                          Modifier
                        </button>
                      </>
                    )}
                    {quote.status === 'sent' && (
                      <button
                        className="text-gray-600 hover:text-gray-800"
                        onClick={() => {/* Relancer le client */}}
                      >
                        Relancer
                      </button>
                    )}
                    {quote.status === 'accepted' && (
                      <button
                        className="text-green-600 hover:text-green-800"
                        onClick={() => {/* Convertir en rendez-vous */}}
                      >
                        Convertir en RDV
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
