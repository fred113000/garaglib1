"use client";

import { useState, useRef } from 'react';
import { uploadGaragePhoto, getGaragePhotos, deleteGaragePhoto, updatePhotoOrder, setMainPhoto, GaragePhoto } from '@/lib/firebase/photos';
import { useAuth } from '@/lib/hooks/useAuth';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TouchBackend } from 'react-dnd-touch-backend';
import { isMobile } from 'react-device-detect';

// Composant pour la gestion des photos de garage
export default function GaragePhotoManager({ garageId }: { garageId: string }) {
  const [photos, setPhotos] = useState<GaragePhoto[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { user } = useAuth();

  // Charger les photos au chargement du composant
  useState(() => {
    const loadPhotos = async () => {
      try {
        setIsLoading(true);
        const photosList = await getGaragePhotos(garageId);
        setPhotos(photosList);
      } catch (error) {
        console.error('Erreur lors du chargement des photos:', error);
        setError('Impossible de charger les photos. Veuillez réessayer.');
      } finally {
        setIsLoading(false);
      }
    };

    loadPhotos();
  }, [garageId]);

  // Gérer l'upload de photo
  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    try {
      setIsLoading(true);
      setError(null);
      setUploadProgress(0);

      // Vérifier si c'est la première photo (qui sera définie comme principale)
      const isMain = photos.length === 0;

      // Simuler la progression de l'upload
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 300);

      // Upload de la photo
      const uploadedPhoto = await uploadGaragePhoto(garageId, files[0], isMain);
      
      // Mettre à jour la liste des photos
      setPhotos(prev => [...prev, uploadedPhoto]);
      
      // Terminer la progression
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Réinitialiser après un court délai
      setTimeout(() => {
        setUploadProgress(0);
        setIsLoading(false);
      }, 500);
      
      // Réinitialiser l'input file
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Erreur lors de l\'upload de la photo:', error);
      setError('Impossible d\'uploader la photo. Veuillez réessayer.');
      setIsLoading(false);
      setUploadProgress(0);
    }
  };

  // Gérer la suppression de photo
  const handleDeletePhoto = async (photoId: string) => {
    if (!photoId) return;
    
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette photo ?')) {
      return;
    }

    try {
      setIsLoading(true);
      await deleteGaragePhoto(photoId);
      setPhotos(prev => prev.filter(photo => photo.id !== photoId));
    } catch (error) {
      console.error('Erreur lors de la suppression de la photo:', error);
      setError('Impossible de supprimer la photo. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  // Gérer le changement d'ordre des photos
  const handleReorderPhotos = async (dragIndex: number, hoverIndex: number) => {
    const newPhotos = [...photos];
    const draggedPhoto = newPhotos[dragIndex];
    
    // Réorganiser l'array
    newPhotos.splice(dragIndex, 1);
    newPhotos.splice(hoverIndex, 0, draggedPhoto);
    
    // Mettre à jour l'état local
    setPhotos(newPhotos);
    
    // Mettre à jour dans Firebase
    try {
      await updatePhotoOrder(newPhotos);
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'ordre des photos:', error);
      setError('Impossible de mettre à jour l\'ordre des photos. Veuillez réessayer.');
    }
  };

  // Gérer la définition de la photo principale
  const handleSetMainPhoto = async (photoId: string) => {
    if (!photoId) return;

    try {
      setIsLoading(true);
      await setMainPhoto(photoId);
      
      // Mettre à jour l'état local
      const updatedPhotos = [...photos];
      updatedPhotos.forEach(photo => {
        photo.isMain = photo.id === photoId;
      });
      
      // Réorganiser pour que la photo principale soit en premier
      const mainPhoto = updatedPhotos.find(photo => photo.isMain);
      const otherPhotos = updatedPhotos.filter(photo => !photo.isMain);
      
      if (mainPhoto) {
        setPhotos([mainPhoto, ...otherPhotos]);
      }
    } catch (error) {
      console.error('Erreur lors de la définition de la photo principale:', error);
      setError('Impossible de définir la photo principale. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  // Vérifier si l'utilisateur est autorisé à gérer les photos
  const isAuthorized = user && (user.role === 'garage' || user.role === 'admin');

  if (!isAuthorized) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
        Vous n'êtes pas autorisé à gérer les photos de ce garage.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Photos du garage</h2>
      
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-4">
          {error}
        </div>
      )}
      
      {/* Section d'upload */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Ajouter une nouvelle photo
        </label>
        
        <div className="flex items-center">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handlePhotoUpload}
            accept="image/*"
            className="hidden"
            disabled={isLoading}
          />
          
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className={`bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-lg transition-colors ${isLoading ? 'opacity-70 cursor-not-allowed' : ''}`}
          >
            {isLoading ? 'Upload en cours...' : 'Sélectionner une image'}
          </button>
          
          <p className="ml-3 text-sm text-gray-500">
            JPG, PNG ou GIF, max 5MB
          </p>
        </div>
        
        {uploadProgress > 0 && (
          <div className="mt-2">
            <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
              <div 
                className="bg-primary h-2.5 rounded-full" 
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {uploadProgress < 100 ? `Upload en cours: ${uploadProgress}%` : 'Upload terminé !'}
            </p>
          </div>
        )}
      </div>
      
      {/* Liste des photos */}
      <div>
        <h3 className="text-lg font-medium text-gray-700 mb-3">
          Photos du garage ({photos.length})
        </h3>
        
        {photos.length === 0 ? (
          <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-200">
            <svg className="w-12 h-12 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-gray-500">
              Aucune photo n'a été ajoutée pour ce garage.
            </p>
            <p className="text-gray-500 text-sm mt-1">
              Ajoutez des photos pour attirer plus de clients !
            </p>
          </div>
        ) : (
          <DndProvider backend={isMobile ? TouchBackend : HTML5Backend}>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {photos.map((photo, index) => (
                <PhotoItem
                  key={photo.id}
                  photo={photo}
                  index={index}
                  onDelete={handleDeletePhoto}
                  onSetMain={handleSetMainPhoto}
                  onReorder={handleReorderPhotos}
                />
              ))}
            </div>
          </DndProvider>
        )}
      </div>
    </div>
  );
}

// Type pour les props du composant PhotoItem
interface PhotoItemProps {
  photo: GaragePhoto;
  index: number;
  onDelete: (photoId: string) => void;
  onSetMain: (photoId: string) => void;
  onReorder: (dragIndex: number, hoverIndex: number) => void;
}

// Composant pour un élément photo avec drag and drop
const PhotoItem = ({ photo, index, onDelete, onSetMain, onReorder }: PhotoItemProps) => {
  const ref = useRef<HTMLDivElement>(null);
  
  // Configuration du drag
  const [{ isDragging }, drag] = useDrag({
    type: 'PHOTO',
    item: { index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  
  // Configuration du drop
  const [, drop] = useDrop({
    accept: 'PHOTO',
    hover: (item: { index: number }, monitor) => {
      if (!ref.current) {
        return;
      }
      
      const dragIndex = item.index;
      const hoverIndex = index;
      
      // Ne pas remplacer les éléments avec eux-mêmes
      if (dragIndex === hoverIndex) {
        return;
      }
      
      // Déterminer le rectangle à l'écran
      const hoverBoundingRect = ref.current.getBoundingClientRect();
      
      // Obtenir le milieu vertical
      const hoverMiddleY = (hoverBoundingRect.bottom - hoverBoundingRect.top) / 2;
      
      // Déterminer la position du curseur
      const clientOffset = monitor.getClientOffset();
      
      // Obtenir les pixels jusqu'au haut
      const hoverClientY = clientOffset!.y - hoverBoundingRect.top;
      
      // Ne déplacer que lorsque le curseur a dépassé la moitié de la hauteur de l'élément
      // Lors du déplacement vers le bas, ne déplacer que lorsque le curseur est en dessous de 50%
      // Lors du déplacement vers le haut, ne déplacer que lorsque le curseur est au-dessus de 50%
      
      // Déplacement vers le haut
      if (dragIndex > hoverIndex && hoverClientY > hoverMiddleY) {
        return;
      }
      
      // Déplacement vers le bas
      if (dragIndex < hoverIndex && hoverClientY < hoverMiddleY) {
        return;
      }
      
      // Effectuer le déplacement
      onReorder(dragIndex, hoverIndex);
      
      // Mettre à jour l'index de l'élément
      item.index = hoverIndex;
    },
  });
  
  // Initialiser les refs de drag and drop
  drag(drop(ref));
  
  return (
    <div 
      ref={ref}
      className={`relative rounded-lg overflow-hidden border ${photo.isMain ? 'border-primary' : 'border-gray-200'} ${isDragging ? 'opacity-50' : 'opacity-100'}`}
      style={{ opacity: isDragging ? 0.5 : 1 }}
    >
      <div className="aspect-w-4 aspect-h-3">
        <img 
          src={photo.url} 
          alt={`Photo ${index + 1}`} 
          className="object-cover w-full h-full"
        />
      </div>
      
      <div className="absolute top-2 right-2 flex space-x-1">
        {!photo.isMain && (
          <button
            onClick={() => photo.id && onSetMain(photo.id)}
            className="bg-blue-500 hover:bg-blue-600 text-white p-1 rounded-full"
            title="Définir comme photo principale"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
            </svg>
          </button>
        )}
        
        <button
          onClick={() => photo.id && onDelete(photo.id)}
          className="bg-red-500 hover:bg-red-600 text-white p-1 rounded-full"
          title="Supprimer la photo"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>
      
      {photo.isMain && (
        <div className="absolute bottom-0 left-0 right-0 bg-primary text-white text-xs py-1 text-center">
          Photo principale
        </div>
      )}
    </div>
  );
};
