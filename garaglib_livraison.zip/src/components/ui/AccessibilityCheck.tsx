"use client";

import { useState, useEffect } from 'react';

interface AccessibilityIssue {
  element: string;
  issue: string;
  severity: 'high' | 'medium' | 'low';
  suggestion: string;
}

export default function AccessibilityCheck() {
  const [issues, setIssues] = useState<AccessibilityIssue[]>([]);
  const [showReport, setShowReport] = useState(false);

  useEffect(() => {
    // Cette fonction serait normalement plus complexe et utiliserait
    // des bibliothèques comme axe-core pour une vérification complète
    const checkAccessibility = () => {
      const newIssues: AccessibilityIssue[] = [];
      
      // Vérifier les images sans alt
      document.querySelectorAll('img').forEach((img, index) => {
        if (!img.alt) {
          newIssues.push({
            element: `Image #${index + 1}`,
            issue: 'Image sans attribut alt',
            severity: 'high',
            suggestion: 'Ajouter un attribut alt descriptif à l\'image'
          });
        }
      });
      
      // Vérifier les contrastes de couleur (simplifié)
      document.querySelectorAll('*').forEach((el) => {
        const style = window.getComputedStyle(el);
        const bgColor = style.backgroundColor;
        const color = style.color;
        
        // Vérification très simplifiée - dans un cas réel, utiliser une bibliothèque de contraste
        if (bgColor === 'rgba(0, 0, 0, 0)' || color === 'rgba(0, 0, 0, 0)') {
          return;
        }
        
        if (bgColor === color) {
          newIssues.push({
            element: el.tagName,
            issue: 'Contraste insuffisant entre le texte et l\'arrière-plan',
            severity: 'high',
            suggestion: 'Augmenter le contraste entre la couleur du texte et la couleur d\'arrière-plan'
          });
        }
      });
      
      // Vérifier les formulaires sans labels
      document.querySelectorAll('input, select, textarea').forEach((input, index) => {
        const inputEl = input as HTMLInputElement;
        const id = inputEl.id;
        
        if (!id || !document.querySelector(`label[for="${id}"]`)) {
          newIssues.push({
            element: `Champ de formulaire #${index + 1}`,
            issue: 'Champ de formulaire sans label associé',
            severity: 'medium',
            suggestion: 'Ajouter un label avec l\'attribut for correspondant à l\'id du champ'
          });
        }
      });
      
      setIssues(newIssues);
    };
    
    // Exécuter la vérification après le chargement complet de la page
    window.addEventListener('load', checkAccessibility);
    
    return () => {
      window.removeEventListener('load', checkAccessibility);
    };
  }, []);

  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }

  return (
    <div className="fixed top-4 left-4 z-50">
      <button
        onClick={() => setShowReport(!showReport)}
        className="bg-blue-600 text-white px-3 py-1 rounded-md text-xs"
      >
        {showReport ? 'Masquer' : 'Vérifier'} l'accessibilité
      </button>
      
      {showReport && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 max-w-md max-h-96 overflow-y-auto">
          <h3 className="font-bold text-sm mb-2">Rapport d'accessibilité</h3>
          
          {issues.length === 0 ? (
            <p className="text-green-600 text-xs">Aucun problème d'accessibilité détecté.</p>
          ) : (
            <ul className="space-y-2">
              {issues.map((issue, index) => (
                <li key={index} className="text-xs border-l-4 pl-2 py-1" style={{
                  borderColor: issue.severity === 'high' ? 'red' : issue.severity === 'medium' ? 'orange' : 'yellow'
                }}>
                  <p className="font-medium">{issue.element}: {issue.issue}</p>
                  <p className="text-gray-600">Suggestion: {issue.suggestion}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
