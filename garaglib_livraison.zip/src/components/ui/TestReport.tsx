"use client";

import { useState, useEffect } from 'react';

interface TestResult {
  category: string;
  total: number;
  passed: number;
  failed: number;
  pending: number;
}

export default function TestReport() {
  const [showReport, setShowReport] = useState(false);
  const [testResults, setTestResults] = useState<TestResult[]>([
    { category: 'Réservation', total: 4, passed: 3, failed: 1, pending: 0 },
    { category: 'Gestion des créneaux', total: 3, passed: 3, failed: 0, pending: 0 },
    { category: 'Authentification', total: 3, passed: 3, failed: 0, pending: 0 },
    { category: 'Fonctionnalités avancées', total: 8, passed: 7, failed: 1, pending: 0 }
  ]);
  
  const [bugSummary, setBugSummary] = useState({
    total: 5,
    critical: 0,
    major: 2,
    minor: 3,
    fixed: 4,
    pending: 1
  });
  
  const getTotalStats = () => {
    return testResults.reduce(
      (acc, curr) => ({
        total: acc.total + curr.total,
        passed: acc.passed + curr.passed,
        failed: acc.failed + curr.failed,
        pending: acc.pending + curr.pending
      }),
      { total: 0, passed: 0, failed: 0, pending: 0 }
    );
  };
  
  const totalStats = getTotalStats();
  const passRate = totalStats.total > 0 ? (totalStats.passed / totalStats.total) * 100 : 0;
  
  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }
  
  return (
    <div className="fixed top-4 right-20 z-50">
      <button
        onClick={() => setShowReport(!showReport)}
        className="bg-green-600 text-white px-3 py-1 rounded-md text-xs flex items-center"
      >
        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        {showReport ? 'Masquer' : 'Rapport de tests'} ({Math.round(passRate)}%)
      </button>
      
      {showReport && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 w-96 max-h-[80vh] overflow-y-auto">
          <h3 className="font-bold text-sm mb-4">Rapport de tests et corrections</h3>
          
          <div className="mb-4">
            <h4 className="font-medium text-sm mb-2">Résumé des tests fonctionnels</h4>
            <div className="bg-gray-100 rounded-md p-3">
              <div className="flex justify-between mb-2">
                <span className="text-xs">Taux de réussite global:</span>
                <span className="text-xs font-medium">{Math.round(passRate)}%</span>
              </div>
              <div className="w-full bg-gray-300 rounded-full h-2">
                <div 
                  className="bg-green-500 h-2 rounded-full" 
                  style={{ width: `${passRate}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs mt-2">
                <div>
                  <span className="text-green-600 font-medium">{totalStats.passed}</span> réussis
                </div>
                <div>
                  <span className="text-red-600 font-medium">{totalStats.failed}</span> échoués
                </div>
                <div>
                  <span className="text-gray-600 font-medium">{totalStats.pending}</span> en attente
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium text-sm mb-2">Détail par catégorie</h4>
            <div className="space-y-2">
              {testResults.map((result, index) => (
                <div key={index} className="bg-gray-100 rounded-md p-2">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs font-medium">{result.category}</span>
                    <span className="text-xs">
                      {result.passed}/{result.total} ({Math.round((result.passed / result.total) * 100)}%)
                    </span>
                  </div>
                  <div className="w-full bg-gray-300 rounded-full h-1.5">
                    <div 
                      className="bg-green-500 h-1.5 rounded-full" 
                      style={{ width: `${(result.passed / result.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium text-sm mb-2">Résumé des bugs</h4>
            <div className="bg-gray-100 rounded-md p-3">
              <div className="grid grid-cols-3 gap-2">
                <div className="text-center">
                  <div className="text-lg font-medium">{bugSummary.total}</div>
                  <div className="text-xs text-gray-600">Total</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-medium text-green-600">{bugSummary.fixed}</div>
                  <div className="text-xs text-gray-600">Corrigés</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-medium text-orange-600">{bugSummary.pending}</div>
                  <div className="text-xs text-gray-600">En attente</div>
                </div>
              </div>
              <div className="mt-2 pt-2 border-t border-gray-300">
                <div className="flex justify-between text-xs">
                  <div>
                    <span className="text-red-600 font-medium">{bugSummary.critical}</span> critiques
                  </div>
                  <div>
                    <span className="text-orange-600 font-medium">{bugSummary.major}</span> majeurs
                  </div>
                  <div>
                    <span className="text-yellow-600 font-medium">{bugSummary.minor}</span> mineurs
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-sm mb-2">Bugs critiques corrigés</h4>
            <ul className="text-xs space-y-1">
              <li className="flex items-start">
                <svg className="w-3 h-3 text-green-500 mt-0.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Validation du minimum de 5 créneaux par garage</span>
              </li>
              <li className="flex items-start">
                <svg className="w-3 h-3 text-green-500 mt-0.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Synchronisation des créneaux entre garage et client</span>
              </li>
              <li className="flex items-start">
                <svg className="w-3 h-3 text-green-500 mt-0.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Redirection après authentification selon le rôle</span>
              </li>
              <li className="flex items-start">
                <svg className="w-3 h-3 text-green-500 mt-0.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Affichage des notifications en temps réel</span>
              </li>
            </ul>
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-200">
            <h4 className="font-medium text-sm mb-2">Bugs en attente de correction</h4>
            <ul className="text-xs space-y-1">
              <li className="flex items-start">
                <svg className="w-3 h-3 text-orange-500 mt-0.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Optimisation de la recherche instantanée sur mobile</span>
              </li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
