"use client";

import { useState, useEffect } from 'react';

export default function ResponsiveCheck() {
  const [viewport, setViewport] = useState({
    width: 0,
    height: 0,
    isMobile: false,
    isTablet: false,
    isDesktop: false
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      setViewport({
        width,
        height: window.innerHeight,
        isMobile: width < 768,
        isTablet: width >= 768 && width < 1024,
        isDesktop: width >= 1024
      });
    };

    // Exécuter une fois au chargement
    handleResize();

    // Ajouter l'écouteur d'événement
    window.addEventListener('resize', handleResize);

    // Nettoyer l'écouteur d'événement
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }

  return (
    <div className="fixed bottom-4 left-4 z-50 bg-black bg-opacity-70 text-white text-xs p-2 rounded-md">
      <div>Largeur: {viewport.width}px</div>
      <div>Hauteur: {viewport.height}px</div>
      <div>
        Type: {viewport.isMobile ? 'Mobile' : viewport.isTablet ? 'Tablette' : 'Desktop'}
      </div>
    </div>
  );
}
