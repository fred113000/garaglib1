"use client";

import { useState, useEffect } from 'react';

interface StyleIssue {
  element: string;
  property: string;
  value: string;
  expectedValue: string;
  location: string;
}

export default function VisualConsistencyCheck() {
  const [issues, setIssues] = useState<StyleIssue[]>([]);
  const [showReport, setShowReport] = useState(false);

  useEffect(() => {
    const checkVisualConsistency = () => {
      const newIssues: StyleIssue[] = [];
      const primaryColor = '#1E3A8A'; // Couleur principale définie dans notre thème
      const primaryLightColor = '#3B82F6'; // Couleur secondaire définie dans notre thème
      
      // Vérifier les boutons pour la cohérence des couleurs
      document.querySelectorAll('button').forEach((button, index) => {
        const style = window.getComputedStyle(button);
        const bgColor = style.backgroundColor;
        
        // Vérifier si le bouton a une couleur d'arrière-plan qui n'est ni la couleur principale ni transparente
        if (bgColor !== 'rgba(0, 0, 0, 0)' && 
            bgColor !== primaryColor && 
            bgColor !== primaryLightColor && 
            !bgColor.includes('rgb(243, 244, 246)') && // Couleur grise pour les boutons secondaires
            !bgColor.includes('rgb(229, 231, 235)')) { // Autre couleur grise acceptable
          
          newIssues.push({
            element: `Bouton #${index + 1}`,
            property: 'backgroundColor',
            value: bgColor,
            expectedValue: primaryColor,
            location: button.textContent?.trim() || 'Bouton sans texte'
          });
        }
      });
      
      // Vérifier les polices de caractères
      document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, span, a, button, input, textarea, select').forEach((el) => {
        const style = window.getComputedStyle(el);
        const fontFamily = style.fontFamily;
        
        // Vérifier si la police n'est pas celle définie dans notre thème
        if (!fontFamily.includes('Inter') && !fontFamily.includes('system-ui') && !fontFamily.includes('sans-serif')) {
          newIssues.push({
            element: el.tagName,
            property: 'fontFamily',
            value: fontFamily,
            expectedValue: 'Inter, system-ui, sans-serif',
            location: el.textContent?.trim() || 'Élément sans texte'
          });
        }
      });
      
      // Vérifier les espacements
      const cards = document.querySelectorAll('.card');
      cards.forEach((card, index) => {
        const style = window.getComputedStyle(card);
        const padding = style.padding;
        
        // Vérifier si le padding n'est pas celui défini dans notre thème
        if (padding !== '24px' && padding !== '1.5rem') {
          newIssues.push({
            element: `Card #${index + 1}`,
            property: 'padding',
            value: padding,
            expectedValue: '1.5rem (24px)',
            location: 'Card component'
          });
        }
      });
      
      setIssues(newIssues);
    };
    
    // Exécuter la vérification après le chargement complet de la page
    window.addEventListener('load', checkVisualConsistency);
    
    return () => {
      window.removeEventListener('load', checkVisualConsistency);
    };
  }, []);

  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }

  return (
    <div className="fixed top-4 right-4 z-50">
      <button
        onClick={() => setShowReport(!showReport)}
        className="bg-primary text-white px-3 py-1 rounded-md text-xs"
      >
        {showReport ? 'Masquer' : 'Vérifier'} la cohérence visuelle
      </button>
      
      {showReport && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 max-w-md max-h-96 overflow-y-auto">
          <h3 className="font-bold text-sm mb-2">Rapport de cohérence visuelle</h3>
          
          {issues.length === 0 ? (
            <p className="text-green-600 text-xs">Aucun problème de cohérence visuelle détecté.</p>
          ) : (
            <ul className="space-y-2">
              {issues.map((issue, index) => (
                <li key={index} className="text-xs border-l-4 border-orange-500 pl-2 py-1">
                  <p className="font-medium">{issue.element}: {issue.property}</p>
                  <p className="text-gray-600">Valeur actuelle: {issue.value}</p>
                  <p className="text-gray-600">Valeur attendue: {issue.expectedValue}</p>
                  <p className="text-gray-500 italic">Emplacement: {issue.location}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
