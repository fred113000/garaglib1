"use client";

import { useState, useEffect } from 'react';

interface Bug {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'major' | 'minor';
  status: 'open' | 'in_progress' | 'fixed' | 'closed';
  component: string;
  steps?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export default function BugTracker() {
  const [bugs, setBugs] = useState<Bug[]>([]);
  const [showTracker, setShowTracker] = useState(false);
  const [newBug, setNewBug] = useState<Partial<Bug>>({
    title: '',
    description: '',
    severity: 'major',
    component: '',
    steps: [''],
    status: 'open'
  });
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    // Charger les bugs depuis le localStorage
    const savedBugs = localStorage.getItem('garaglib_bugs');
    if (savedBugs) {
      try {
        const parsedBugs = JSON.parse(savedBugs);
        // Convertir les dates
        const bugsWithDates = parsedBugs.map((bug: any) => ({
          ...bug,
          createdAt: new Date(bug.createdAt),
          updatedAt: new Date(bug.updatedAt)
        }));
        setBugs(bugsWithDates);
      } catch (error) {
        console.error('Erreur lors du chargement des bugs:', error);
      }
    }
  }, []);

  // Sauvegarder les bugs dans le localStorage
  useEffect(() => {
    if (bugs.length > 0) {
      localStorage.setItem('garaglib_bugs', JSON.stringify(bugs));
    }
  }, [bugs]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewBug(prev => ({ ...prev, [name]: value }));
  };

  const handleStepChange = (index: number, value: string) => {
    const updatedSteps = [...(newBug.steps || [''])];
    updatedSteps[index] = value;
    setNewBug(prev => ({ ...prev, steps: updatedSteps }));
  };

  const addStep = () => {
    setNewBug(prev => ({ 
      ...prev, 
      steps: [...(prev.steps || ['']), ''] 
    }));
  };

  const removeStep = (index: number) => {
    const updatedSteps = [...(newBug.steps || [''])];
    updatedSteps.splice(index, 1);
    setNewBug(prev => ({ ...prev, steps: updatedSteps }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const now = new Date();
    const newBugComplete: Bug = {
      id: `bug_${Date.now()}`,
      title: newBug.title || 'Bug sans titre',
      description: newBug.description || 'Aucune description',
      severity: newBug.severity as 'critical' | 'major' | 'minor',
      status: 'open',
      component: newBug.component || 'Non spécifié',
      steps: newBug.steps?.filter(step => step.trim() !== ''),
      createdAt: now,
      updatedAt: now
    };
    
    setBugs(prev => [...prev, newBugComplete]);
    
    // Réinitialiser le formulaire
    setNewBug({
      title: '',
      description: '',
      severity: 'major',
      component: '',
      steps: [''],
      status: 'open'
    });
    
    setShowForm(false);
  };

  const updateBugStatus = (id: string, status: Bug['status']) => {
    setBugs(prev => prev.map(bug => 
      bug.id === id 
        ? { ...bug, status, updatedAt: new Date() } 
        : bug
    ));
  };

  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }

  return (
    <div className="fixed bottom-20 right-4 z-50">
      <button
        onClick={() => setShowTracker(!showTracker)}
        className="bg-red-600 text-white px-3 py-1 rounded-md text-xs flex items-center"
      >
        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        {showTracker ? 'Masquer' : 'Suivi de bugs'} {bugs.filter(b => b.status === 'open').length > 0 && `(${bugs.filter(b => b.status === 'open').length})`}
      </button>
      
      {showTracker && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 w-96 max-h-[80vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-sm">Suivi des bugs</h3>
            <button
              onClick={() => setShowForm(!showForm)}
              className="bg-blue-500 text-white px-2 py-1 rounded text-xs"
            >
              {showForm ? 'Annuler' : 'Nouveau bug'}
            </button>
          </div>
          
          {showForm ? (
            <form onSubmit={handleSubmit} className="mb-4 border p-3 rounded-md bg-gray-50">
              <div className="mb-2">
                <label className="block text-xs font-medium text-gray-700 mb-1">Titre</label>
                <input
                  type="text"
                  name="title"
                  value={newBug.title}
                  onChange={handleInputChange}
                  className="w-full px-2 py-1 text-xs border rounded"
                  required
                />
              </div>
              
              <div className="mb-2">
                <label className="block text-xs font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  name="description"
                  value={newBug.description}
                  onChange={handleInputChange}
                  className="w-full px-2 py-1 text-xs border rounded"
                  rows={3}
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Sévérité</label>
                  <select
                    name="severity"
                    value={newBug.severity}
                    onChange={handleInputChange}
                    className="w-full px-2 py-1 text-xs border rounded"
                  >
                    <option value="critical">Critique</option>
                    <option value="major">Majeur</option>
                    <option value="minor">Mineur</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-700 mb-1">Composant</label>
                  <input
                    type="text"
                    name="component"
                    value={newBug.component}
                    onChange={handleInputChange}
                    className="w-full px-2 py-1 text-xs border rounded"
                    placeholder="ex: Réservation"
                  />
                </div>
              </div>
              
              <div className="mb-2">
                <label className="block text-xs font-medium text-gray-700 mb-1">Étapes pour reproduire</label>
                {newBug.steps?.map((step, index) => (
                  <div key={index} className="flex mb-1">
                    <input
                      type="text"
                      value={step}
                      onChange={(e) => handleStepChange(index, e.target.value)}
                      className="w-full px-2 py-1 text-xs border rounded"
                      placeholder={`Étape ${index + 1}`}
                    />
                    <button
                      type="button"
                      onClick={() => removeStep(index)}
                      className="ml-1 text-red-500"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={addStep}
                  className="text-xs text-blue-500 mt-1"
                >
                  + Ajouter une étape
                </button>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="bg-green-500 text-white px-3 py-1 rounded text-xs"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          ) : null}
          
          {bugs.length === 0 ? (
            <p className="text-gray-500 text-xs text-center py-4">Aucun bug enregistré.</p>
          ) : (
            <div className="space-y-3">
              {bugs.map(bug => (
                <div 
                  key={bug.id} 
                  className="border rounded-md p-2 text-xs"
                  style={{
                    borderLeftWidth: '4px',
                    borderLeftColor: bug.severity === 'critical' ? 'red' : 
                                    bug.severity === 'major' ? 'orange' : 'yellow'
                  }}
                >
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">{bug.title}</h4>
                    <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${
                      bug.status === 'open' ? 'bg-red-100 text-red-800' :
                      bug.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                      bug.status === 'fixed' ? 'bg-green-100 text-green-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {bug.status === 'open' ? 'Ouvert' :
                       bug.status === 'in_progress' ? 'En cours' :
                       bug.status === 'fixed' ? 'Corrigé' : 'Fermé'}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mt-1">{bug.description}</p>
                  
                  <div className="mt-1 flex items-center">
                    <span className="text-gray-500">Composant:</span>
                    <span className="ml-1">{bug.component}</span>
                  </div>
                  
                  {bug.steps && bug.steps.length > 0 && (
                    <div className="mt-1">
                      <p className="text-gray-500">Étapes pour reproduire:</p>
                      <ol className="list-decimal pl-4">
                        {bug.steps.map((step, index) => (
                          <li key={index}>{step}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                  
                  <div className="mt-2 flex justify-between items-center">
                    <span className="text-gray-400 text-[10px]">
                      {bug.createdAt.toLocaleDateString()} {bug.createdAt.toLocaleTimeString()}
                    </span>
                    
                    <div className="flex space-x-1">
                      {bug.status === 'open' && (
                        <button
                          onClick={() => updateBugStatus(bug.id, 'in_progress')}
                          className="bg-blue-500 text-white px-1.5 py-0.5 rounded text-[10px]"
                        >
                          Traiter
                        </button>
                      )}
                      
                      {bug.status === 'in_progress' && (
                        <button
                          onClick={() => updateBugStatus(bug.id, 'fixed')}
                          className="bg-green-500 text-white px-1.5 py-0.5 rounded text-[10px]"
                        >
                          Marquer corrigé
                        </button>
                      )}
                      
                      {bug.status === 'fixed' && (
                        <button
                          onClick={() => updateBugStatus(bug.id, 'closed')}
                          className="bg-gray-500 text-white px-1.5 py-0.5 rounded text-[10px]"
                        >
                          Fermer
                        </button>
                      )}
                      
                      {bug.status === 'closed' && (
                        <button
                          onClick={() => updateBugStatus(bug.id, 'open')}
                          className="bg-red-500 text-white px-1.5 py-0.5 rounded text-[10px]"
                        >
                          Réouvrir
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
