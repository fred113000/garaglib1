"use client";

import { useState, useEffect } from 'react';

interface TestCase {
  id: string;
  name: string;
  description: string;
  category: 'réservation' | 'gestion_créneaux' | 'authentification' | 'fonctionnalités_avancées' | 'autre';
  status: 'pending' | 'passed' | 'failed';
  errorMessage?: string;
}

export default function TestSuite() {
  const [tests, setTests] = useState<TestCase[]>([
    // Tests de réservation
    {
      id: 'res_1',
      name: 'Recherche de garage',
      description: 'Vérifier que la recherche de garage fonctionne correctement avec différents critères',
      category: 'réservation',
      status: 'pending'
    },
    {
      id: 'res_2',
      name: 'Sélection de service',
      description: 'Vérifier que la sélection d\'un service affiche correctement les détails et le prix',
      category: 'réservation',
      status: 'pending'
    },
    {
      id: 'res_3',
      name: 'Sélection de créneau',
      description: 'Vérifier que seuls les créneaux disponibles sont affichés et sélectionnables',
      category: 'réservation',
      status: 'pending'
    },
    {
      id: 'res_4',
      name: 'Validation de réservation',
      description: 'Vérifier que la réservation est correctement enregistrée et confirmée',
      category: 'réservation',
      status: 'pending'
    },
    
    // Tests de gestion des créneaux
    {
      id: 'slot_1',
      name: 'Ajout de créneaux',
      description: 'Vérifier que le garage peut ajouter au moins 5 créneaux',
      category: 'gestion_créneaux',
      status: 'pending'
    },
    {
      id: 'slot_2',
      name: 'Validation minimum 5 créneaux',
      description: 'Vérifier que le système empêche l\'enregistrement si moins de 5 créneaux',
      category: 'gestion_créneaux',
      status: 'pending'
    },
    {
      id: 'slot_3',
      name: 'Modification de créneaux',
      description: 'Vérifier que la modification des créneaux est correctement enregistrée',
      category: 'gestion_créneaux',
      status: 'pending'
    },
    
    // Tests d'authentification
    {
      id: 'auth_1',
      name: 'Inscription client',
      description: 'Vérifier que l\'inscription d\'un nouveau client fonctionne correctement',
      category: 'authentification',
      status: 'pending'
    },
    {
      id: 'auth_2',
      name: 'Connexion garage',
      description: 'Vérifier que la connexion d\'un garage redirige vers le dashboard garage',
      category: 'authentification',
      status: 'pending'
    },
    {
      id: 'auth_3',
      name: 'Connexion admin',
      description: 'Vérifier que la connexion d\'un admin redirige vers le dashboard admin',
      category: 'authentification',
      status: 'pending'
    },
    
    // Tests des fonctionnalités avancées
    {
      id: 'adv_1',
      name: 'Ajout aux favoris',
      description: 'Vérifier que l\'ajout d\'un garage aux favoris fonctionne correctement',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_2',
      name: 'Notifications',
      description: 'Vérifier que les notifications sont correctement générées et affichées',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_3',
      name: 'Dépôt d\'avis',
      description: 'Vérifier que le dépôt d\'un avis est correctement enregistré et affiché',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_4',
      name: 'Upload de fichier',
      description: 'Vérifier que l\'upload de fichier fonctionne correctement',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_5',
      name: 'Export de données',
      description: 'Vérifier que l\'export de données génère un fichier valide',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_6',
      name: 'Chatbot',
      description: 'Vérifier que le chatbot répond correctement aux questions',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_7',
      name: 'Recherche instantanée',
      description: 'Vérifier que la recherche instantanée affiche des résultats pertinents',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    },
    {
      id: 'adv_8',
      name: 'Google Maps',
      description: 'Vérifier que l\'intégration Google Maps affiche correctement les emplacements',
      category: 'fonctionnalités_avancées',
      status: 'pending'
    }
  ]);
  
  const [showTests, setShowTests] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  
  const updateTestStatus = (id: string, status: 'passed' | 'failed', errorMessage?: string) => {
    setTests(prev => prev.map(test => 
      test.id === id 
        ? { ...test, status, errorMessage } 
        : test
    ));
  };
  
  const getTestsByCategory = (category: string) => {
    if (category === 'all') {
      return tests;
    }
    return tests.filter(test => test.category === category);
  };
  
  const getTestStats = () => {
    const total = tests.length;
    const passed = tests.filter(test => test.status === 'passed').length;
    const failed = tests.filter(test => test.status === 'failed').length;
    const pending = tests.filter(test => test.status === 'pending').length;
    
    return { total, passed, failed, pending };
  };
  
  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }
  
  const stats = getTestStats();
  const filteredTests = getTestsByCategory(filter);
  
  return (
    <div className="fixed top-20 left-4 z-50">
      <button
        onClick={() => setShowTests(!showTests)}
        className="bg-indigo-600 text-white px-3 py-1 rounded-md text-xs flex items-center"
      >
        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
        </svg>
        {showTests ? 'Masquer' : 'Tests fonctionnels'} ({stats.passed}/{stats.total})
      </button>
      
      {showTests && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 w-96 max-h-[80vh] overflow-y-auto">
          <h3 className="font-bold text-sm mb-2">Suite de tests fonctionnels</h3>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex space-x-2 text-xs">
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                <span>{stats.passed}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                <span>{stats.failed}</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-gray-300 mr-1"></div>
                <span>{stats.pending}</span>
              </div>
            </div>
            
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="text-xs border rounded px-2 py-1"
            >
              <option value="all">Tous les tests</option>
              <option value="réservation">Réservation</option>
              <option value="gestion_créneaux">Gestion des créneaux</option>
              <option value="authentification">Authentification</option>
              <option value="fonctionnalités_avancées">Fonctionnalités avancées</option>
              <option value="autre">Autre</option>
            </select>
          </div>
          
          <div className="space-y-2">
            {filteredTests.map(test => (
              <div 
                key={test.id} 
                className="border rounded-md p-2 text-xs"
              >
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">{test.name}</h4>
                  <div className="flex space-x-1">
                    <button
                      onClick={() => updateTestStatus(test.id, 'passed')}
                      className={`px-2 py-0.5 rounded text-[10px] ${
                        test.status === 'passed' 
                          ? 'bg-green-500 text-white' 
                          : 'bg-gray-200 text-gray-700'
                      }`}
                    >
                      Réussi
                    </button>
                    <button
                      onClick={() => updateTestStatus(test.id, 'failed', 'Erreur à décrire')}
                      className={`px-2 py-0.5 rounded text-[10px] ${
                        test.status === 'failed' 
                          ? 'bg-red-500 text-white' 
                          : 'bg-gray-200 text-gray-700'
                      }`}
                    >
                      Échec
                    </button>
                  </div>
                </div>
                
                <p className="text-gray-600 mt-1">{test.description}</p>
                
                {test.status === 'failed' && test.errorMessage && (
                  <div className="mt-1 p-1 bg-red-50 border border-red-200 rounded">
                    <p className="text-red-600">{test.errorMessage}</p>
                  </div>
                )}
                
                <div className="mt-1 flex items-center">
                  <span className="text-gray-500">Catégorie:</span>
                  <span className="ml-1 capitalize">{test.category.replace('_', ' ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
