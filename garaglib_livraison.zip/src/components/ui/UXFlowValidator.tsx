"use client";

import { useState, useEffect } from 'react';

interface UserFlow {
  name: string;
  steps: string[];
  status: 'pending' | 'testing' | 'passed' | 'failed';
  issues?: string[];
}

export default function UXFlowValidator() {
  const [flows, setFlows] = useState<UserFlow[]>([
    {
      name: "Réservation d'un créneau",
      steps: [
        "Recherche d'un garage",
        "Sélection d'un garage",
        "Sélection d'un service",
        "Sélection d'un créneau",
        "Saisie des informations du véhicule",
        "Confirmation de la réservation"
      ],
      status: 'pending'
    },
    {
      name: "Gestion des créneaux par le garage",
      steps: [
        "Accès au dashboard garage",
        "Navigation vers la gestion des créneaux",
        "Sélection d'une date",
        "Ajout de 5 créneaux minimum",
        "Enregistrement des modifications"
      ],
      status: 'pending'
    },
    {
      name: "Authentification et gestion de compte",
      steps: [
        "Inscription",
        "Connexion",
        "Modification du profil",
        "Déconnexion"
      ],
      status: 'pending'
    },
    {
      name: "Utilisation des fonctionnalités avancées",
      steps: [
        "Ajout d'un garage aux favoris",
        "Consultation des notifications",
        "Dépôt d'un avis",
        "Upload d'un document",
        "Export de données",
        "Utilisation du chatbot",
        "Recherche instantanée"
      ],
      status: 'pending'
    }
  ]);
  const [showReport, setShowReport] = useState(false);
  const [activeFlow, setActiveFlow] = useState<number | null>(null);
  const [currentStep, setCurrentStep] = useState<number>(0);

  const startFlowTest = (index: number) => {
    setActiveFlow(index);
    setCurrentStep(0);
    
    const updatedFlows = [...flows];
    updatedFlows[index].status = 'testing';
    updatedFlows[index].issues = [];
    setFlows(updatedFlows);
  };

  const completeStep = (success: boolean, issue?: string) => {
    if (activeFlow === null) return;
    
    const updatedFlows = [...flows];
    const flow = updatedFlows[activeFlow];
    
    if (!success && issue) {
      if (!flow.issues) flow.issues = [];
      flow.issues.push(`Étape ${currentStep + 1} (${flow.steps[currentStep]}): ${issue}`);
    }
    
    if (currentStep < flow.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Flux terminé
      flow.status = flow.issues && flow.issues.length > 0 ? 'failed' : 'passed';
      setActiveFlow(null);
    }
    
    setFlows(updatedFlows);
  };

  const cancelFlowTest = () => {
    if (activeFlow === null) return;
    
    const updatedFlows = [...flows];
    updatedFlows[activeFlow].status = 'pending';
    setFlows(updatedFlows);
    setActiveFlow(null);
  };

  if (process.env.NODE_ENV === 'production') {
    return null; // Ne pas afficher en production
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={() => setShowReport(!showReport)}
        className="bg-purple-600 text-white px-3 py-1 rounded-md text-xs"
      >
        {showReport ? 'Masquer' : 'Vérifier'} les parcours utilisateur
      </button>
      
      {showReport && (
        <div className="mt-2 bg-white shadow-lg rounded-md p-4 max-w-md max-h-96 overflow-y-auto">
          <h3 className="font-bold text-sm mb-2">Validation des parcours utilisateur</h3>
          
          {activeFlow !== null ? (
            <div className="mb-4">
              <h4 className="font-medium text-sm">{flows[activeFlow].name}</h4>
              <p className="text-xs text-gray-600 mb-2">
                Étape {currentStep + 1}/{flows[activeFlow].steps.length}: {flows[activeFlow].steps[currentStep]}
              </p>
              <div className="flex space-x-2">
                <button 
                  onClick={() => completeStep(true)}
                  className="bg-green-500 text-white px-2 py-1 rounded text-xs"
                >
                  Réussi
                </button>
                <button 
                  onClick={() => completeStep(false, "Problème à décrire")}
                  className="bg-red-500 text-white px-2 py-1 rounded text-xs"
                >
                  Échec
                </button>
                <button 
                  onClick={cancelFlowTest}
                  className="bg-gray-500 text-white px-2 py-1 rounded text-xs"
                >
                  Annuler
                </button>
              </div>
            </div>
          ) : (
            <ul className="space-y-3">
              {flows.map((flow, index) => (
                <li key={index} className="text-xs border-l-4 pl-2 py-1" style={{
                  borderColor: flow.status === 'passed' ? 'green' : 
                              flow.status === 'failed' ? 'red' : 
                              flow.status === 'testing' ? 'blue' : 'gray'
                }}>
                  <div className="flex justify-between items-center">
                    <p className="font-medium">{flow.name}</p>
                    {flow.status === 'pending' && (
                      <button 
                        onClick={() => startFlowTest(index)}
                        className="bg-blue-500 text-white px-2 py-0.5 rounded text-xs"
                      >
                        Tester
                      </button>
                    )}
                    {flow.status === 'passed' && (
                      <span className="text-green-500">✓ Validé</span>
                    )}
                    {flow.status === 'failed' && (
                      <span className="text-red-500">✗ Échec</span>
                    )}
                    {flow.status === 'testing' && (
                      <span className="text-blue-500">En cours...</span>
                    )}
                  </div>
                  
                  {flow.issues && flow.issues.length > 0 && (
                    <div className="mt-1 pl-2 border-l-2 border-red-300">
                      <p className="font-medium text-red-600">Problèmes détectés:</p>
                      <ul className="list-disc pl-4">
                        {flow.issues.map((issue, i) => (
                          <li key={i} className="text-red-600">{issue}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
