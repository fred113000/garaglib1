// src/components/shared/GoogleMapsLocation.tsx
import { useEffect, useRef, useState } from 'react';

interface GoogleMapsLocationProps {
  address?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  height?: string;
  zoom?: number;
  interactive?: boolean;
  onLocationSelect?: (location: { lat: number; lng: number; address: string }) => void;
}

declare global {
  interface Window {
    initMap: () => void;
    google: any;
  }
}

export default function GoogleMapsLocation({
  address,
  coordinates,
  height = '400px',
  zoom = 15,
  interactive = true,
  onLocationSelect
}: GoogleMapsLocationProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [map, setMap] = useState<any>(null);
  const [marker, setMarker] = useState<any>(null);
  const [selectedLocation, setSelectedLocation] = useState<{
    lat: number;
    lng: number;
    address: string;
  } | null>(null);

  // Charger l'API Google Maps
  useEffect(() => {
    if (!mapLoaded) {
      const googleMapsScript = document.createElement('script');
      googleMapsScript.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places&callback=initMap`;
      googleMapsScript.async = true;
      googleMapsScript.defer = true;
      
      window.initMap = () => {
        setMapLoaded(true);
      };
      
      document.head.appendChild(googleMapsScript);
      
      return () => {
        document.head.removeChild(googleMapsScript);
        delete window.initMap;
      };
    }
  }, [mapLoaded]);

  // Initialiser la carte une fois l'API chargée
  useEffect(() => {
    if (mapLoaded && mapRef.current) {
      const initialLocation = coordinates || { lat: 48.8566, lng: 2.3522 }; // Paris par défaut
      
      const mapOptions = {
        center: initialLocation,
        zoom,
        disableDefaultUI: !interactive,
        zoomControl: interactive,
        scrollwheel: interactive,
        draggable: interactive
      };
      
      const newMap = new window.google.maps.Map(mapRef.current, mapOptions);
      setMap(newMap);
      
      // Créer un marqueur initial
      const newMarker = new window.google.maps.Marker({
        position: initialLocation,
        map: newMap,
        draggable: interactive
      });
      setMarker(newMarker);
      
      // Si une adresse est fournie, géocoder pour obtenir les coordonnées
      if (address && !coordinates) {
        const geocoder = new window.google.maps.Geocoder();
        geocoder.geocode({ address }, (results: any, status: any) => {
          if (status === 'OK' && results[0]) {
            const location = results[0].geometry.location;
            newMap.setCenter(location);
            newMarker.setPosition(location);
            
            setSelectedLocation({
              lat: location.lat(),
              lng: location.lng(),
              address: results[0].formatted_address
            });
          }
        });
      } else if (coordinates) {
        setSelectedLocation({
          lat: coordinates.lat,
          lng: coordinates.lng,
          address: address || ''
        });
      }
      
      // Ajouter des événements si la carte est interactive
      if (interactive && onLocationSelect) {
        // Événement de clic sur la carte
        newMap.addListener('click', (e: any) => {
          newMarker.setPosition(e.latLng);
          
          // Géocoder pour obtenir l'adresse
          const geocoder = new window.google.maps.Geocoder();
          geocoder.geocode({ location: e.latLng }, (results: any, status: any) => {
            if (status === 'OK' && results[0]) {
              const newLocation = {
                lat: e.latLng.lat(),
                lng: e.latLng.lng(),
                address: results[0].formatted_address
              };
              
              setSelectedLocation(newLocation);
              onLocationSelect(newLocation);
            }
          });
        });
        
        // Événement de fin de glisser-déposer du marqueur
        newMarker.addListener('dragend', () => {
          const position = newMarker.getPosition();
          
          // Géocoder pour obtenir l'adresse
          const geocoder = new window.google.maps.Geocoder();
          geocoder.geocode({ location: position }, (results: any, status: any) => {
            if (status === 'OK' && results[0]) {
              const newLocation = {
                lat: position.lat(),
                lng: position.lng(),
                address: results[0].formatted_address
              };
              
              setSelectedLocation(newLocation);
              onLocationSelect(newLocation);
            }
          });
        });
      }
    }
  }, [mapLoaded, address, coordinates, zoom, interactive, onLocationSelect]);

  return (
    <div className="w-full">
      <div 
        ref={mapRef} 
        className="w-full rounded-lg overflow-hidden"
        style={{ height }}
      ></div>
      
      {interactive && selectedLocation && (
        <div className="mt-2 text-sm text-gray-600">
          <p><strong>Adresse:</strong> {selectedLocation.address}</p>
          <p><strong>Coordonnées:</strong> {selectedLocation.lat.toFixed(6)}, {selectedLocation.lng.toFixed(6)}</p>
        </div>
      )}
    </div>
  );
}
