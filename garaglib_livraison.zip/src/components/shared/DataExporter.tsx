// src/components/shared/DataExporter.tsx
import { useState } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';

interface DataExporterProps {
  garageId?: string;
  userId?: string;
  dataType: 'appointments' | 'services' | 'clients' | 'reviews';
  buttonLabel?: string;
  className?: string;
}

export default function DataExporter({ 
  garageId, 
  userId, 
  dataType, 
  buttonLabel = 'Exporter les données', 
  className = '' 
}: DataExporterProps) {
  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const exportData = async () => {
    setExporting(true);
    setError(null);
    
    try {
      let q;
      
      // Construire la requête en fonction du type de données et des filtres
      if (dataType === 'appointments') {
        q = garageId 
          ? query(collection(db, 'appointments'), where('garageId', '==', garageId))
          : userId 
            ? query(collection(db, 'appointments'), where('clientId', '==', userId))
            : query(collection(db, 'appointments'));
      } else if (dataType === 'services') {
        q = garageId 
          ? query(collection(db, 'services'), where('garageId', '==', garageId))
          : query(collection(db, 'services'));
      } else if (dataType === 'clients') {
        q = garageId 
          ? query(collection(db, 'appointments'), where('garageId', '==', garageId))
          : query(collection(db, 'users'), where('role', '==', 'client'));
      } else if (dataType === 'reviews') {
        q = garageId 
          ? query(collection(db, 'reviews'), where('garageId', '==', garageId))
          : userId 
            ? query(collection(db, 'reviews'), where('clientId', '==', userId))
            : query(collection(db, 'reviews'));
      }
      
      // Récupérer les données
      const querySnapshot = await getDocs(q);
      const data: any[] = [];
      
      querySnapshot.forEach((doc) => {
        const docData = doc.data();
        
        // Convertir les timestamps en dates lisibles
        const formattedData = Object.entries(docData).reduce((acc, [key, value]) => {
          if (value && typeof value === 'object' && 'toDate' in value) {
            acc[key] = value.toDate().toISOString();
          } else {
            acc[key] = value;
          }
          return acc;
        }, {} as Record<string, any>);
        
        data.push({
          id: doc.id,
          ...formattedData
        });
      });
      
      // Créer un fichier CSV ou JSON
      const fileName = `${dataType}_${new Date().toISOString().split('T')[0]}.json`;
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Télécharger le fichier
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
    } catch (err) {
      console.error('Erreur lors de l\'export des données:', err);
      setError('Une erreur est survenue lors de l\'export des données.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div>
      <button
        onClick={exportData}
        disabled={exporting}
        className={`px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
      >
        {exporting ? 'Export en cours...' : buttonLabel}
      </button>
      
      {error && (
        <p className="mt-2 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
}
