"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';

// Interface pour les notifications
interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'appointment' | 'quote' | 'system';
  status: 'unread' | 'read';
  createdAt: Date;
  link?: string;
}

export default function NotificationSystem() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();

  // Charger les notifications au chargement du composant
  useEffect(() => {
    const loadNotifications = async () => {
      if (!user) return;

      try {
        setIsLoading(true);
        // Simulation de chargement des notifications depuis Firebase
        // Dans une implémentation réelle, nous utiliserions une fonction Firebase
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Données de test
        const mockNotifications: Notification[] = [
          {
            id: 'notif1',
            userId: user.id,
            title: 'Nouveau rendez-vous',
            message: 'Jean Dupont a demandé un rendez-vous pour une vidange le 21/05/2025 à 09:00.',
            type: 'appointment',
            status: 'unread',
            createdAt: new Date(2025, 4, 20, 14, 30),
            link: '/garage/dashboard'
          },
          {
            id: 'notif2',
            userId: user.id,
            title: 'Devis accepté',
            message: 'Marie Martin a accepté votre devis de 399,98€ pour une révision complète.',
            type: 'quote',
            status: 'unread',
            createdAt: new Date(2025, 4, 19, 10, 15),
            link: '/garage/quotes'
          },
          {
            id: 'notif3',
            userId: user.id,
            title: 'Rappel de rendez-vous',
            message: 'Vous avez un rendez-vous demain avec Pierre Durand à 11:00 pour un diagnostic électronique.',
            type: 'appointment',
            status: 'read',
            createdAt: new Date(2025, 4, 21, 8, 0),
            link: '/garage/dashboard'
          }
        ];
        
        setNotifications(mockNotifications);
      } catch (error) {
        console.error('Erreur lors du chargement des notifications:', error);
        setError('Impossible de charger les notifications.');
      } finally {
        setIsLoading(false);
      }
    };

    loadNotifications();
  }, [user]);

  // Marquer une notification comme lue
  const markAsRead = async (notificationId: string) => {
    try {
      // Dans une implémentation réelle, nous utiliserions une fonction Firebase
      // pour mettre à jour le statut de la notification
      
      // Simuler une mise à jour
      setNotifications(prev => 
        prev.map(notification => 
          notification.id === notificationId 
            ? { ...notification, status: 'read' as const } 
            : notification
        )
      );
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la notification:', error);
    }
  };

  // Marquer toutes les notifications comme lues
  const markAllAsRead = async () => {
    try {
      // Dans une implémentation réelle, nous utiliserions une fonction Firebase
      // pour mettre à jour le statut de toutes les notifications
      
      // Simuler une mise à jour
      setNotifications(prev => 
        prev.map(notification => ({ ...notification, status: 'read' as const }))
      );
    } catch (error) {
      console.error('Erreur lors de la mise à jour des notifications:', error);
    }
  };

  // Compter les notifications non lues
  const unreadCount = notifications.filter(notification => notification.status === 'unread').length;

  // Si l'utilisateur n'est pas connecté, ne pas afficher le composant
  if (!user) {
    return null;
  }

  return (
    <div className="relative">
      {/* Bouton de notification */}
      <button
        className="relative p-1 rounded-full text-gray-600 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="sr-only">Notifications</span>
        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
        
        {/* Badge de notification */}
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-xs text-white font-bold flex items-center justify-center">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>
      
      {/* Panneau de notifications */}
      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-80 sm:w-96 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
          <div className="py-2 px-4 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-lg font-medium text-gray-900">Notifications</h3>
            {unreadCount > 0 && (
              <button
                className="text-sm text-primary hover:text-primary-dark"
                onClick={markAllAsRead}
              >
                Tout marquer comme lu
              </button>
            )}
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {isLoading ? (
              <div className="flex justify-center items-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : notifications.length === 0 ? (
              <div className="py-8 text-center">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <p className="mt-2 text-gray-500">Aucune notification</p>
              </div>
            ) : (
              <div>
                {notifications
                  .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
                  .map((notification) => (
                    <div
                      key={notification.id}
                      className={`px-4 py-3 border-b border-gray-200 hover:bg-gray-50 ${
                        notification.status === 'unread' ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => {
                        if (notification.status === 'unread') {
                          markAsRead(notification.id);
                        }
                        if (notification.link) {
                          // Dans une implémentation réelle, nous utiliserions un router pour naviguer
                          console.log(`Naviguer vers: ${notification.link}`);
                        }
                        setIsOpen(false);
                      }}
                    >
                      <div className="flex items-start">
                        <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                          notification.type === 'appointment' ? 'bg-blue-100 text-blue-500' :
                          notification.type === 'quote' ? 'bg-green-100 text-green-500' :
                          'bg-gray-100 text-gray-500'
                        }`}>
                          {notification.type === 'appointment' ? (
                            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                          ) : notification.type === 'quote' ? (
                            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                          ) : (
                            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                          )}
                        </div>
                        <div className="ml-3 flex-1">
                          <p className="text-sm font-medium text-gray-900">{notification.title}</p>
                          <p className="text-sm text-gray-500 mt-1">{notification.message}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {notification.createdAt.toLocaleDateString()} à {notification.createdAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                        {notification.status === 'unread' && (
                          <div className="ml-2 flex-shrink-0">
                            <span className="inline-block h-2 w-2 rounded-full bg-blue-500"></span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            )}
          </div>
          
          {notifications.length > 0 && (
            <div className="py-2 px-4 border-t border-gray-200 text-center">
              <button
                className="text-sm text-primary hover:text-primary-dark"
                onClick={() => {
                  // Dans une implémentation réelle, nous naviguerions vers une page de toutes les notifications
                  console.log('Voir toutes les notifications');
                  setIsOpen(false);
                }}
              >
                Voir toutes les notifications
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
