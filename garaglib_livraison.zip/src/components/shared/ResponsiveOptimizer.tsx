"use client";

import { useState, useEffect } from 'react';
import { useMediaQuery } from 'react-responsive';

// Composant pour gérer l'optimisation responsive
export default function ResponsiveOptimizer({ children }: { children: React.ReactNode }) {
  const [isMounted, setIsMounted] = useState(false);
  
  // Détection des breakpoints
  const isMobile = useMediaQuery({ maxWidth: 639 });
  const isTablet = useMediaQuery({ minWidth: 640, maxWidth: 1023 });
  const isDesktop = useMediaQuery({ minWidth: 1024 });
  
  // Éviter les problèmes d'hydratation en attendant le montage côté client
  useEffect(() => {
    setIsMounted(true);
  }, []);

  // Ajouter des classes CSS spécifiques en fonction du device
  const getDeviceSpecificClasses = () => {
    if (!isMounted) return '';
    
    if (isMobile) {
      return 'mobile-device';
    } else if (isTablet) {
      return 'tablet-device';
    } else if (isDesktop) {
      return 'desktop-device';
    }
    
    return '';
  };

  // Optimiser les interactions tactiles sur mobile
  useEffect(() => {
    if (isMounted && (isMobile || isTablet)) {
      // Améliorer la réactivité des éléments tactiles
      document.documentElement.style.setProperty('--touch-target-size', '44px');
      
      // Désactiver le zoom sur les inputs pour éviter les problèmes d'UI
      const metaViewport = document.querySelector('meta[name=viewport]');
      if (metaViewport) {
        metaViewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0');
      }
      
      // Améliorer le défilement sur iOS
      document.documentElement.style.setProperty('-webkit-overflow-scrolling', 'touch');
    }
    
    return () => {
      // Nettoyer les modifications
      if (isMounted) {
        document.documentElement.style.removeProperty('--touch-target-size');
        const metaViewport = document.querySelector('meta[name=viewport]');
        if (metaViewport) {
          metaViewport.setAttribute('content', 'width=device-width, initial-scale=1.0');
        }
        document.documentElement.style.removeProperty('-webkit-overflow-scrolling');
      }
    };
  }, [isMounted, isMobile, isTablet]);

  // Optimiser le chargement des ressources en fonction du device
  useEffect(() => {
    if (isMounted) {
      if (isMobile) {
        // Charger des images de plus basse résolution sur mobile
        document.documentElement.style.setProperty('--image-quality', 'low');
      } else {
        document.documentElement.style.setProperty('--image-quality', 'high');
      }
    }
    
    return () => {
      if (isMounted) {
        document.documentElement.style.removeProperty('--image-quality');
      }
    };
  }, [isMounted, isMobile]);

  // Ajouter des styles globaux pour l'optimisation responsive
  useEffect(() => {
    if (isMounted) {
      // Créer un élément style
      const styleElement = document.createElement('style');
      styleElement.id = 'responsive-optimizer-styles';
      
      // Définir les styles
      styleElement.innerHTML = `
        /* Optimisations mobiles */
        @media (max-width: 639px) {
          .mobile-hidden {
            display: none !important;
          }
          
          .mobile-full-width {
            width: 100% !important;
          }
          
          .mobile-text-center {
            text-align: center !important;
          }
          
          .mobile-py-2 {
            padding-top: 0.5rem !important;
            padding-bottom: 0.5rem !important;
          }
          
          .mobile-px-4 {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
          }
          
          .mobile-stack {
            flex-direction: column !important;
          }
          
          .mobile-stack > * {
            width: 100% !important;
            margin-left: 0 !important;
            margin-right: 0 !important;
            margin-bottom: 0.5rem !important;
          }
          
          .mobile-stack > *:last-child {
            margin-bottom: 0 !important;
          }
          
          /* Améliorer la taille des éléments tactiles */
          button, 
          [role="button"],
          a,
          input[type="submit"],
          input[type="button"],
          input[type="reset"] {
            min-height: var(--touch-target-size, 44px);
            min-width: var(--touch-target-size, 44px);
          }
          
          /* Améliorer la lisibilité des textes */
          body {
            font-size: 16px !important;
          }
          
          /* Optimiser les tableaux pour mobile */
          table {
            display: block;
            overflow-x: auto;
            white-space: nowrap;
          }
        }
        
        /* Optimisations tablettes */
        @media (min-width: 640px) and (max-width: 1023px) {
          .tablet-hidden {
            display: none !important;
          }
          
          /* Améliorer la taille des éléments tactiles */
          button, 
          [role="button"],
          a,
          input[type="submit"],
          input[type="button"],
          input[type="reset"] {
            min-height: var(--touch-target-size, 44px);
          }
        }
      `;
      
      // Ajouter les styles au document
      document.head.appendChild(styleElement);
      
      // Nettoyer les styles lors du démontage
      return () => {
        const element = document.getElementById('responsive-optimizer-styles');
        if (element) {
          element.remove();
        }
      };
    }
  }, [isMounted]);

  if (!isMounted) {
    // Rendu initial côté serveur ou pendant l'hydratation
    return <>{children}</>;
  }

  // Ajouter la classe de device au conteneur
  return (
    <div className={getDeviceSpecificClasses()}>
      {children}
    </div>
  );
}
