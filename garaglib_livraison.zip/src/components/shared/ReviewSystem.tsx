// src/components/shared/ReviewSystem.tsx
import { useState } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';

interface ReviewSystemProps {
  garageId: string;
  appointmentId?: string;
  onSubmit: (reviewData: any) => void;
}

export default function ReviewSystem({ garageId, appointmentId, onSubmit }: ReviewSystemProps) {
  const { user } = useAuth();
  const [rating, setRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');
  const [hoveredRating, setHoveredRating] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleRatingClick = (value: number) => {
    setRating(value);
  };

  const handleRatingHover = (value: number) => {
    setHoveredRating(value);
  };

  const handleRatingLeave = () => {
    setHoveredRating(0);
  };

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setComment(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
      window.location.href = '/login?redirect=' + encodeURIComponent(window.location.pathname);
      return;
    }
    
    if (rating === 0) {
      alert('Veuillez sélectionner une note');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const reviewData = {
        garageId,
        clientId: user.uid,
        appointmentId,
        rating,
        comment,
        createdAt: new Date(),
        isPublished: true
      };
      
      await onSubmit(reviewData);
      
      // Réinitialiser le formulaire
      setRating(0);
      setComment('');
      
      alert('Merci pour votre avis !');
    } catch (error) {
      console.error('Erreur lors de la soumission de l\'avis:', error);
      alert('Une erreur est survenue lors de la soumission de votre avis. Veuillez réessayer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-semibold mb-4">Donnez votre avis</h3>
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <p className="text-sm font-medium text-gray-700 mb-2">Votre note</p>
          <div 
            className="flex space-x-1" 
            onMouseLeave={handleRatingLeave}
          >
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => handleRatingClick(value)}
                onMouseEnter={() => handleRatingHover(value)}
                className="focus:outline-none"
              >
                <svg 
                  className={`w-8 h-8 ${
                    (hoveredRating >= value || (!hoveredRating && rating >= value)) 
                      ? 'text-yellow-400' 
                      : 'text-gray-300'
                  }`} 
                  fill="currentColor" 
                  viewBox="0 0 20 20" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
              </button>
            ))}
            <span className="ml-2 text-sm text-gray-600">
              {rating > 0 ? `${rating}/5` : 'Sélectionnez une note'}
            </span>
          </div>
        </div>
        
        <div className="mb-4">
          <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
            Votre commentaire
          </label>
          <textarea
            id="comment"
            rows={4}
            value={comment}
            onChange={handleCommentChange}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
            placeholder="Partagez votre expérience avec ce garage..."
            required
          ></textarea>
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting || rating === 0}
            className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary-light transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Envoi en cours...' : 'Soumettre mon avis'}
          </button>
        </div>
      </form>
    </div>
  );
}
