// src/components/shared/FileUploader.tsx
import { useState, useRef } from 'react';
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';

interface FileUploaderProps {
  folder: string;
  onUploadComplete: (url: string, fileName: string) => void;
  allowedTypes?: string[];
  maxSizeMB?: number;
}

export default function FileUploader({ 
  folder, 
  onUploadComplete, 
  allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'],
  maxSizeMB = 5
}: FileUploaderProps) {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    const file = files[0];
    
    // Vérifier le type de fichier
    if (!allowedTypes.includes(file.type)) {
      setError(`Type de fichier non autorisé. Types acceptés: ${allowedTypes.join(', ')}`);
      return;
    }
    
    // Vérifier la taille du fichier
    const maxSizeBytes = maxSizeMB * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setError(`Le fichier est trop volumineux. Taille maximale: ${maxSizeMB}MB`);
      return;
    }
    
    setError(null);
    setUploading(true);
    setProgress(0);
    
    try {
      const storage = getStorage();
      const timestamp = new Date().getTime();
      const fileName = `${timestamp}_${file.name}`;
      const storageRef = ref(storage, `${folder}/${fileName}`);
      
      const uploadTask = uploadBytesResumable(storageRef, file);
      
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          setProgress(progress);
        },
        (error) => {
          console.error('Erreur lors de l\'upload:', error);
          setError('Une erreur est survenue lors de l\'upload du fichier.');
          setUploading(false);
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          onUploadComplete(downloadURL, fileName);
          setUploading(false);
          setProgress(0);
          
          // Réinitialiser l'input file
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        }
      );
    } catch (error) {
      console.error('Erreur lors de l\'upload:', error);
      setError('Une erreur est survenue lors de l\'upload du fichier.');
      setUploading(false);
    }
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-center w-full">
        <label
          htmlFor="file-upload"
          className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer ${
            error ? 'border-red-300 bg-red-50' : 'border-gray-300 bg-gray-50'
          } hover:bg-gray-100`}
        >
          {uploading ? (
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <p className="mb-2 text-sm text-gray-500">Upload en cours...</p>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4 max-w-xs">
                <div 
                  className="bg-primary h-2.5 rounded-full" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-xs text-gray-500">{Math.round(progress)}%</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <svg
                className="w-8 h-8 mb-4 text-gray-500"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 20 16"
              >
                <path
                  stroke="currentColor"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                />
              </svg>
              <p className="mb-2 text-sm text-gray-500">
                <span className="font-semibold">Cliquez pour uploader</span> ou glissez-déposez
              </p>
              <p className="text-xs text-gray-500">
                {allowedTypes.join(', ')} (Max. {maxSizeMB}MB)
              </p>
            </div>
          )}
          <input
            id="file-upload"
            ref={fileInputRef}
            type="file"
            className="hidden"
            onChange={handleFileChange}
            disabled={uploading}
            accept={allowedTypes.join(',')}
          />
        </label>
      </div>
      
      {error && (
        <p className="mt-2 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
}
