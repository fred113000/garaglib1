// src/components/shared/InstantSearch.tsx
import { useState, useEffect, useRef } from 'react';
import { collection, query, where, orderBy, limit, getDocs, startAt, endAt } from 'firebase/firestore';
import { db } from '@/lib/firebase/config';
import Link from 'next/link';

interface SearchResult {
  id: string;
  type: 'garage' | 'service';
  name: string;
  description?: string;
  location?: string;
  rating?: number;
  imageUrl?: string;
  url: string;
}

export default function InstantSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  // Fermer les résultats lorsqu'on clique en dehors
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Effectuer la recherche lorsque le terme de recherche change
  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (searchTerm.length >= 2) {
        setLoading(true);
        setShowResults(true);
        
        try {
          const results = await searchData(searchTerm);
          setResults(results);
        } catch (error) {
          console.error('Erreur lors de la recherche:', error);
          setResults([]);
        } finally {
          setLoading(false);
        }
      } else {
        setResults([]);
        setShowResults(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  // Fonction de recherche dans Firestore
  const searchData = async (term: string): Promise<SearchResult[]> => {
    const results: SearchResult[] = [];
    const searchTermLower = term.toLowerCase();
    const searchTermUpper = term.charAt(0).toUpperCase() + term.slice(1);
    
    // Recherche dans les garages
    const garagesQuery = query(
      collection(db, 'garages'),
      where('isActive', '==', true),
      orderBy('name'),
      startAt(searchTermLower),
      endAt(searchTermLower + '\uf8ff'),
      limit(5)
    );
    
    const garagesSnapshot = await getDocs(garagesQuery);
    
    garagesSnapshot.forEach(doc => {
      const data = doc.data();
      results.push({
        id: doc.id,
        type: 'garage',
        name: data.name,
        description: data.description,
        location: `${data.address.city}, ${data.address.zipCode}`,
        rating: data.rating,
        imageUrl: data.photos && data.photos.length > 0 ? data.photos[0] : undefined,
        url: `/booking/${doc.id}`
      });
    });
    
    // Recherche dans les services
    const servicesQuery = query(
      collection(db, 'services'),
      where('isActive', '==', true),
      orderBy('name'),
      startAt(searchTermLower),
      endAt(searchTermLower + '\uf8ff'),
      limit(5)
    );
    
    const servicesSnapshot = await getDocs(servicesQuery);
    
    servicesSnapshot.forEach(doc => {
      const data = doc.data();
      results.push({
        id: doc.id,
        type: 'service',
        name: data.name,
        description: data.description,
        url: `/search?service=${doc.id}`
      });
    });
    
    // Recherche avec première lettre en majuscule
    if (searchTermLower !== searchTermUpper) {
      const garagesUpperQuery = query(
        collection(db, 'garages'),
        where('isActive', '==', true),
        orderBy('name'),
        startAt(searchTermUpper),
        endAt(searchTermUpper + '\uf8ff'),
        limit(5)
      );
      
      const garagesUpperSnapshot = await getDocs(garagesUpperQuery);
      
      garagesUpperSnapshot.forEach(doc => {
        // Vérifier si ce résultat n'est pas déjà dans la liste
        if (!results.some(r => r.id === doc.id && r.type === 'garage')) {
          const data = doc.data();
          results.push({
            id: doc.id,
            type: 'garage',
            name: data.name,
            description: data.description,
            location: `${data.address.city}, ${data.address.zipCode}`,
            rating: data.rating,
            imageUrl: data.photos && data.photos.length > 0 ? data.photos[0] : undefined,
            url: `/booking/${doc.id}`
          });
        }
      });
      
      const servicesUpperQuery = query(
        collection(db, 'services'),
        where('isActive', '==', true),
        orderBy('name'),
        startAt(searchTermUpper),
        endAt(searchTermUpper + '\uf8ff'),
        limit(5)
      );
      
      const servicesUpperSnapshot = await getDocs(servicesUpperQuery);
      
      servicesUpperSnapshot.forEach(doc => {
        // Vérifier si ce résultat n'est pas déjà dans la liste
        if (!results.some(r => r.id === doc.id && r.type === 'service')) {
          const data = doc.data();
          results.push({
            id: doc.id,
            type: 'service',
            name: data.name,
            description: data.description,
            url: `/search?service=${doc.id}`
          });
        }
      });
    }
    
    return results.slice(0, 10); // Limiter à 10 résultats au total
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  const handleInputFocus = () => {
    if (searchTerm.length >= 2) {
      setShowResults(true);
    }
  };

  return (
    <div className="relative" ref={searchRef}>
      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={handleInputChange}
          onFocus={handleInputFocus}
          placeholder="Rechercher un garage ou un service..."
          className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-light"
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute inset-y-0 right-0 pr-3 flex items-center"
          >
            <svg className="w-5 h-5 text-gray-400 hover:text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
      
      {showResults && (
        <div className="absolute z-10 w-full mt-1 bg-white rounded-md shadow-lg max-h-96 overflow-y-auto">
          {loading ? (
            <div className="p-4 text-center text-gray-500">
              <div className="inline-block animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-primary mr-2"></div>
              Recherche en cours...
            </div>
          ) : results.length > 0 ? (
            <ul>
              {results.map(result => (
                <li key={`${result.type}-${result.id}`} className="border-b last:border-b-0">
                  <Link href={result.url} className="block p-4 hover:bg-gray-50">
                    <div className="flex items-start">
                      {result.imageUrl && (
                        <div className="flex-shrink-0 mr-3">
                          <div 
                            className="w-12 h-12 bg-gray-200 rounded-md bg-cover bg-center" 
                            style={{ backgroundImage: `url(${result.imageUrl})` }}
                          ></div>
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <h4 className="text-sm font-medium text-gray-900">{result.name}</h4>
                          <span className="text-xs text-gray-500 capitalize">{result.type}</span>
                        </div>
                        {result.description && (
                          <p className="text-xs text-gray-600 mt-1 line-clamp-1">{result.description}</p>
                        )}
                        {result.location && (
                          <p className="text-xs text-gray-500 mt-1">{result.location}</p>
                        )}
                        {result.rating !== undefined && (
                          <div className="flex items-center mt-1">
                            <div className="flex text-yellow-400">
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                              </svg>
                            </div>
                            <span className="text-xs text-gray-600 ml-1">{result.rating.toFixed(1)}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          ) : searchTerm.length >= 2 ? (
            <div className="p-4 text-center text-gray-500">
              Aucun résultat trouvé pour "{searchTerm}"
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}
