"use client";

import { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase/config';

// Interface pour la synchronisation temps réel
export default function RealtimeSynchronization({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [isReady, setIsReady] = useState(false);

  // Gérer l'authentification en temps réel
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setIsAuthenticated(!!user);
      setUserId(user ? user.uid : null);
      setIsReady(true);
    });

    return () => {
      unsubscribeAuth();
    };
  }, []);

  // Synchroniser les données utilisateur en temps réel
  useEffect(() => {
    if (!userId) return;

    // Synchroniser le profil utilisateur
    const userDocRef = doc(db, 'users', userId);
    const unsubscribeUser = onSnapshot(userDocRef, (docSnapshot) => {
      if (docSnapshot.exists()) {
        // Mettre à jour les données utilisateur dans le localStorage pour un accès rapide
        localStorage.setItem('user_data', JSON.stringify({
          ...docSnapshot.data(),
          lastSynced: new Date().toISOString()
        }));
      }
    }, (error) => {
      console.error('Erreur lors de la synchronisation du profil utilisateur:', error);
    });

    // Synchroniser les notifications en temps réel
    const notificationsQuery = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      where('status', '==', 'unread'),
      orderBy('createdAt', 'desc')
    );
    
    const unsubscribeNotifications = onSnapshot(notificationsQuery, (querySnapshot) => {
      const notifications = [];
      querySnapshot.forEach((doc) => {
        notifications.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      // Mettre à jour les notifications dans le localStorage
      localStorage.setItem('user_notifications', JSON.stringify({
        items: notifications,
        lastSynced: new Date().toISOString()
      }));
      
      // Déclencher un événement personnalisé pour informer les composants des nouvelles notifications
      const event = new CustomEvent('notificationsUpdated', { detail: notifications });
      window.dispatchEvent(event);
    }, (error) => {
      console.error('Erreur lors de la synchronisation des notifications:', error);
    });

    // Synchroniser les rendez-vous en temps réel (pour les garages)
    let unsubscribeAppointments = () => {};
    
    // Vérifier si l'utilisateur est un garage
    const checkUserRole = async () => {
      try {
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists() && userDoc.data().role === 'garage') {
          const garageId = userDoc.data().garageId;
          
          if (garageId) {
            const appointmentsQuery = query(
              collection(db, 'appointments'),
              where('garageId', '==', garageId),
              orderBy('date', 'desc')
            );
            
            unsubscribeAppointments = onSnapshot(appointmentsQuery, (querySnapshot) => {
              const appointments = [];
              querySnapshot.forEach((doc) => {
                appointments.push({
                  id: doc.id,
                  ...doc.data()
                });
              });
              
              // Mettre à jour les rendez-vous dans le localStorage
              localStorage.setItem('garage_appointments', JSON.stringify({
                items: appointments,
                lastSynced: new Date().toISOString()
              }));
              
              // Déclencher un événement personnalisé
              const event = new CustomEvent('appointmentsUpdated', { detail: appointments });
              window.dispatchEvent(event);
            }, (error) => {
              console.error('Erreur lors de la synchronisation des rendez-vous:', error);
            });
          }
        }
      } catch (error) {
        console.error('Erreur lors de la vérification du rôle utilisateur:', error);
      }
    };
    
    checkUserRole();

    return () => {
      unsubscribeUser();
      unsubscribeNotifications();
      unsubscribeAppointments();
    };
  }, [userId]);

  // Synchroniser les données hors ligne
  useEffect(() => {
    if (!isAuthenticated || !userId) return;

    // Vérifier la connectivité réseau
    const handleOnline = () => {
      console.log('Connexion rétablie, synchronisation des données...');
      
      // Synchroniser les données modifiées hors ligne
      const syncOfflineData = async () => {
        try {
          // Récupérer les actions en attente du localStorage
          const pendingActions = JSON.parse(localStorage.getItem('pending_actions') || '[]');
          
          // Traiter chaque action en attente
          for (const action of pendingActions) {
            switch (action.type) {
              case 'update_appointment_status':
                // Mettre à jour le statut d'un rendez-vous
                await updateDoc(doc(db, 'appointments', action.appointmentId), {
                  status: action.status,
                  updatedAt: serverTimestamp()
                });
                break;
              
              case 'add_client_note':
                // Ajouter une note client
                await updateDoc(doc(db, 'clients', action.clientId), {
                  notes: arrayUnion({
                    text: action.note,
                    createdAt: serverTimestamp()
                  })
                });
                break;
              
              // Autres types d'actions...
            }
          }
          
          // Effacer les actions traitées
          localStorage.removeItem('pending_actions');
        } catch (error) {
          console.error('Erreur lors de la synchronisation des données hors ligne:', error);
        }
      };
      
      syncOfflineData();
    };
    
    const handleOffline = () => {
      console.log('Connexion perdue, passage en mode hors ligne...');
      // Afficher une notification à l'utilisateur
      const event = new CustomEvent('connectionStatusChanged', { detail: { status: 'offline' } });
      window.dispatchEvent(event);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [isAuthenticated, userId]);

  if (!isReady) {
    // Afficher un écran de chargement pendant l'initialisation
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Chargement de votre espace...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
