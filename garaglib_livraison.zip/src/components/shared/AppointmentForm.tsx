// src/components/shared/AppointmentForm.tsx
import { useState } from 'react';
import { Slot } from '@/lib/firebase/slots';

interface AppointmentFormProps {
  garageId: string;
  onSubmit: (appointmentData: any) => void;
}

export default function AppointmentForm({ garageId, onSubmit }: AppointmentFormProps) {
  const [selectedService, setSelectedService] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [vehicleInfo, setVehicleInfo] = useState({
    make: '',
    model: '',
    year: '',
    licensePlate: ''
  });
  const [notes, setNotes] = useState<string>('');
  const [step, setStep] = useState<number>(1);

  const handleServiceSelect = (serviceId: string) => {
    setSelectedService(serviceId);
    setStep(2);
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
  };

  const handleSlotSelect = (slot: Slot) => {
    setSelectedSlot(slot);
    setStep(3);
  };

  const handleVehicleInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setVehicleInfo(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotes(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedService || !selectedDate || !selectedSlot) {
      return;
    }
    
    const appointmentData = {
      garageId,
      serviceId: selectedService,
      slotId: selectedSlot.id,
      date: selectedDate,
      startTime: selectedSlot.startTime,
      duration: selectedSlot.duration,
      vehicleInfo,
      notes
    };
    
    onSubmit(appointmentData);
  };

  return (
    <div className="space-y-6">
      {step === 1 && (
        <div className="card">
          <h2 className="text-xl font-semibold mb-4">1. Sélectionnez un service</h2>
          
          <div className="space-y-3">
            <div 
              className={`border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors ${selectedService === 'service1' ? 'bg-blue-50 border-primary' : ''}`}
              onClick={() => handleServiceSelect('service1')}
            >
              <div className="flex justify-between">
                <div>
                  <h3 className="font-medium">Révision complète</h3>
                  <p className="text-sm text-gray-600 mt-1">Contrôle des points essentiels de votre véhicule</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">120 €</p>
                  <p className="text-sm text-gray-600">Durée: 90 min</p>
                </div>
              </div>
            </div>
            
            <div 
              className={`border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors ${selectedService === 'service2' ? 'bg-blue-50 border-primary' : ''}`}
              onClick={() => handleServiceSelect('service2')}
            >
              <div className="flex justify-between">
                <div>
                  <h3 className="font-medium">Changement de pneus</h3>
                  <p className="text-sm text-gray-600 mt-1">Remplacement des 4 pneus</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">80 €</p>
                  <p className="text-sm text-gray-600">Durée: 60 min</p>
                </div>
              </div>
            </div>
            
            <div 
              className={`border rounded-lg p-4 hover:border-primary cursor-pointer transition-colors ${selectedService === 'service3' ? 'bg-blue-50 border-primary' : ''}`}
              onClick={() => handleServiceSelect('service3')}
            >
              <div className="flex justify-between">
                <div>
                  <h3 className="font-medium">Vidange</h3>
                  <p className="text-sm text-gray-600 mt-1">Changement d'huile et du filtre</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">60 €</p>
                  <p className="text-sm text-gray-600">Durée: 30 min</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {step >= 2 && (
        <div className="card">
          <h2 className="text-xl font-semibold mb-4">2. Choisissez une date et un créneau</h2>
          
          <div className="grid grid-cols-7 gap-2 mb-6">
            {/* Exemple de sélection de date - à remplacer par un vrai calendrier */}
            {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map((day, index) => (
              <div key={index} className="text-center">
                <p className="text-sm font-medium mb-1">{day}</p>
                <p className="text-sm text-gray-500 mb-1">{20 + index}</p>
                <button 
                  className={`w-full py-2 rounded-md ${index === 1 ? 'bg-primary text-white' : 'border hover:border-primary transition-colors'}`}
                  onClick={() => handleDateSelect(new Date(2025, 4, 20 + index))}
                >
                  <span className="text-xs">{index === 6 ? 'Fermé' : `${5 - index} créneaux`}</span>
                </button>
              </div>
            ))}
          </div>
          
          {selectedDate && (
            <>
              <h3 className="font-medium mb-3">Créneaux disponibles pour le {selectedDate.toLocaleDateString('fr-FR')}</h3>
              
              <div className="grid grid-cols-3 gap-2">
                {['09:30', '11:00', '14:00', '15:30', '16:30'].map((time, index) => (
                  <button 
                    key={index}
                    className="py-2 px-3 rounded-md border hover:border-primary hover:bg-blue-50 transition-colors text-center"
                    onClick={() => handleSlotSelect({
                      id: `slot${index}`,
                      garageId,
                      date: selectedDate,
                      startTime: time,
                      duration: 60,
                      serviceId: null,
                      isBooked: false
                    })}
                  >
                    {time}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      )}
      
      {step >= 3 && (
        <form onSubmit={handleSubmit}>
          <div className="card mb-6">
            <h2 className="text-xl font-semibold mb-4">3. Informations sur votre véhicule</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="make" className="block text-sm font-medium text-gray-700 mb-1">Marque</label>
                <input 
                  type="text" 
                  id="make" 
                  name="make"
                  value={vehicleInfo.make}
                  onChange={handleVehicleInfoChange}
                  className="input w-full" 
                  placeholder="Ex: Renault" 
                  required
                />
              </div>
              
              <div>
                <label htmlFor="model" className="block text-sm font-medium text-gray-700 mb-1">Modèle</label>
                <input 
                  type="text" 
                  id="model" 
                  name="model"
                  value={vehicleInfo.model}
                  onChange={handleVehicleInfoChange}
                  className="input w-full" 
                  placeholder="Ex: Clio" 
                  required
                />
              </div>
              
              <div>
                <label htmlFor="year" className="block text-sm font-medium text-gray-700 mb-1">Année</label>
                <input 
                  type="number" 
                  id="year" 
                  name="year"
                  value={vehicleInfo.year}
                  onChange={handleVehicleInfoChange}
                  className="input w-full" 
                  placeholder="Ex: 2018" 
                  required
                />
              </div>
              
              <div>
                <label htmlFor="licensePlate" className="block text-sm font-medium text-gray-700 mb-1">Immatriculation</label>
                <input 
                  type="text" 
                  id="licensePlate" 
                  name="licensePlate"
                  value={vehicleInfo.licensePlate}
                  onChange={handleVehicleInfoChange}
                  className="input w-full" 
                  placeholder="Ex: AB-123-CD" 
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1">Notes additionnelles (optionnel)</label>
              <textarea 
                id="notes" 
                value={notes}
                onChange={handleNotesChange}
                rows={3} 
                className="input w-full" 
                placeholder="Informations supplémentaires pour le garagiste..."
              ></textarea>
            </div>
          </div>
          
          <div className="card">
            <h2 className="text-xl font-semibold mb-4">4. Récapitulatif</h2>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between pb-4 border-b">
                <div>
                  <p className="font-medium">Service</p>
                  <p className="text-gray-600">
                    {selectedService === 'service1' ? 'Révision complète' : 
                     selectedService === 'service2' ? 'Changement de pneus' : 
                     selectedService === 'service3' ? 'Vidange' : ''}
                  </p>
                </div>
                <p className="font-medium">
                  {selectedService === 'service1' ? '120 €' : 
                   selectedService === 'service2' ? '80 €' : 
                   selectedService === 'service3' ? '60 €' : ''}
                </p>
              </div>
              
              <div className="flex justify-between pb-4 border-b">
                <div>
                  <p className="font-medium">Date et heure</p>
                  <p className="text-gray-600">
                    {selectedDate && selectedSlot ? 
                      `${selectedDate.toLocaleDateString('fr-FR')}, ${selectedSlot.startTime}` : 
                      'À sélectionner'}
                  </p>
                </div>
                <p className="font-medium">
                  {selectedSlot ? `${selectedSlot.duration} min` : ''}
                </p>
              </div>
              
              <div className="flex justify-between">
                <div>
                  <p className="font-medium">Véhicule</p>
                  <p className="text-gray-600">
                    {vehicleInfo.make && vehicleInfo.model ? 
                      `${vehicleInfo.make} ${vehicleInfo.model} (${vehicleInfo.year}) - ${vehicleInfo.licensePlate}` : 
                      'À renseigner'}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between items-center font-medium text-lg pb-4 mb-6 border-b">
              <p>Total</p>
              <p>
                {selectedService === 'service1' ? '120 €' : 
                 selectedService === 'service2' ? '80 €' : 
                 selectedService === 'service3' ? '60 €' : '0 €'}
              </p>
            </div>
            
            <div className="flex justify-end">
              <button 
                type="submit"
                className="px-6 py-3 bg-primary text-white rounded-md hover:bg-primary-light transition-colors"
                disabled={!selectedService || !selectedDate || !selectedSlot || !vehicleInfo.make || !vehicleInfo.model || !vehicleInfo.year || !vehicleInfo.licensePlate}
              >
                Confirmer la réservation
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
