"use client";

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/hooks/useAuth';

// Interface pour le rapport de test
interface TestReport {
  totalTests: number;
  passedTests: number;
  warningTests: number;
  failedTests: number;
  components: {
    [key: string]: {
      passed: number;
      warnings: number;
      failed: number;
      total: number;
    }
  };
  details: {
    component: string;
    name: string;
    status: 'success' | 'warning' | 'error';
    message: string;
  }[];
  timestamp: Date;
}

export default function TestReport() {
  const [reports, setReports] = useState<TestReport[]>([]);
  const [selectedReport, setSelectedReport] = useState<TestReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();

  // Charger les rapports de test
  useEffect(() => {
    const loadReports = async () => {
      try {
        setIsLoading(true);
        // Simulation de chargement des rapports depuis Firebase
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Données de test
        const mockReports: TestReport[] = [
          {
            totalTests: 24,
            passedTests: 20,
            warningTests: 3,
            failedTests: 1,
            components: {
              'PhotoManager': { passed: 3, warnings: 0, failed: 0, total: 3 },
              'QuoteManager': { passed: 1, warnings: 1, failed: 0, total: 2 },
              'ClientPortfolio': { passed: 2, warnings: 0, failed: 0, total: 2 },
              'AppointmentCalendar': { passed: 3, warnings: 0, failed: 0, total: 3 },
              'NotificationSystem': { passed: 2, warnings: 0, failed: 0, total: 2 },
              'ResponsiveOptimizer': { passed: 1, warnings: 1, failed: 0, total: 2 },
              'RealtimeSynchronization': { passed: 1, warnings: 1, failed: 0, total: 2 },
              'Authentication': { passed: 2, warnings: 0, failed: 1, total: 3 },
              'Integration': { passed: 5, warnings: 0, failed: 0, total: 5 }
            },
            details: [
              { component: 'PhotoManager', name: 'Chargement des photos', status: 'success', message: 'Les photos se chargent correctement' },
              { component: 'PhotoManager', name: 'Upload de photos', status: 'success', message: 'L\'upload de photos fonctionne correctement' },
              { component: 'PhotoManager', name: 'Suppression de photos', status: 'success', message: 'La suppression de photos fonctionne correctement' },
              { component: 'QuoteManager', name: 'Chargement des devis', status: 'success', message: 'Les devis se chargent correctement' },
              { component: 'QuoteManager', name: 'Création de devis', status: 'warning', message: 'La création de devis fonctionne mais des validations supplémentaires sont nécessaires' },
              { component: 'ClientPortfolio', name: 'Chargement des clients', status: 'success', message: 'Les clients se chargent correctement' },
              { component: 'ClientPortfolio', name: 'Recherche de clients', status: 'success', message: 'La recherche de clients fonctionne correctement' },
              { component: 'AppointmentCalendar', name: 'Chargement des rendez-vous', status: 'success', message: 'Les rendez-vous se chargent correctement' },
              { component: 'AppointmentCalendar', name: 'Acceptation des rendez-vous', status: 'success', message: 'L\'acceptation des rendez-vous fonctionne correctement' },
              { component: 'AppointmentCalendar', name: 'Refus des rendez-vous', status: 'success', message: 'Le refus des rendez-vous fonctionne correctement' },
              { component: 'NotificationSystem', name: 'Chargement des notifications', status: 'success', message: 'Les notifications se chargent correctement' },
              { component: 'NotificationSystem', name: 'Mise à jour des notifications', status: 'success', message: 'La mise à jour des notifications fonctionne correctement' },
              { component: 'ResponsiveOptimizer', name: 'Détection des breakpoints', status: 'success', message: 'La détection des breakpoints fonctionne correctement' },
              { component: 'ResponsiveOptimizer', name: 'Adaptation mobile', status: 'warning', message: 'L\'adaptation mobile fonctionne mais certains éléments nécessitent des ajustements' },
              { component: 'RealtimeSynchronization', name: 'Synchronisation en temps réel', status: 'success', message: 'La synchronisation en temps réel fonctionne correctement' },
              { component: 'RealtimeSynchronization', name: 'Mode hors ligne', status: 'warning', message: 'Le mode hors ligne fonctionne mais la resynchronisation peut être améliorée' },
              { component: 'Authentication', name: 'Connexion', status: 'success', message: 'La connexion fonctionne correctement' },
              { component: 'Authentication', name: 'Gestion des rôles', status: 'success', message: 'La gestion des rôles fonctionne correctement' },
              { component: 'Authentication', name: 'Déconnexion', status: 'error', message: 'Problème de persistance de session après déconnexion' },
              { component: 'Integration', name: 'Navigation', status: 'success', message: 'La navigation entre les pages fonctionne correctement' },
              { component: 'Integration', name: 'Cohérence des données', status: 'success', message: 'Les données sont cohérentes entre les différentes vues' },
              { component: 'Integration', name: 'Performance', status: 'success', message: 'Les performances sont satisfaisantes' },
              { component: 'Integration', name: 'Sécurité', status: 'success', message: 'Les contrôles de sécurité fonctionnent correctement' },
              { component: 'Integration', name: 'Compatibilité navigateurs', status: 'success', message: 'L\'application est compatible avec les principaux navigateurs' }
            ],
            timestamp: new Date(2025, 4, 21, 15, 30)
          },
          {
            totalTests: 24,
            passedTests: 22,
            warningTests: 2,
            failedTests: 0,
            components: {
              'PhotoManager': { passed: 3, warnings: 0, failed: 0, total: 3 },
              'QuoteManager': { passed: 1, warnings: 1, failed: 0, total: 2 },
              'ClientPortfolio': { passed: 2, warnings: 0, failed: 0, total: 2 },
              'AppointmentCalendar': { passed: 3, warnings: 0, failed: 0, total: 3 },
              'NotificationSystem': { passed: 2, warnings: 0, failed: 0, total: 2 },
              'ResponsiveOptimizer': { passed: 1, warnings: 1, failed: 0, total: 2 },
              'RealtimeSynchronization': { passed: 2, warnings: 0, failed: 0, total: 2 },
              'Authentication': { passed: 3, warnings: 0, failed: 0, total: 3 },
              'Integration': { passed: 5, warnings: 0, failed: 0, total: 5 }
            },
            details: [
              // Détails similaires avec corrections
              { component: 'Authentication', name: 'Déconnexion', status: 'success', message: 'La déconnexion fonctionne correctement après correction' },
              { component: 'RealtimeSynchronization', name: 'Mode hors ligne', status: 'warning', message: 'Le mode hors ligne fonctionne mais la resynchronisation peut être améliorée' }
              // ... autres détails
            ],
            timestamp: new Date(2025, 4, 21, 17, 45)
          }
        ];
        
        setReports(mockReports);
        setSelectedReport(mockReports[0]);
      } catch (error) {
        console.error('Erreur lors du chargement des rapports de test:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadReports();
  }, []);

  // Vérifier si l'utilisateur est autorisé à accéder aux rapports de test
  const isAuthorized = user && user.role === 'admin';

  if (!isAuthorized) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
        Vous n'êtes pas autorisé à accéder aux rapports de test.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Rapports de test</h2>
      
      {isLoading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <div>
          {/* Sélection du rapport */}
          <div className="mb-6">
            <label htmlFor="report-select" className="block text-sm font-medium text-gray-700 mb-1">
              Sélectionner un rapport
            </label>
            <select
              id="report-select"
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm rounded-md"
              value={selectedReport ? reports.findIndex(r => r.timestamp === selectedReport.timestamp) : 0}
              onChange={(e) => setSelectedReport(reports[parseInt(e.target.value)])}
            >
              {reports.map((report, index) => (
                <option key={index} value={index}>
                  {report.timestamp.toLocaleString()} - {report.passedTests}/{report.totalTests} tests réussis
                </option>
              ))}
            </select>
          </div>
          
          {selectedReport && (
            <div>
              {/* Résumé du rapport */}
              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <h3 className="text-lg font-medium text-gray-800 mb-3">Résumé</h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-gray-500">Tests totaux</p>
                    <p className="text-2xl font-bold text-gray-900">{selectedReport.totalTests}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-green-600">Tests réussis</p>
                    <p className="text-2xl font-bold text-green-700">{selectedReport.passedTests}</p>
                    <p className="text-sm text-green-600">
                      {Math.round((selectedReport.passedTests / selectedReport.totalTests) * 100)}%
                    </p>
                  </div>
                  <div className="bg-yellow-50 p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-yellow-600">Avertissements</p>
                    <p className="text-2xl font-bold text-yellow-700">{selectedReport.warningTests}</p>
                    <p className="text-sm text-yellow-600">
                      {Math.round((selectedReport.warningTests / selectedReport.totalTests) * 100)}%
                    </p>
                  </div>
                  <div className="bg-red-50 p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-red-600">Tests échoués</p>
                    <p className="text-2xl font-bold text-red-700">{selectedReport.failedTests}</p>
                    <p className="text-sm text-red-600">
                      {Math.round((selectedReport.failedTests / selectedReport.totalTests) * 100)}%
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Résultats par composant */}
              <div className="mb-6">
                <h3 className="text-lg font-medium text-gray-800 mb-3">Résultats par composant</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Composant
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Tests réussis
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Avertissements
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Tests échoués
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Taux de réussite
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {Object.entries(selectedReport.components).map(([component, stats]) => (
                        <tr key={component}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {component}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {stats.passed}/{stats.total}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {stats.warnings}/{stats.total}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {stats.failed}/{stats.total}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="w-full bg-gray-200 rounded-full h-2.5">
                              <div 
                                className={`h-2.5 rounded-full ${
                                  stats.failed > 0 ? 'bg-red-500' :
                                  stats.warnings > 0 ? 'bg-yellow-500' :
                                  'bg-green-500'
                                }`}
                                style={{ width: `${Math.round((stats.passed / stats.total) * 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-gray-500 mt-1 inline-block">
                              {Math.round((stats.passed / stats.total) * 100)}%
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              
              {/* Détails des tests */}
              <div>
                <h3 className="text-lg font-medium text-gray-800 mb-3">Détails des tests</h3>
                <div className="space-y-4">
                  {selectedReport.details
                    .filter(detail => detail.status !== 'success')
                    .map((detail, index) => (
                      <div 
                        key={index}
                        className={`p-4 rounded-lg ${
                          detail.status === 'warning' ? 'bg-yellow-50 border border-yellow-200' :
                          'bg-red-50 border border-red-200'
                        }`}
                      >
                        <div className="flex justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900">{detail.name}</p>
                            <p className="text-xs text-gray-500 mt-1">Composant: {detail.component}</p>
                          </div>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            detail.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {detail.status === 'warning' ? 'Avertissement' : 'Erreur'}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mt-2">{detail.message}</p>
                      </div>
                    ))}
                  
                  {selectedReport.details.filter(detail => detail.status !== 'success').length === 0 && (
                    <div className="text-center py-8 bg-green-50 rounded-lg border border-green-200">
                      <svg className="w-12 h-12 text-green-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <p className="text-green-700 font-medium">
                        Tous les tests ont réussi sans problème !
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
