# Documentation d'accès à Garaglib

## Informations générales

**Nom du projet :** Garaglib  
**Description :** Plateforme de réservation de rendez-vous pour garages automobiles  
**URL de production :** https://garaglib.vercel.app  
**Date de déploiement :** 21 mai 2025

## Accès administrateur

**Email :** contact@garaglib.com  
**Mot de passe :** Yanisfred11  
**URL d'accès :** https://garaglib.vercel.app/admin/dashboard

## Fonctionnalités principales

### Pour les clients
- Recherche de garages par localisation et services
- Consultation des disponibilités en temps réel
- Réservation de créneaux horaires
- Gestion des rendez-vous depuis un espace personnel
- Système d'avis et d'évaluation des garages
- Ajout de garages en favoris

### Pour les garages
- Gestion de planning avec minimum 5 créneaux disponibles
- Tableau de bord avec statistiques et suivi des rendez-vous
- Gestion des services et tarifs
- Réception de notifications pour les nouvelles réservations
- Export des données clients et rendez-vous

### Pour l'administrateur
- Création de garages à distance
- Supervision de tous les garages et utilisateurs
- Accès aux statistiques globales
- Gestion des messages de contact
- Configuration des paramètres système

## Parcours d'inscription garage

1. Le garage accède à la page d'inscription via "Devenir partenaire"
2. Il remplit le formulaire d'inscription avec ses informations
3. Il est redirigé vers la page de paiement Stripe (29,99€/mois)
4. Après paiement, il reçoit ses identifiants par email
5. Il peut se connecter et compléter son profil

## Création de garage par l'administrateur

1. Se connecter avec les identifiants admin
2. Accéder à l'URL : https://garaglib.vercel.app/admin/garages/create
3. Remplir le formulaire de création de garage
4. Valider pour créer le compte garage
5. Les identifiants sont automatiquement envoyés au garage par email

## Contacts et support

Pour toute question ou assistance, veuillez contacter :
- Email : support@garaglib.com
- Téléphone : +33 1 23 45 67 89
- Formulaire de contact : https://garaglib.vercel.app/contact
