/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1E3A8A', // bleu foncé
          light: '#3B82F6',   // bleu clair
        },
        secondary: {
          DEFAULT: '#F3F4F6', // gris clair
          dark: '#4B5563',    // gris foncé
        },
        success: '#10B981',   // vert
        error: '#EF4444',     // rouge
        warning: '#F59E0B',   // orange
      },
    },
  },
  plugins: [],
}
