# Analyse des nouvelles fonctionnalités pour Garaglib

## 1. Page d'inscription pour les garages

### Flux utilisateur
- Le garage accède à une page commerciale attractive
- Il découvre l'offre à 29,99€ et ses avantages
- Il remplit un formulaire d'inscription avec ses informations
- Il est redirigé vers Stripe pour le paiement
- Après paiement réussi, son compte est créé et il reçoit ses identifiants

### Modèle de données
```typescript
interface GarageSubscription {
  id: string;
  garageId: string;
  stripeCustomerId: string;
  subscriptionId: string;
  status: 'active' | 'canceled' | 'past_due';
  priceId: string;
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  createdAt: Date;
  updatedAt: Date;
}
```

## 2. Intégration Stripe

### Flux de paiement
- Utilisation du lien Stripe fourni: https://buy.stripe.com/9AQ7uOdyS7Cg05W5kn
- Redirection après paiement vers une page de confirmation
- Webhook Stripe pour gérer les événements de paiement (optionnel)

### Modèle de données
```typescript
interface Payment {
  id: string;
  garageId: string;
  stripePaymentId: string;
  amount: number;
  currency: string;
  status: 'succeeded' | 'failed' | 'pending';
  createdAt: Date;
}
```

## 3. Conditions générales de vente et d'utilisation

### Structure
- Section CGV sur la page d'accueil
- Section CGU sur la page d'accueil
- Mentions légales
- Politique de confidentialité
- Acceptation obligatoire lors de l'inscription

## 4. Rubrique contact avec formulaire

### Flux utilisateur
- L'utilisateur accède à la page contact
- Il remplit le formulaire (nom, email, sujet, message)
- Le message est enregistré et accessible depuis le dashboard admin

### Modèle de données
```typescript
interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'unread' | 'read' | 'replied';
  createdAt: Date;
  updatedAt: Date;
}
```

## 5. Création de garages à distance par l'admin

### Flux administrateur
- L'admin se connecte au dashboard admin
- Il accède à une section "Gestion des garages"
- Il peut créer un nouveau garage en remplissant un formulaire
- Il peut modifier les informations des garages existants
- Il peut désactiver/réactiver un garage

### Modèle de données
```typescript
// Extension du modèle Garage existant
interface Garage {
  // Champs existants...
  createdByAdmin: boolean;
  adminNotes?: string;
  isActive: boolean;
}
```

## 6. Configuration du compte admin par défaut

### Données d'accès
- Email: contact@garaglib.com
- Mot de passe: Yanisfred11
- Rôle: admin

### Implémentation
- Créer un script d'initialisation pour générer ce compte admin par défaut
- S'assurer que ce compte a tous les privilèges administrateur
